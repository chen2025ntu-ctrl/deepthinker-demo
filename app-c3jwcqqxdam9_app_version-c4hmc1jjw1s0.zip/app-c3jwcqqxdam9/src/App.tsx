import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import IntersectObserver from '@/components/common/IntersectObserver';
import { Toaster } from '@/components/ui/sonner';
import MainLayout from '@/components/layouts/MainLayout';
import { LangProvider } from '@/contexts/LangContext';
import { AuthProvider } from '@/contexts/AuthContext';
import { RouteGuard } from '@/components/common/RouteGuard';
import LoginPage from '@/pages/LoginPage';
import { routes } from './routes';

const App: React.FC = () => {
  return (
    <LangProvider>
      <AuthProvider>
        <Router>
          <IntersectObserver />
          <Routes>
            {/* 登录页：不走 MainLayout */}
            <Route path="/login" element={<LoginPage />} />
            {/* 所有受保护路由 */}
            <Route
              path="*"
              element={
                <RouteGuard>
                  <MainLayout>
                    <Routes>
                      {routes.map((route, index) => (
                        <Route key={index} path={route.path} element={route.element} />
                      ))}
                      <Route path="*" element={<Navigate to="/" replace />} />
                    </Routes>
                  </MainLayout>
                </RouteGuard>
              }
            />
          </Routes>
          <Toaster />
        </Router>
      </AuthProvider>
    </LangProvider>
  );
};

export default App;
