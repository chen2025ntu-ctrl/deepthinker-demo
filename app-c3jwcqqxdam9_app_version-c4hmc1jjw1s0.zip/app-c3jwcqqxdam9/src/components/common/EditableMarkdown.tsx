import React, { useState } from 'react';
import { useLang } from '@/contexts/LangContext';

interface EditableMarkdownProps {
  value: string;
  onChange: (v: string) => void;
}

export default function EditableMarkdown({ value, onChange }: EditableMarkdownProps) {
  const { t } = useLang();
  const [isEditing, setIsEditing] = useState(false);

  return (
    <div className="border border-border">
      {/* 工具栏 */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-border bg-muted/40">
        <span className="text-xs text-muted-foreground font-mono">Markdown</span>
        <button
          onClick={() => setIsEditing(!isEditing)}
          className="text-xs text-primary hover:underline"
        >
          {isEditing ? t.editableMarkdown.preview : t.editableMarkdown.edit}
        </button>
      </div>
      {isEditing ? (
        <textarea
          className="w-full min-h-64 p-4 font-mono text-sm bg-card text-foreground resize-y focus:outline-none focus:ring-1 focus:ring-ring"
          value={value}
          onChange={(e) => onChange(e.target.value)}
        />
      ) : (
        <div
          className="p-4 min-h-64 prose prose-sm max-w-none text-foreground cursor-pointer hover:bg-muted/20 transition-colors"
          onClick={() => setIsEditing(true)}
        >
          {value ? (
            <pre className="whitespace-pre-wrap font-sans text-sm text-foreground bg-transparent p-0 m-0">{value}</pre>
          ) : (
            <p className="text-muted-foreground text-sm">{t.editableMarkdown.clickToEdit}</p>
          )}
        </div>
      )}
    </div>
  );
}
