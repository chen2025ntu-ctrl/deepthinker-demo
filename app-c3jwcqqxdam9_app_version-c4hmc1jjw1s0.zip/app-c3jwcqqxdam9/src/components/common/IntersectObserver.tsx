// 占位组件，用于交叉观察器初始化（可扩展懒加载等功能）
export default function IntersectObserver() {
  return null;
}
