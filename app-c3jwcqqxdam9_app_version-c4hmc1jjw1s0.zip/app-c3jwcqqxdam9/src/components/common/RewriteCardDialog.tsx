import React, { useState, useCallback } from 'react';
import { Loader2, Sparkles, Check, RefreshCw, ChevronRight, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { useLang } from '@/contexts/LangContext';
import { evidenceCardService } from '@/services/database';
import type { EvidenceCard } from '@/types/types';
import { DIMENSION_COLORS } from '@/types/types';
import { toast } from 'sonner';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export interface RewriteResult {
  summary: string;
  structured_content: Record<string, string>;
  summary_en: string;
  structured_content_en: Record<string, string>;
}

// ── API 调用（带退避重试，120s 超时） ────────────────────────────────────────
async function callRewriteAPI(card: EvidenceCard, retries = 2): Promise<RewriteResult> {
  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 120_000);
    try {
      const res = await fetch(`${supabaseUrl}/functions/v1/rewrite-evidence-card`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${supabaseAnonKey}`,
          apikey: supabaseAnonKey,
        },
        body: JSON.stringify({ card }),
        signal: controller.signal,
      });
      clearTimeout(timer);

      if (res.status === 429) {
        if (attempt < retries) {
          // 指数退避：3s → 6s
          await new Promise<void>((r) => setTimeout(r, 3000 * (attempt + 1)));
          continue;
        }
        throw new Error('429');
      }
      if (res.status === 402) throw new Error('402');
      if (!res.ok) {
        const text = await res.text().catch(() => '');
        throw new Error(`HTTP ${res.status}: ${text.slice(0, 200)}`);
      }

      const data = await res.json() as RewriteResult & { error?: string };
      if (data.error) throw new Error(data.error);
      return {
        summary: data.summary ?? '',
        structured_content: data.structured_content ?? {},
        summary_en: data.summary_en ?? '',
        structured_content_en: data.structured_content_en ?? {},
      };
    } catch (e) {
      clearTimeout(timer);
      // 不可重试的错误：直接抛出
      if (e instanceof Error && (e.message === '402' || e.message.startsWith('HTTP'))) throw e;
      // 已耗尽重试次数
      if (attempt >= retries) throw e;
      await new Promise<void>((r) => setTimeout(r, 2000));
    }
  }
  throw new Error('重试失败');
}

// ── 双语字段对比面板 ──────────────────────────────────────────────────────────
function BilingualDiff({
  card,
  result,
  zhLabels,
  enLabels,
}: {
  card: EvidenceCard;
  result: RewriteResult;
  zhLabels: Record<string, string>;
  enLabels: Record<string, string>;
}) {
  const { t } = useLang();
  const fields = Object.keys(result.structured_content);

  const Row = ({
    label, orig, next
  }: { label: string; orig: string; next: string }) => (
    <div className="grid grid-cols-[4.5rem_1fr] gap-x-2">
      <span className="text-xs text-muted-foreground text-right pt-0.5 shrink-0">{label}</span>
      <p className={cn('text-sm leading-snug text-pretty', next !== orig ? 'text-foreground font-medium' : 'text-muted-foreground')}>
        {next || orig}
      </p>
    </div>
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
      {/* 原始 */}
      <div className="space-y-3">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{t.evidence.llmRewriteOriginalLabel}</p>
        <div className="p-3 bg-muted/40 border border-border space-y-3">
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-1">{t.evidence.llmRewriteSummaryLabel}</p>
            <p className="text-sm text-foreground leading-relaxed text-pretty">{card.summary}</p>
          </div>
          {fields.some((f) => card.structured_content[f]?.trim()) && (
            <div className="space-y-1.5">
              {fields.map((f) => card.structured_content[f]?.trim() ? (
                <Row key={f} label={zhLabels[f] ?? f} orig={card.structured_content[f]} next={card.structured_content[f]} />
              ) : null)}
            </div>
          )}
        </div>
      </div>

      {/* 中文重写 */}
      <div className="space-y-3">
        <p className="text-xs font-semibold text-primary uppercase tracking-wide flex items-center gap-1">
          <Sparkles className="h-3 w-3" />{t.evidence.llmRewriteZhLabel}
        </p>
        <div className="p-3 bg-primary/5 border border-primary/20 space-y-3">
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-1">{t.evidence.llmRewriteSummaryLabel}</p>
            <p className={cn('text-sm leading-relaxed text-pretty', result.summary !== card.summary ? 'text-foreground font-medium' : 'text-muted-foreground')}>
              {result.summary || card.summary}
            </p>
          </div>
          {fields.length > 0 && (
            <div className="space-y-1.5">
              {fields.map((f) => result.structured_content[f]?.trim() ? (
                <Row key={f} label={zhLabels[f] ?? f} orig={card.structured_content[f] ?? ''} next={result.structured_content[f]} />
              ) : null)}
            </div>
          )}
        </div>
      </div>

      {/* 英文版 */}
      <div className="space-y-3">
        <p className="text-xs font-semibold text-emerald-600 uppercase tracking-wide flex items-center gap-1">
          <Sparkles className="h-3 w-3" />English AI Version
        </p>
        <div className="p-3 bg-emerald-50 border border-emerald-200 space-y-3">
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-1">Summary</p>
            <p className="text-sm text-foreground font-medium leading-relaxed text-pretty">
              {result.summary_en || '—'}
            </p>
          </div>
          {fields.length > 0 && (
            <div className="space-y-1.5">
              {fields.map((f) => result.structured_content_en?.[f]?.trim() ? (
                <Row key={f} label={enLabels[f] ?? f} orig='' next={result.structured_content_en[f]} />
              ) : null)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── 单卡片重写 Dialog ─────────────────────────────────────────────────────────
export interface SingleRewriteDialogProps {
  card: EvidenceCard | null;
  onClose: () => void;
  onSaved: (updated: EvidenceCard) => void;
}

const EN_FIELD_LABELS: Record<string, string> = {
  method: 'Method', findings: 'Findings', conclusion: 'Conclusion',
  scenario: 'Scenario', solution: 'Solution', effect: 'Effect',
  requirements: 'Requirements', skills: 'Skills', distribution: 'Distribution',
  stage: 'Stage', track: 'Track', logic: 'Investment Logic',
};

export function SingleRewriteDialog({ card, onClose, onSaved }: SingleRewriteDialogProps) {
  const { t } = useLang();
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState<RewriteResult | null>(null);
  const [saving, setSaving] = useState(false);
  const zhLabels = t.evidence.fieldLabels as Record<string, string>;

  const generate = useCallback(async (target: EvidenceCard) => {
    setGenerating(true);
    setResult(null);
    try {
      const res = await callRewriteAPI(target);
      setResult(res);
    } catch (e) {
      const msg = e instanceof Error ? e.message : '';
      if (msg === '429') toast.error(t.evidence.llmRewriteError429);
      else if (msg === '402') toast.error(t.evidence.llmRewriteError402);
      else toast.error(t.evidence.llmRewriteFail);
    } finally {
      setGenerating(false);
    }
  }, [t]);

  React.useEffect(() => {
    if (card) { setResult(null); void generate(card); }
  }, [card]);

  const handleSave = async () => {
    if (!card || !result) return;
    setSaving(true);
    try {
      await evidenceCardService.update(card.id, {
        summary: result.summary,
        structured_content: result.structured_content,
        summary_en: result.summary_en,
        structured_content_en: result.structured_content_en,
      });
      onSaved({
        ...card,
        summary: result.summary,
        structured_content: result.structured_content,
        summary_en: result.summary_en,
        structured_content_en: result.structured_content_en,
      });
      toast.success(t.evidence.llmRewriteSaved);
      onClose();
    } catch {
      toast.error(t.evidence.llmRewriteFail);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={!!card} onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-5xl max-h-[90dvh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-balance pr-6">
            <Sparkles className="h-4 w-4 text-primary shrink-0" />
            {t.evidence.llmRewriteDialogTitle}
          </DialogTitle>
        </DialogHeader>

        {card && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={cn('text-xs font-medium px-2 py-0.5 border', DIMENSION_COLORS[card.dimension])}>
                {t.dimension[card.dimension]}
              </span>
              <p className="text-sm font-semibold text-foreground text-balance leading-snug flex-1">{card.title}</p>
            </div>

            {generating && (
              <div className="flex items-center justify-center gap-2 py-12 text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin" />
                <span className="text-sm">{t.evidence.llmRewriteGenerating}</span>
              </div>
            )}

            {!generating && result && (
              <BilingualDiff card={card} result={result} zhLabels={zhLabels} enLabels={EN_FIELD_LABELS} />
            )}

            {!generating && (
              <div className="flex gap-3 pt-2 border-t border-border">
                {result ? (
                  <>
                    <Button onClick={() => void handleSave()} disabled={saving} className="flex-1">
                      {saving
                        ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />{t.common.saving}</>
                        : <><Check className="h-4 w-4 mr-2" />{t.evidence.llmRewriteConfirmBtn}</>
                      }
                    </Button>
                    <Button variant="outline" onClick={() => void generate(card)} disabled={saving}>
                      <RefreshCw className="h-4 w-4 mr-2" />{t.evidence.llmRewriteRegenBtn}
                    </Button>
                  </>
                ) : (
                  <Button variant="outline" onClick={() => void generate(card)} className="flex-1">
                    <RefreshCw className="h-4 w-4 mr-2" />{t.evidence.llmRewriteRegenBtn}
                  </Button>
                )}
                <Button variant="outline" onClick={onClose}>{t.common.cancel}</Button>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ── 批量重写 Dialog ───────────────────────────────────────────────────────────
export interface BatchRewriteDialogProps {
  cards: EvidenceCard[];
  open: boolean;
  onClose: () => void;
  onAllSaved: (updates: Map<string, RewriteResult>) => void;
}

type BatchPhase = 'confirm' | 'running' | 'done';

export function BatchRewriteDialog({ cards, open, onClose, onAllSaved }: BatchRewriteDialogProps) {
  const { t } = useLang();
  const [phase, setPhase] = useState<BatchPhase>('confirm');
  const [done, setDone] = useState(0);
  const [ok, setOk] = useState(0);
  const [fail, setFail] = useState(0);
  const [currentTitle, setCurrentTitle] = useState('');
  const zhLabels = t.evidence.fieldLabels as Record<string, string>;

  const [previewCard, setPreviewCard] = useState<EvidenceCard | null>(null);
  const [previewResult, setPreviewResult] = useState<RewriteResult | null>(null);
  const [previewGenerating, setPreviewGenerating] = useState(false);

  React.useEffect(() => {
    if (open && cards.length > 0) {
      setPhase('confirm');
      setDone(0); setOk(0); setFail(0); setCurrentTitle('');
      setPreviewResult(null);
      const first = cards[0];
      setPreviewCard(first);
      setPreviewGenerating(true);
      callRewriteAPI(first)
        .then((res) => setPreviewResult(res))
        .catch(() => setPreviewResult(null))
        .finally(() => setPreviewGenerating(false));
    }
  }, [open]);

  const runBatch = async () => {
    setPhase('running');
    const updates = new Map<string, RewriteResult>();
    let okCount = 0, failCount = 0;

    for (let i = 0; i < cards.length; i++) {
      const card = cards[i];
      setCurrentTitle(card.title);
      try {
        const res = await callRewriteAPI(card);
        await evidenceCardService.update(card.id, {
          summary: res.summary,
          structured_content: res.structured_content,
          summary_en: res.summary_en,
          structured_content_en: res.structured_content_en,
        });
        updates.set(card.id, res);
        okCount++;
      } catch {
        failCount++;
      }
      setDone(i + 1);
      setOk(okCount);
      setFail(failCount);
      // 每张之间等待 2s，避免 LLM API 限流（429）
      if (i < cards.length - 1) {
        await new Promise<void>((resolve) => setTimeout(resolve, 2000));
      }
    }

    onAllSaved(updates);
    setPhase('done');
    toast.success(
      t.evidence.llmRewriteAllDone
        .replace('{ok}', String(okCount))
        .replace('{fail}', String(failCount))
    );
  };

  const handleClose = () => {
    if (phase === 'running') return;
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) handleClose(); }}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-5xl max-h-[90dvh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-balance pr-6">
            <Sparkles className="h-4 w-4 text-primary shrink-0" />
            {t.evidence.llmRewriteAllDialogTitle}
          </DialogTitle>
        </DialogHeader>

        {phase === 'confirm' && (
          <div className="space-y-5">
            <div className="flex items-start gap-2 p-3 bg-amber-50 border border-amber-200 text-amber-800 text-sm">
              <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
              <p className="text-pretty">
                {t.evidence.llmRewriteAllConfirmDesc.replace('{n}', String(cards.length))}
              </p>
            </div>

            {previewCard && (
              <div className="space-y-2">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                  {`${t.evidence.llmRewritePreviewLabel} — ${previewCard.title}`}
                </p>
                {previewGenerating ? (
                  <div className="flex items-center justify-center gap-2 py-10 text-muted-foreground">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-sm">{t.evidence.llmRewriteGenerating}</span>
                  </div>
                ) : previewResult ? (
                  <BilingualDiff card={previewCard} result={previewResult} zhLabels={zhLabels} enLabels={EN_FIELD_LABELS} />
                ) : (
                  <p className="text-sm text-muted-foreground py-4 text-center">{t.evidence.llmRewriteFail}</p>
                )}
              </div>
            )}

            <div className="flex gap-3 pt-2 border-t border-border">
              <Button
                onClick={() => void runBatch()}
                // 必须等预览完成，避免与批量并发触发 429
                disabled={previewGenerating}
                className="flex-1"
              >
                <ChevronRight className="h-4 w-4 mr-2" />
                {t.evidence.llmRewriteAllStartBtn} ({cards.length})
              </Button>
              <Button variant="outline" onClick={handleClose}>{t.common.cancel}</Button>
            </div>
          </div>
        )}

        {phase === 'running' && (
          <div className="space-y-6 py-4">
            <div className="flex flex-col items-center gap-3">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-sm font-medium text-foreground">
                {t.evidence.llmRewriteAllProgress
                  .replace('{done}', String(done))
                  .replace('{total}', String(cards.length))}
              </p>
              {currentTitle && (
                <p className="text-xs text-muted-foreground text-center max-w-xs truncate">{currentTitle}</p>
              )}
            </div>
            <div className="w-full bg-muted h-2">
              <div
                className="h-2 bg-primary transition-all duration-300"
                style={{ width: `${Math.round((done / cards.length) * 100)}%` }}
              />
            </div>
            <div className="flex justify-center gap-6 text-sm">
              <span className="text-emerald-600 font-medium">✓ {ok}</span>
              {fail > 0 && <span className="text-destructive font-medium">✗ {fail}</span>}
            </div>
          </div>
        )}

        {phase === 'done' && (
          <div className="space-y-4 py-4 text-center">
            <div className="flex justify-center">
              <div className="w-12 h-12 bg-emerald-50 border border-emerald-200 flex items-center justify-center">
                <Check className="h-6 w-6 text-emerald-600" />
              </div>
            </div>
            <p className="text-sm font-medium text-foreground">
              {t.evidence.llmRewriteAllDone
                .replace('{ok}', String(ok))
                .replace('{fail}', String(fail))}
            </p>
            <Button onClick={onClose} className="mx-auto">{t.common.close}</Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

