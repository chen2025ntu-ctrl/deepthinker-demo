import React, { useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  Upload, BookOpen, Search, FileText, BarChart3,
  Menu, X, FlaskConical, Languages, LogOut, User,
  LayoutDashboard,
} from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import { useLang } from '@/contexts/LangContext';
import { useAuth } from '@/contexts/AuthContext';

function NavItems({ onNavigate }: { onNavigate?: () => void }) {
  const location = useLocation();
  const { t } = useLang();

  const NAV_ITEMS = [
    { path: '/',          label: t.nav.dashboard,    icon: LayoutDashboard },
    { path: '/input',     label: t.nav.contentInput, icon: Upload },
    { path: '/knowledge', label: t.nav.knowledge,    icon: BookOpen },
    { path: '/research',  label: t.nav.research,     icon: Search },
    { path: '/evidence',  label: t.nav.evidence,     icon: FileText },
    { path: '/reports',   label: t.nav.reports,      icon: BarChart3 },
  ];

  return (
    <nav className="flex flex-col gap-0.5 px-2">
      {NAV_ITEMS.map(({ path, label, icon: Icon }) => {
        const active = path === '/' ? location.pathname === '/' : location.pathname.startsWith(path);
        return (
          <NavLink
            key={path}
            to={path}
            onClick={onNavigate}
            className={cn(
              'group relative flex items-center gap-3 px-3 py-2.5 text-sm font-medium transition-all duration-150 rounded-sm',
              active
                ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground'
            )}
          >
            {active && (
              <span className="absolute left-0 top-[20%] bottom-[20%] w-0.5 rounded-r-full bg-sidebar-primary" />
            )}
            <Icon className="h-4 w-4 shrink-0" />
            <span>{label}</span>
          </NavLink>
        );
      })}
    </nav>
  );
}

function UserMenu({ compact = false }: { compact?: boolean }) {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();
  const { t } = useLang();

  const handleSignOut = async () => {
    await signOut();
    navigate('/login', { replace: true });
  };

  const displayName = profile?.username ?? t.layout.userFallback;
  const initial = displayName[0]?.toUpperCase() ?? 'U';

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className={cn(
          'flex items-center gap-2 transition-colors hover:bg-sidebar-accent px-2 py-1.5 w-full rounded-sm',
          compact ? 'justify-center' : ''
        )}>
          <div className="w-7 h-7 rounded-sm bg-sidebar-primary flex items-center justify-center shrink-0">
            <span className="text-[11px] font-bold text-sidebar-primary-foreground">{initial}</span>
          </div>
          {!compact && (
            <span className="text-sm text-sidebar-foreground truncate flex-1 text-left">{displayName}</span>
          )}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-44">
        <div className="px-2 py-1.5">
          <p className="text-xs font-semibold text-foreground truncate">{displayName}</p>
          <p className="text-[11px] text-muted-foreground truncate">{profile?.email ?? ''}</p>
        </div>
        <DropdownMenuSeparator />
        <DropdownMenuItem disabled>
          <User className="h-3.5 w-3.5 mr-2" />
          {t.layout.userSettings}
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => void handleSignOut()} className="text-destructive focus:text-destructive">
          <LogOut className="h-3.5 w-3.5 mr-2" />
          {t.layout.signOut}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const { t, toggleLang } = useLang();
  return (
    <div className="flex flex-col h-full bg-sidebar">
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-4 border-b border-sidebar-border">
        <div className="flex items-center justify-center w-8 h-8 bg-sidebar-primary rounded-sm shrink-0 shadow-sm">
          <FlaskConical className="h-4 w-4 text-sidebar-primary-foreground" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-sidebar-foreground leading-tight text-balance">{t.layout.title}</p>
          <p className="text-[10px] font-mono tracking-wider text-sidebar-foreground/50 uppercase leading-tight mt-0.5">{t.layout.subtitle}</p>
        </div>
        <button
          onClick={toggleLang}
          title="切换语言 / Switch Language"
          className="shrink-0 flex items-center gap-1 px-1.5 py-1 text-[10px] font-mono font-semibold tracking-wider text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent transition-colors border border-sidebar-border rounded-sm"
        >
          <Languages className="h-3 w-3" />
          {t.layout.langToggle}
        </button>
      </div>

      {/* Nav section label */}
      <div className="px-4 pt-4 pb-1">
        <p className="text-[9px] font-mono tracking-[0.2em] uppercase text-sidebar-foreground/40">
          Workspace
        </p>
      </div>

      {/* Nav */}
      <div className="flex-1 overflow-y-auto py-1">
        <NavItems onNavigate={onNavigate} />
      </div>

      {/* User area */}
      <div className="border-t border-sidebar-border px-3 py-3">
        <UserMenu />
      </div>
    </div>
  );
}

export default function MainLayout({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { t, toggleLang } = useLang();

  return (
    <div className="flex min-h-screen w-full">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-60 shrink-0 border-r border-border">
        <SidebarContent />
      </aside>

      {/* Main content */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Mobile header */}
        <header className="lg:hidden flex items-center gap-3 px-4 py-3 border-b border-border bg-card">
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="shrink-0">
                {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-60 bg-sidebar">
              <SidebarContent onNavigate={() => setMobileOpen(false)} />
            </SheetContent>
          </Sheet>
          <span className="font-semibold text-foreground truncate flex-1">{t.layout.title}</span>
          <button
            onClick={toggleLang}
            className="shrink-0 flex items-center gap-1 px-2 py-1 text-xs font-mono font-semibold text-muted-foreground hover:text-foreground hover:bg-muted transition-colors border border-border rounded-sm"
          >
            <Languages className="h-3.5 w-3.5" />
            {t.layout.langToggle}
          </button>
        </header>

        {/* Page content */}
        <main className="flex-1 min-w-0 overflow-x-hidden">
          {children}
        </main>
      </div>
    </div>
  );
}
