import ky from 'ky';
import { createParser } from 'eventsource-parser';

export interface SSEOptions {
  onData: (data: string) => void;
  onCompleted?: (error?: Error) => void;
  onAborted?: () => void;
}

export interface StreamRequestOptions {
  functionName: string;
  requestBody: unknown;
  onData: (data: string) => void;
  onComplete: () => void;
  onError: (error: Error) => void;
  onAborted?: () => void;
  signal?: AbortSignal;
}

export async function sendStreamRequest(options: StreamRequestOptions): Promise<void> {
  const { functionName, requestBody, onData, onComplete, onError, signal } = options;
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
  const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

  let done = false;
  const finish = (err?: Error) => {
    if (!done) {
      done = true;
      if (err) onError(err);
      else onComplete();
    }
  };

  try {
    await ky.post(`${supabaseUrl}/functions/v1/${functionName}`, {
      json: requestBody,
      headers: {
        Authorization: `Bearer ${supabaseAnonKey}`,
        apikey: supabaseAnonKey,
        'Content-Type': 'application/json',
      },
      signal,
      timeout: 120000,
      hooks: {
        afterResponse: [
          async (_req, _opts, response) => {
            if (!response.ok || !response.body) return;
            const reader = response.body.getReader();
            const decoder = new TextDecoder('utf8');
            const parser = createParser({
              onEvent: (event) => {
                if (!event.data || event.data === '[DONE]') return;
                onData(event.data);
              },
            });

            const read = (): void => {
              reader
                .read()
                .then(({ done: streamDone, value }) => {
                  if (streamDone) {
                    finish();
                    return;
                  }
                  parser.feed(decoder.decode(value, { stream: true }));
                  read();
                })
                .catch((err: unknown) => {
                  if (signal?.aborted) {
                    options.onAborted?.();
                    return;
                  }
                  finish(err instanceof Error ? err : new Error(String(err)));
                });
            };
            read();
            return response;
          },
        ],
      },
    });
  } catch (err: unknown) {
    if (!signal?.aborted) {
      finish(err instanceof Error ? err : new Error(String(err)));
    }
  }
}

// 解析SSE数据帧中的文本内容（Gemini格式）
export function parseGeminiChunk(data: string): string {
  try {
    const frame = JSON.parse(data) as {
      candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
    };
    return frame?.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
  } catch {
    return '';
  }
}
