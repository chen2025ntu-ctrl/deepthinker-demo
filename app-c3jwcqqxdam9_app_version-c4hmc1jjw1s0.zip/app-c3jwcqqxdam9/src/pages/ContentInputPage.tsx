import React, { useState, useRef, useEffect } from 'react';
import {
  Upload, FileText, Type, Video, CheckSquare, Loader2,
  Check, AlertCircle, Link2, Share2, Info, ChevronDown, ChevronUp,
  Mic, Sparkles, Cloud, Radio, DatabaseZap, Cpu,
  AlertTriangle, ClipboardPaste, ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';
import { knowledgeService, topicService, videoPipelineService } from '@/services/database';
import type { SourceType, VideoPipelineJob, VideoPipelineStatus } from '@/types/types';
import EditableMarkdown from '@/components/common/EditableMarkdown';
import { useLang } from '@/contexts/LangContext';

type InputMode = 'video' | 'text' | 'document';
type VideoSubMode = 'upload' | 'url' | 'weixin';
// 视频处理阶段（用于进度展示）
type VideoStage = 'idle' | 'uploading' | 'transcribing' | 'formatting' | 'done';

// 管道阶段配置（URL 子模式专用）
interface PipelineStageConfig {
  key: VideoPipelineStatus | 'done';
  label: string;
  icon: React.ElementType;
  desc: string;
}

// 状态 → 管道阶段下标映射
const STATUS_TO_STAGE_IDX: Partial<Record<VideoPipelineStatus | 'done', number>> = {
  uploading_bos:   0,
  asr_submitted:   1,
  asr_processing:  1,
  transcribing:    1,
  formatting:      2,
  completed:       3,
  failed:          -1,
};

interface ProcessedResult {
  markdown: string;
  transcript?: string;
  srt?: string;
  sourceType: SourceType;
  fileName?: string;
}

const VIDEO_STAGE_ICONS: { key: VideoStage; icon: React.ElementType }[] = [
  { key: 'uploading',    icon: Cloud },
  { key: 'transcribing', icon: Mic },
  { key: 'formatting',   icon: Sparkles },
];

function isValidUrl(str: string): boolean {
  try {
    const u = new URL(str.trim());
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
}

// ── 视频处理实时进度组件 ──────────────────────────────────────────────────────

function VideoPipelineProgress({ job, pipelineStages, processingLabel }: {
  job: VideoPipelineJob;
  pipelineStages: PipelineStageConfig[];
  processingLabel: string;
}) {
  const activeIdx = STATUS_TO_STAGE_IDX[job.status] ?? -1;

  return (
    <div className="border border-border bg-muted/20 p-4 space-y-3">
      {/* 当前阶段文字 */}
      <div className="flex items-center gap-2">
        <Radio className="h-3.5 w-3.5 text-primary animate-pulse shrink-0" />
        <p className="text-xs font-medium text-primary truncate">
          {job.stage_label ?? processingLabel}
        </p>
      </div>

      {/* 四阶段进度条 */}
      <div className="flex items-center gap-0">
        {pipelineStages.map(({ key, label, icon: Icon }, idx) => {
          const isDone   = activeIdx > idx;
          const isActive = activeIdx === idx;
          const isFailed = job.status === 'failed';
          return (
            <React.Fragment key={key}>
              <div className="flex flex-col items-center gap-1 flex-1 min-w-0">
                <div className={cn(
                  'h-8 w-8 flex items-center justify-center border-2 transition-colors shrink-0',
                  isFailed && isActive ? 'border-destructive bg-destructive/10 text-destructive'
                  : isDone  ? 'border-primary bg-primary text-primary-foreground'
                  : isActive ? 'border-primary text-primary bg-primary/10'
                  : 'border-muted-foreground/30 text-muted-foreground/40'
                )}>
                  {isDone
                    ? <Check className="h-3.5 w-3.5" />
                    : isActive
                    ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    : <Icon className="h-3.5 w-3.5" />}
                </div>
                <span className={cn(
                  'text-[10px] font-medium text-center leading-tight whitespace-nowrap px-0.5',
                  isDone || isActive ? 'text-primary' : 'text-muted-foreground/50'
                )}>{label}</span>
              </div>
              {idx < pipelineStages.length - 1 && (
                <div className={cn(
                  'h-0.5 flex-1 mx-1 mb-5 transition-colors shrink-0',
                  activeIdx > idx ? 'bg-primary' : 'bg-muted-foreground/20'
                )} />
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* 失败提示 */}
      {job.status === 'failed' && job.error_msg && (
        <div className="flex items-start gap-2 p-2 bg-destructive/10 border border-destructive/30 text-xs text-destructive">
          <AlertCircle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
          <span className="text-pretty">{job.error_msg}</span>
        </div>
      )}
    </div>
  );
}

export default function ContentInputPage() {
  const { t } = useLang();

  // 管道阶段配置（依赖 t，必须在组件内定义）
  const PIPELINE_STAGES: PipelineStageConfig[] = [
    { key: 'uploading_bos',  label: t.contentInput.pipelineStage0Label, icon: Cloud,       desc: t.contentInput.pipelineStage0Desc },
    { key: 'asr_processing', label: t.contentInput.pipelineStage1Label, icon: Cpu,         desc: t.contentInput.pipelineStage1Desc },
    { key: 'formatting',     label: t.contentInput.pipelineStage2Label, icon: Sparkles,    desc: t.contentInput.pipelineStage2Desc },
    { key: 'done',           label: t.contentInput.pipelineStage3Label, icon: DatabaseZap, desc: t.contentInput.pipelineStage3Desc },
  ];

  const VIDEO_STAGES: { key: VideoStage; label: string; icon: React.ElementType }[] = [
    { key: 'uploading',    label: t.contentInput.videoStageUpload,    icon: Cloud },
    { key: 'transcribing', label: t.contentInput.videoStageTranscribe, icon: Mic },
    { key: 'formatting',   label: t.contentInput.videoStageFormatContent, icon: Sparkles },
  ];
  const [mode, setMode] = useState<InputMode>('text');
  const [videoSubMode, setVideoSubMode] = useState<VideoSubMode>('upload');
  const [textInput, setTextInput] = useState('');
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState('');
  const [weixinText, setWeixinText] = useState('');
  const [docFile, setDocFile] = useState<File | null>(null);
  const [doExtractTopic, setDoExtractTopic] = useState(false);
  const [doAddKnowledge, setDoAddKnowledge] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [videoStage, setVideoStage] = useState<VideoStage>('idle');
  const [result, setResult] = useState<ProcessedResult | null>(null);
  const [editedMarkdown, setEditedMarkdown] = useState('');
  const [showTranscript, setShowTranscript] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [confirmCooldown, setConfirmCooldown] = useState(false);
  const videoRef = useRef<HTMLInputElement>(null);
  const docRef = useRef<HTMLInputElement>(null);

  // YouTube 被 bot 拦截时的兜底状态
  const [youtubeBlockedUrl, setYoutubeBlockedUrl] = useState<string | null>(null);
  const [youtubePasteText, setYoutubePasteText] = useState('');

  // 视频管道状态（URL 子模式）
  const [pipelineJob, setPipelineJob] = useState<VideoPipelineJob | null>(null);
  const pipelineChannelRef = useRef<ReturnType<typeof videoPipelineService.subscribeJob> | null>(null);

  // 清理 Realtime 订阅
  useEffect(() => {
    return () => {
      if (pipelineChannelRef.current) {
        supabase.removeChannel(pipelineChannelRef.current);
        pipelineChannelRef.current = null;
      }
    };
  }, []);

  // 当管道完成时，把结果填入 result
  useEffect(() => {
    if (!pipelineJob) return;
    if (pipelineJob.status === 'completed' && pipelineJob.markdown) {
      setResult({
        markdown: pipelineJob.markdown,
        transcript: pipelineJob.transcript ?? undefined,
        srt: pipelineJob.srt_content ?? undefined,
        sourceType: 'video',
        fileName: t.contentInput.onlineVideo,
      });
      setEditedMarkdown(pipelineJob.markdown);
      setProcessing(false);
      setVideoStage('done');
      toast.success(t.contentInput.toastVideoProcessed);
    } else if (pipelineJob.status === 'failed') {
      setProcessing(false);
      setVideoStage('idle');
      toast.error(t.contentInput.toastVideoFailed.replace('{msg}', pipelineJob.error_msg ?? t.common.error));
    }
  }, [pipelineJob, t]);

  // 启动视频处理管道（URL 子模式）
  const startVideoPipeline = async (url: string) => {
    setProcessing(true);
    setPipelineJob(null);
    setResult(null);
    setVideoStage('transcribing');
    setYoutubeBlockedUrl(null);

    // 清理旧订阅
    if (pipelineChannelRef.current) {
      supabase.removeChannel(pipelineChannelRef.current);
      pipelineChannelRef.current = null;
    }

    const { data, error } = await supabase.functions.invoke('video-pipeline', {
      body: { video_url: url, title: t.contentInput.onlineVideo },
    });

    if (error) {
      const rawText = await error?.context?.text?.();
      setProcessing(false);
      setVideoStage('idle');
      // 尝试解析结构化错误
      try {
        const parsed = JSON.parse(rawText ?? '{}') as { error_code?: string };
        if (parsed.error_code === 'YOUTUBE_BLOCKED') {
          setYoutubeBlockedUrl(url);
          return; // 不 throw，前端展示兜底 UI
        }
      } catch { /* 不是 JSON，走普通错误路径 */ }
      throw new Error(rawText || error.message);
    }

    // 422 with YOUTUBE_BLOCKED (data 路径)
    const anyData = data as { error_code?: string; status?: string; markdown?: string; transcript?: string; srt?: string; transcript_source?: string; job_id?: string } | null;
    if (anyData?.error_code === 'YOUTUBE_BLOCKED') {
      setProcessing(false);
      setVideoStage('idle');
      setYoutubeBlockedUrl(url);
      return;
    }

    const resp = anyData;
    if (!resp) { setProcessing(false); setVideoStage('idle'); return; }

    // 新版函数同步返回已完成结果
    if (resp.status === 'completed' && resp.markdown) {
      setResult({
        markdown: resp.markdown,
        transcript: resp.transcript,
        srt: resp.srt,
        sourceType: 'video',
        fileName: t.contentInput.onlineVideo,
      });
      setEditedMarkdown(resp.markdown);
      setProcessing(false);
      setVideoStage('done');
      return;
    }

    // 兜底：异步任务 → 订阅 Realtime 等待更新（旧路径兼容）
    if (resp.job_id) {
      const job = await videoPipelineService.getJob(resp.job_id);
      if (job) setPipelineJob(job);

      pipelineChannelRef.current = videoPipelineService.subscribeJob(resp.job_id, (updated) => {
        setPipelineJob(updated);
      });
    }
  };

  const handleProcess = async () => {
    if (!doExtractTopic && !doAddKnowledge) {
      toast.error(t.contentInput.toastNeedAction);
      return;
    }

    setProcessing(true);
    setResult(null);
    setVideoStage('idle');

    try {
      let markdown = '';
      let transcript: string | undefined;
      let sourceType: SourceType = 'text';
      let fileName: string | undefined;

      if (mode === 'text') {
        if (!textInput.trim()) { toast.error(t.contentInput.errorEmptyText); return; }
        const { data, error } = await supabase.functions.invoke('process-content', {
          body: { type: 'text', content: textInput },
        });
        if (error) { const msg = await error?.context?.text?.(); throw new Error(msg || error.message); }
        markdown = (data as { markdown: string }).markdown;
        sourceType = 'text';

      } else if (mode === 'video') {

        if (videoSubMode === 'upload') {
          if (!videoFile) { toast.error(t.contentInput.errorNoVideo); return; }
          setVideoStage('uploading');
          const filePath = `videos/${Date.now()}_${videoFile.name.replace(/\s+/g, '_')}`;
          const { error: uploadError } = await supabase.storage
            .from('content-uploads')
            .upload(filePath, videoFile, { contentType: videoFile.type });
          if (uploadError) throw uploadError;
          const { data: urlData } = supabase.storage.from('content-uploads').getPublicUrl(filePath);

          setVideoStage('transcribing');
          const { data, error } = await supabase.functions.invoke('process-content', {
            body: { type: 'video', fileUrl: urlData.publicUrl, fileName: videoFile.name },
          });
          if (error) { const msg = await error?.context?.text?.(); throw new Error(msg || error.message); }
          setVideoStage('formatting');
          markdown = (data as { markdown: string; transcript?: string }).markdown;
          transcript = (data as { transcript?: string }).transcript;
          sourceType = 'video';
          fileName = videoFile.name;
          setVideoStage('done');

        } else if (videoSubMode === 'url') {
          // ── URL 子模式：交给 startVideoPipeline，handleProcess 提前返回 ──
          const url = videoUrl.trim();
          if (!url) { toast.error(t.contentInput.errorNoUrl); setProcessing(false); return; }
          if (!isValidUrl(url)) { toast.error(t.contentInput.errorInvalidUrl); setProcessing(false); return; }
          await startVideoPipeline(url);
          return; // 结果通过 useEffect 异步回填

        } else {
          if (!weixinText.trim()) { toast.error(t.contentInput.errorNoWeixin); return; }
          const { data, error } = await supabase.functions.invoke('process-content', {
            body: { type: 'text', content: weixinText },
          });
          if (error) { const msg = await error?.context?.text?.(); throw new Error(msg || error.message); }
          markdown = (data as { markdown: string }).markdown;
          sourceType = 'video';
          fileName = t.contentInput.videoSubWeixin;
        }

      } else {
        if (!docFile) { toast.error(t.contentInput.errorNoDoc); return; }
        const text = await docFile.text();
        const { data, error } = await supabase.functions.invoke('process-content', {
          body: { type: 'document', content: text, fileName: docFile.name },
        });
        if (error) { const msg = await error?.context?.text?.(); throw new Error(msg || error.message); }
        markdown = (data as { markdown: string }).markdown;
        sourceType = 'document';
        fileName = docFile.name;
      }

      setResult({ markdown, transcript, sourceType, fileName });
      setEditedMarkdown(markdown);
      setShowTranscript(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('429') || msg.includes('频率超限')) {
        toast.error(t.contentInput.errorRateLimit, { duration: 5000 });
      } else if (msg.includes('402') || msg.includes('余额不足')) {
        toast.error(t.contentInput.errorQuota, { duration: 8000 });
      } else {
        toast.error(`${t.contentInput.errorProcessFail}：${msg}`);
      }
    } finally {
      setProcessing(false);
      setVideoStage('idle');
    }
  };

  const handleConfirm = async () => {
    if (!result || confirmCooldown) return;
    setConfirming(true);
    try {
      const title = extractTitle(editedMarkdown) || result.fileName || t.contentInput.unnamedContent;

      if (doAddKnowledge) {
        const candidates = await knowledgeService.findSimilar(title);
        const similar = candidates.filter((c) => {
          const wa = new Set(c.title.toLowerCase().split(/[\s\-_,，【】（）()]+/).filter((w) => w.length >= 2));
          const wb = new Set(title.toLowerCase().split(/[\s\-_,，【】（）()]+/).filter((w) => w.length >= 2));
          const hit = [...wa].filter((w) => wb.has(w)).length;
          return hit / Math.max(wa.size, wb.size) >= 0.5;
        });

        if (similar.length > 0) {
          const target = similar[0];
          const section = `## ${t.contentInput.supplementContent}（${new Date().toLocaleDateString('zh-CN')}）\n\n${editedMarkdown}`;
          await knowledgeService.appendContent(target.id, section);
          toast.success(t.contentInput.toastMerged.replace('{title}', target.title), { duration: 4000 });
        } else {
          await knowledgeService.create({
            title,
            content: editedMarkdown,
            source_type: result.sourceType,
            original_content: result.markdown,
          });
          toast.success(t.contentInput.toastKbSaved);
        }
      }

      if (doExtractTopic) {
        const { data, error } = await supabase.functions.invoke('extract-topics', {
          body: { content: editedMarkdown },
        });
        if (error) { const msg = await error?.context?.text?.(); throw new Error(msg || error.message); }
        const topics = (data as { topics: Array<{ title: string; description: string }> }).topics;
        for (const tp of topics) {
          await topicService.create({ title: tp.title, description: tp.description, source_content: editedMarkdown });
        }
        toast.success(t.contentInput.toastTopicsExtracted.replace('{n}', String(topics.length)));
      }

      setResult(null);
      setEditedMarkdown('');
      setTextInput('');
      setVideoFile(null);
      setVideoUrl('');
      setWeixinText('');
      setDocFile(null);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('429') || msg.includes('频率超限')) {
        toast.error(t.contentInput.errorRateLimit, { duration: 6000 });
        setConfirmCooldown(true);
        setTimeout(() => setConfirmCooldown(false), 8000);
      } else if (msg.includes('402') || msg.includes('余额不足')) {
        toast.error(t.contentInput.errorQuota, { duration: 8000 });
      } else {
        toast.error(`${t.contentInput.errorConfirmFail}：${msg}`);
      }
    } finally {
      setConfirming(false);
    }
  };

  function extractTitle(md: string): string {
    const match = /^#\s+(.+)/m.exec(md);
    return match ? match[1].trim() : md.slice(0, 40).replace(/\n/g, ' ');
  }

  // YouTube 兜底：用粘贴的文字稿继续处理
  const handleYoutubePastedText = async () => {
    if (!youtubePasteText.trim()) { toast.error(t.contentInput.ytNoPasteError); return; }
    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('process-content', {
        body: { type: 'text', content: youtubePasteText },
      });
      if (error) { const msg = await error?.context?.text?.(); throw new Error(msg || error.message); }
      const markdown = (data as { markdown: string }).markdown;
      setResult({ markdown, sourceType: 'video', fileName: t.contentInput.onlineVideo });
      setEditedMarkdown(markdown);
      setYoutubeBlockedUrl(null);
      setYoutubePasteText('');
      toast.success(t.contentInput.toastTranscriptDone);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast.error(t.contentInput.toastTranscriptFail.replace('{msg}', msg));
    } finally {
      setProcessing(false);
    }
  };

  const modes: { id: InputMode; label: string; icon: React.ElementType }[] = [
    { id: 'text',     label: t.contentInput.modeText,     icon: Type },
    { id: 'video',    label: t.contentInput.modeVideo,    icon: Video },
    { id: 'document', label: t.contentInput.modeDocument, icon: FileText },
  ];

  const videoSubModes: { id: VideoSubMode; label: string; icon: React.ElementType }[] = [
    { id: 'upload', label: t.contentInput.videoSubUpload, icon: Upload },
    { id: 'url',    label: t.contentInput.videoSubUrl,    icon: Link2 },
    { id: 'weixin', label: t.contentInput.videoSubWeixin, icon: Share2 },
  ];

  const videoStageLabels: Record<VideoStage, string> = {
    idle: '',
    uploading:    t.contentInput.stageUpload,
    transcribing: t.contentInput.stageTranscribe,
    formatting:   t.contentInput.stageFormat,
    done: '',
  }; // kept for compatibility — VIDEO_STAGES.find() is the primary lookup now

  // 当前激活的处理阶段（用于进度条渲染）
  const activeStageIdx = VIDEO_STAGES.findIndex((s) => s.key === videoStage);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground text-balance">{t.contentInput.pageTitle}</h1>
        <p className="text-sm text-muted-foreground mt-1 text-pretty">{t.contentInput.pageDesc}</p>
      </div>

      <div className="space-y-6">
        {/* 输入方式选择 */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">{t.contentInput.modeText}/{t.contentInput.modeVideo}/{t.contentInput.modeDocument}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-3">
              {modes.map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => { setMode(id); setResult(null); setVideoStage('idle'); }}
                  className={cn(
                    'flex flex-col items-center gap-2 p-4 border transition-colors duration-150',
                    mode === id
                      ? 'border-primary bg-primary/5 text-primary'
                      : 'border-border hover:border-primary/40 hover:bg-muted text-foreground'
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span className="text-sm font-medium">{label}</span>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* 输入区域 */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">
              {mode === 'text' ? t.contentInput.modeText : mode === 'video' ? t.contentInput.modeVideo : t.contentInput.modeDocument}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">

            {/* 文本 */}
            {mode === 'text' && (
              <Textarea
                placeholder={t.contentInput.textPlaceholder}
                className="min-h-48 resize-y font-mono text-sm"
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
              />
            )}

            {/* 视频 */}
            {mode === 'video' && (
              <>
                {/* 子模式 Tab */}
                <div className="flex border border-border divide-x divide-border overflow-hidden">
                  {videoSubModes.map(({ id, label, icon: Icon }) => (
                    <button
                      key={id}
                      onClick={() => setVideoSubMode(id)}
                      className={cn(
                        'flex-1 flex items-center justify-center gap-1.5 py-2.5 text-sm font-medium transition-colors',
                        videoSubMode === id
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-card text-muted-foreground hover:bg-muted hover:text-foreground'
                      )}
                    >
                      <Icon className="h-3.5 w-3.5 shrink-0" />
                      <span>{label}</span>
                    </button>
                  ))}
                </div>

                {/* 本地上传 */}
                {videoSubMode === 'upload' && (
                  <div
                    className={cn(
                      'border-2 border-dashed rounded-sm p-8 text-center cursor-pointer transition-colors',
                      videoFile ? 'border-primary/60 bg-primary/5' : 'border-border hover:border-primary/40'
                    )}
                    onClick={() => videoRef.current?.click()}
                  >
                    <input
                      ref={videoRef}
                      type="file"
                      accept="video/*,.mp4,.mov,.avi,.mkv,.webm"
                      className="hidden"
                      onChange={(e) => setVideoFile(e.target.files?.[0] ?? null)}
                    />
                    {videoFile ? (
                      <div className="flex flex-col items-center gap-2">
                        <Check className="h-8 w-8 text-primary" />
                        <p className="font-medium text-foreground">{videoFile.name}</p>
                        <p className="text-sm text-muted-foreground">{(videoFile.size / 1024 / 1024).toFixed(1)} MB</p>
                        <Badge variant="secondary">{t.common.confirm}</Badge>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-2">
                        <Upload className="h-8 w-8 text-muted-foreground" />
                        <p className="font-medium text-foreground">{t.contentInput.uploadBtn}</p>
                        <p className="text-sm text-muted-foreground">{t.contentInput.uploadFormats}</p>
                        <p className="text-xs text-muted-foreground">{t.contentInput.uploadDrop}</p>
                      </div>
                    )}
                  </div>
                )}

                {/* 视频链接 */}
                {videoSubMode === 'url' && (
                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <Input
                        placeholder={t.contentInput.videoUrlPlaceholder}
                        value={videoUrl}
                        onChange={(e) => { setVideoUrl(e.target.value); setYoutubeBlockedUrl(null); }}
                        className="flex-1 font-mono text-sm"
                      />
                      {videoUrl && (
                        <Button size="sm" variant="ghost" onClick={() => { setVideoUrl(''); setYoutubeBlockedUrl(null); }} className="shrink-0 px-2">✕</Button>
                      )}
                    </div>

                    {/* YouTube 被拦截的兜底 UI */}
                    {youtubeBlockedUrl && !processing && (
                      <div className="border border-amber-500/40 bg-amber-500/5 rounded-sm p-4 space-y-4">
                        {/* 标题 */}
                        <div className="flex items-start gap-2.5">
                          <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                          <div>
                            <p className="text-sm font-medium text-foreground">{t.contentInput.ytBlockedTitle}</p>
                            <p className="text-xs text-muted-foreground mt-0.5 text-pretty">
                              {t.contentInput.ytBlockedDesc}
                            </p>
                          </div>
                        </div>

                        <Separator />

                        {/* 方式一：粘贴文字稿 */}
                        <div className="space-y-2">
                          <div className="flex items-center gap-1.5">
                            <ClipboardPaste className="h-3.5 w-3.5 text-primary shrink-0" />
                            <span className="text-xs font-semibold text-foreground">{t.contentInput.ytMethod1Title}</span>
                          </div>
                          <div className="p-3 bg-muted/60 rounded-sm border border-border text-xs text-muted-foreground space-y-1">
                            <p className="font-medium text-foreground">{t.contentInput.ytMethod1HowTo}</p>
                            <ol className="list-decimal list-inside space-y-0.5 text-pretty">
                              <li>{t.contentInput.ytMethod1Step1}</li>
                              <li>{t.contentInput.ytMethod1Step2}</li>
                              <li>{t.contentInput.ytMethod1Step3}</li>
                              <li>{t.contentInput.ytMethod1Step4}</li>
                            </ol>
                            <a
                              href={youtubeBlockedUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-primary hover:underline mt-1"
                            >
                              <ExternalLink className="h-3 w-3" />
                              {t.contentInput.ytOpenLink}
                            </a>
                          </div>
                          <Textarea
                            placeholder={t.contentInput.ytPastePlaceholder}
                            className="min-h-32 resize-y text-sm font-mono"
                            value={youtubePasteText}
                            onChange={(e) => setYoutubePasteText(e.target.value)}
                          />
                          {youtubePasteText.trim() && (
                            <Button
                              size="sm"
                              onClick={handleYoutubePastedText}
                              disabled={processing}
                              className="w-full"
                            >
                              {processing ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> : <Sparkles className="h-3.5 w-3.5 mr-1.5" />}
                              {t.contentInput.ytProcessBtn}
                            </Button>
                          )}
                        </div>

                        <Separator />

                        {/* 方式二：切换到上传 */}
                        <div className="space-y-2">
                          <div className="flex items-center gap-1.5">
                            <Upload className="h-3.5 w-3.5 text-primary shrink-0" />
                            <span className="text-xs font-semibold text-foreground">{t.contentInput.ytMethod2Title}</span>
                          </div>
                          <p className="text-xs text-muted-foreground text-pretty">
                            {t.contentInput.ytMethod2Desc}
                          </p>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => { setVideoSubMode('upload'); setYoutubeBlockedUrl(null); }}
                            className="w-full"
                          >
                            <Upload className="h-3.5 w-3.5 mr-1.5" />
                            {t.contentInput.ytSwitchUpload}
                          </Button>
                        </div>
                      </div>
                    )}

                    {/* 视频处理进度（处理中） */}
                    {processing && pipelineJob && (
                      <VideoPipelineProgress
                        job={pipelineJob}
                        pipelineStages={PIPELINE_STAGES}
                        processingLabel={t.contentInput.pipelineProcessing}
                      />
                    )}

                    {/* 静态流程说明（未处理时且无错误） */}
                    {!processing && !youtubeBlockedUrl && (
                      <>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                          {PIPELINE_STAGES.map(({ key, label, icon: Icon, desc }) => (
                            <div key={key} className="flex flex-col gap-1.5 p-3 border border-border bg-muted/30">
                              <div className="flex items-center gap-1.5">
                                <Icon className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                                <span className="text-xs font-medium text-foreground truncate">{label}</span>
                              </div>
                              <span className="text-[11px] text-muted-foreground leading-snug text-pretty">{desc}</span>
                            </div>
                          ))}
                        </div>
                        <div className="flex items-start gap-2 p-3 bg-muted/50 border border-border text-xs text-muted-foreground">
                          <Info className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                          <p className="text-pretty">{t.contentInput.ytInfoHint}</p>
                        </div>
                      </>
                    )}
                  </div>
                )}

                {/* 视频号分享 */}
                {videoSubMode === 'weixin' && (
                  <div className="space-y-3">
                    <Textarea
                      placeholder={t.contentInput.weixinPlaceholder}
                      className="min-h-40 resize-y text-sm"
                      value={weixinText}
                      onChange={(e) => setWeixinText(e.target.value)}
                    />
                    <div className="flex items-start gap-2 p-3 bg-blue-50 border border-blue-200 text-xs text-blue-700">
                      <Share2 className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                      <p className="text-pretty">{t.contentInput.weixinHint}</p>
                    </div>
                  </div>
                )}

                {/* 上传模式进度条（仅 upload 子模式） */}
                {processing && mode === 'video' && videoSubMode === 'upload' && videoStage !== 'idle' && (
                  <div className="border border-border bg-muted/20 p-4">
                    <p className="text-xs text-muted-foreground mb-3 font-medium">{t.contentInput.processing}</p>
                    <div className="flex items-center gap-0">
                      {VIDEO_STAGES.map(({ key, label, icon: Icon }, idx) => {
                        const isDone = activeStageIdx > idx;
                        const isActive = activeStageIdx === idx;
                        return (
                          <React.Fragment key={key}>
                            <div className="flex flex-col items-center gap-1.5 flex-1">
                              <div className={cn(
                                'h-9 w-9 flex items-center justify-center border-2 transition-colors',
                                isDone  ? 'border-primary bg-primary text-primary-foreground' :
                                isActive ? 'border-primary text-primary bg-primary/10' :
                                          'border-muted-foreground/30 text-muted-foreground/40'
                              )}>
                                {isDone
                                  ? <Check className="h-4 w-4" />
                                  : isActive
                                  ? <Loader2 className="h-4 w-4 animate-spin" />
                                  : <Icon className="h-4 w-4" />
                                }
                              </div>
                              <span className={cn(
                                'text-[11px] font-medium whitespace-nowrap',
                                isDone || isActive ? 'text-primary' : 'text-muted-foreground/50'
                              )}>{label}</span>
                            </div>
                            {idx < VIDEO_STAGES.length - 1 && (
                              <div className={cn(
                                'h-0.5 flex-1 mx-1 mb-5 transition-colors',
                                activeStageIdx > idx ? 'bg-primary' : 'bg-muted-foreground/20'
                              )} />
                            )}
                          </React.Fragment>
                        );
                      })}
                    </div>
                  </div>
                )}
              </>
            )}

            {/* 文档 */}
            {mode === 'document' && (
              <div
                className={cn(
                  'border-2 border-dashed rounded-sm p-8 text-center cursor-pointer transition-colors',
                  docFile ? 'border-primary/60 bg-primary/5' : 'border-border hover:border-primary/40'
                )}
                onClick={() => docRef.current?.click()}
              >
                <input
                  ref={docRef}
                  type="file"
                  accept=".pdf,.doc,.docx,.txt,.md"
                  className="hidden"
                  onChange={(e) => setDocFile(e.target.files?.[0] ?? null)}
                />
                {docFile ? (
                  <div className="flex flex-col items-center gap-2">
                    <Check className="h-8 w-8 text-primary" />
                    <p className="font-medium text-foreground">{docFile.name}</p>
                    <p className="text-sm text-muted-foreground">{(docFile.size / 1024).toFixed(1)} KB</p>
                    <Badge variant="secondary">{t.common.confirm}</Badge>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2">
                    <FileText className="h-8 w-8 text-muted-foreground" />
                    <p className="font-medium text-foreground">{t.contentInput.docUploadBtn}</p>
                    <p className="text-sm text-muted-foreground">{t.contentInput.docFormats}</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* 操作选项 */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">{t.contentInput.optExtractTopic} / {t.contentInput.optAddKnowledge}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <label className="flex items-start gap-3 p-4 border border-border cursor-pointer hover:bg-muted/50 flex-1 transition-colors">
                <Checkbox checked={doExtractTopic} onCheckedChange={(v) => setDoExtractTopic(!!v)} className="mt-0.5" />
                <div className="min-w-0">
                  <p className="font-medium text-foreground">{t.contentInput.optExtractTopic}</p>
                  <p className="text-sm text-muted-foreground text-pretty">
                    {t.contentInput.stageFormat}
                  </p>
                </div>
              </label>
              <label className="flex items-start gap-3 p-4 border border-border cursor-pointer hover:bg-muted/50 flex-1 transition-colors">
                <Checkbox checked={doAddKnowledge} onCheckedChange={(v) => setDoAddKnowledge(!!v)} className="mt-0.5" />
                <div className="min-w-0">
                  <p className="font-medium text-foreground">{t.contentInput.optAddKnowledge}</p>
                  <p className="text-sm text-muted-foreground text-pretty">
                    {t.contentInput.editHint}
                  </p>
                </div>
              </label>
            </div>
            {!doExtractTopic && !doAddKnowledge && (
              <div className="flex items-center gap-2 mt-3 p-3 bg-amber-50 border border-amber-200 text-amber-700 text-sm">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{t.contentInput.errorTooShort}</span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 处理按钮 */}
        <Button
          onClick={handleProcess}
          disabled={processing || (!doExtractTopic && !doAddKnowledge)}
          className="w-full"
          size="lg"
        >
          {processing ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
              {mode === 'video' && videoSubMode === 'url'
                ? (pipelineJob?.stage_label ?? t.contentInput.pipelineProcessing)
                : (VIDEO_STAGES.find(s => s.key === videoStage)?.label || t.contentInput.processing)}
            </>
          ) : (
            <>
              <CheckSquare className="h-4 w-4 mr-2" />
              {t.contentInput.processBtn}
            </>
          )}
        </Button>

        {/* 结果校验区 */}
        {result && (
          <>
            <Separator />
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between gap-4">
                  <CardTitle className="text-base">{t.contentInput.resultTitle}</CardTitle>
                  <Badge variant="outline" className="shrink-0">
                    {result.sourceType === 'video'
                      ? (videoSubMode === 'weixin' ? t.contentInput.videoSubWeixin : t.contentInput.modeVideo)
                      : result.sourceType === 'document' ? t.contentInput.modeDocument : t.contentInput.modeText}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* 原始转录展开区 */}
                {result.transcript && (
                  <div className="border border-border">
                    <button
                      onClick={() => setShowTranscript((v) => !v)}
                      className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium text-muted-foreground hover:bg-muted/50 transition-colors"
                    >
                      <span className="flex items-center gap-2">
                        <Mic className="h-3.5 w-3.5" />
                        {t.contentInput.transcriptTitle}（{result.transcript.length}）{t.contentInput.transcriptHint}
                      </span>
                      {showTranscript
                        ? <ChevronUp className="h-3.5 w-3.5 shrink-0" />
                        : <ChevronDown className="h-3.5 w-3.5 shrink-0" />}
                    </button>
                    {showTranscript && (
                      <div className="px-3 pb-3 pt-1 border-t border-border">
                        <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap font-mono bg-muted/30 p-3 max-h-48 overflow-y-auto">
                          {result.transcript}
                        </p>
                      </div>
                    )}
                  </div>
                )}

                <EditableMarkdown value={editedMarkdown} onChange={setEditedMarkdown} />
                <p className="text-xs text-muted-foreground">{t.contentInput.editHint}</p>

                {/* SRT 字幕下载（Whisper 转写时可用） */}
                {result.srt && (
                  <div className="flex items-center gap-2 p-2.5 border border-border bg-muted/30 text-xs">
                    <Mic className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                    <span className="text-muted-foreground flex-1">{t.contentInput.srtReady}</span>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 text-xs px-2"
                      onClick={() => {
                        const blob = new Blob([result.srt!], { type: 'text/srt;charset=utf-8' });
                        const a = document.createElement('a');
                        a.href = URL.createObjectURL(blob);
                        a.download = `subtitle_${Date.now()}.srt`;
                        a.click();
                        URL.revokeObjectURL(a.href);
                      }}
                    >
                      {t.contentInput.downloadSrt}
                    </Button>
                  </div>
                )}

                <div className="flex gap-3">
                  <Button onClick={handleConfirm} disabled={confirming || confirmCooldown} className="flex-1">
                    {confirming ? (
                      <><Loader2 className="h-4 w-4 animate-spin mr-2" />{t.contentInput.confirming}</>
                    ) : confirmCooldown ? (
                      <><Loader2 className="h-4 w-4 animate-spin mr-2" />{t.contentInput.confirming}</>
                    ) : (
                      <><Check className="h-4 w-4 mr-2" />{t.contentInput.confirmBtn}</>
                    )}
                  </Button>
                  <Button variant="outline" onClick={() => setResult(null)}>{t.common.cancel}</Button>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}
