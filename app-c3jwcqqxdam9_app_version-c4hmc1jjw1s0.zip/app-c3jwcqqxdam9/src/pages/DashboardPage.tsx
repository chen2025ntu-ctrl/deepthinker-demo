import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Upload, BookOpen, Search, FileText, BarChart3,
  TrendingUp, Layers, ArrowRight, Loader2,
  FolderOpen, FlaskConical, Sparkles,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend,
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
} from 'recharts';
import {
  knowledgeService, topicService, evidenceCardService, reportService,
} from '@/services/database';
import type { KnowledgeItem, Topic, EvidenceCard, ResearchReport } from '@/types/types';
import { useLang } from '@/contexts/LangContext';
import { cn } from '@/lib/utils';

// ─── animated counter ───────────────────────────────────────────────────────
function AnimatedNumber({ value, duration = 900 }: { value: number; duration?: number }) {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    const start = performance.now();
    const from = 0;
    const raf = (ts: number) => {
      const k = Math.min(1, (ts - start) / duration);
      const ease = 1 - Math.pow(1 - k, 3);
      setDisplay(Math.round(from + (value - from) * ease));
      if (k < 1) requestAnimationFrame(raf);
    };
    requestAnimationFrame(raf);
  }, [value, duration]);
  return <>{display.toLocaleString()}</>;
}

// ─── stat card ───────────────────────────────────────────────────────────────
interface StatCardProps {
  label: string;
  value: number;
  subLabel?: string;
  subValue?: string | number;
  icon: React.ElementType;
  accent?: string;
  loading?: boolean;
}
function StatCard({ label, value, subLabel, subValue, icon: Icon, accent = 'text-primary', loading }: StatCardProps) {
  return (
    <Card className="h-full flex flex-col hover:-translate-y-0.5 transition-transform duration-200">
      <CardContent className="p-5 flex flex-col gap-3 flex-1">
        <div className="flex items-start justify-between">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{label}</p>
          <span className={cn('p-1.5 rounded-md bg-muted/60', accent)}>
            <Icon className="h-3.5 w-3.5" />
          </span>
        </div>
        <div className="flex-1">
          {loading ? (
            <Skeleton className="h-9 w-20 bg-muted" />
          ) : (
            <p className="text-3xl font-bold text-foreground tabular-nums leading-none">
              <AnimatedNumber value={value} />
            </p>
          )}
        </div>
        {subLabel && (
          <p className="text-xs text-muted-foreground">
            {subLabel}
            {subValue !== undefined && (
              <span className="font-semibold text-foreground ml-1">{subValue}</span>
            )}
          </p>
        )}
      </CardContent>
    </Card>
  );
}

// ─── quick action card ────────────────────────────────────────────────────────
interface QuickActionProps {
  label: string;
  desc: string;
  icon: React.ElementType;
  to: string;
  accent: string;
}
function QuickAction({ label, desc, icon: Icon, to, accent }: QuickActionProps) {
  const navigate = useNavigate();
  return (
    <button
      onClick={() => navigate(to)}
      className="flex items-center gap-3 p-4 rounded-lg border border-border bg-card hover:border-primary/40 hover:bg-muted/30 transition-all duration-200 text-left group w-full"
    >
      <span className={cn('p-2 rounded-md shrink-0', accent)}>
        <Icon className="h-4 w-4" />
      </span>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-foreground text-balance">{label}</p>
        <p className="text-xs text-muted-foreground mt-0.5 text-pretty">{desc}</p>
      </div>
      <ArrowRight className="h-3.5 w-3.5 text-muted-foreground group-hover:text-primary group-hover:translate-x-0.5 transition-all duration-200 shrink-0" />
    </button>
  );
}

// ─── topic status badge ───────────────────────────────────────────────────────
function TopicBadge({ status }: { status: Topic['status'] }) {
  const { t } = useLang();
  const cfg: Record<Topic['status'], { label: string; cls: string }> = {
    pending: { label: t.research.statusPending, cls: 'bg-muted text-muted-foreground' },
    researching: { label: t.dashboard.topicResearching, cls: 'bg-blue-50 text-blue-600 border-blue-200' },
    completed: { label: t.dashboard.topicCompleted, cls: 'bg-emerald-50 text-emerald-600 border-emerald-200' },
  };
  const c = cfg[status] ?? cfg.pending;
  return <Badge variant="outline" className={cn('text-[10px]', c.cls)}>{c.label}</Badge>;
}

// ─── report status badge ──────────────────────────────────────────────────────
function ReportBadge({ status }: { status: ResearchReport['status'] }) {
  const { t } = useLang();
  const cfg: Record<ResearchReport['status'], { label: string; cls: string }> = {
    draft:      { label: t.dashboard.reportDraft,      cls: 'bg-muted text-muted-foreground' },
    generating: { label: t.reports.statusGenerating,   cls: 'bg-blue-50 text-blue-600 border-blue-200' },
    completed:  { label: t.dashboard.reportCompleted,  cls: 'bg-emerald-50 text-emerald-600 border-emerald-200' },
  };
  const c = cfg[status] ?? cfg.draft;
  return <Badge variant="outline" className={cn('text-[10px]', c.cls)}>{c.label}</Badge>;
}

// ─── custom tooltip for charts ────────────────────────────────────────────────
function CustomTooltip({ active, payload }: { active?: boolean; payload?: Array<{ name: string; value: number; fill: string }> }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-md px-3 py-2 shadow-md text-xs">
      <p className="font-semibold text-foreground">{payload[0].name}</p>
      <p className="text-muted-foreground">{payload[0].value}</p>
    </div>
  );
}

// ─── main component ───────────────────────────────────────────────────────────
export default function DashboardPage() {
  const { t, lang } = useLang();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [kbItems, setKbItems]     = useState<KnowledgeItem[]>([]);
  const [topics, setTopics]       = useState<Topic[]>([]);
  const [cards, setCards]         = useState<EvidenceCard[]>([]);
  const [reports, setReports]     = useState<ResearchReport[]>([]);

  const loadAll = useCallback(async () => {
    try {
      const [kb, tps, cds, rps] = await Promise.all([
        knowledgeService.list(),
        topicService.list(),
        evidenceCardService.listAll(),
        reportService.list(),
      ]);
      setKbItems(Array.isArray(kb) ? kb : []);
      setTopics(Array.isArray(tps) ? tps : []);
      setCards(Array.isArray(cds) ? cds : []);
      setReports(Array.isArray(rps) ? rps : []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void loadAll(); }, [loadAll]);

  // ── derived stats ──────────────────────────────────────────────────────────
  const archivedCards = cards.filter((c) => c.status === 'archived').length;
  const completedTopics = topics.filter((tp) => tp.status === 'completed').length;
  const completedReports = reports.filter((r) => r.status === 'completed').length;

  // dimension pie data
  const dimCounts = cards.reduce<Record<string, number>>((acc, c) => {
    acc[c.dimension] = (acc[c.dimension] ?? 0) + 1;
    return acc;
  }, {});
  const dimData = Object.entries(dimCounts).map(([key, val]) => ({
    name: t.dimension[key as keyof typeof t.dimension] ?? key,
    value: val,
  }));

  // knowledge source bar data
  const srcCounts = kbItems.reduce<Record<string, number>>((acc, k) => {
    acc[k.source_type] = (acc[k.source_type] ?? 0) + 1;
    return acc;
  }, {});
  const srcLabels: Record<string, string> = {
    video: t.dashboard.sourceVideo,
    text: t.dashboard.sourceText,
    document: t.dashboard.sourceDoc,
    evidence: t.dashboard.sourceEvidence,
  };
  const srcData = Object.entries(srcCounts).map(([key, val]) => ({
    name: srcLabels[key] ?? key,
    value: val,
  }));

  // card status bar data
  const cardStatusData = [
    { name: t.dashboard.cardsPending,  value: cards.filter((c) => c.status === 'pending').length },
    { name: t.dashboard.cardsArchived, value: cards.filter((c) => c.status === 'archived').length },
    { name: t.dashboard.cardsIgnored,  value: cards.filter((c) => c.status === 'ignored').length },
  ].filter((d) => d.value > 0);

  const PIE_COLORS = [
    'hsl(var(--chart-1))', 'hsl(var(--chart-2))',
    'hsl(var(--chart-3))', 'hsl(var(--chart-4))',
  ];
  const BAR_COLOR = 'hsl(var(--primary))';
  const BAR_COLOR2 = 'hsl(var(--chart-2))';

  const recentReports = reports.slice(0, 5);
  const recentTopics  = topics.slice(0, 5);

  const quickActions: QuickActionProps[] = [
    { label: t.dashboard.goContentInput, desc: t.nav.contentInput, icon: Upload,    to: '/',         accent: 'bg-primary/10 text-primary' },
    { label: t.dashboard.goResearch,     desc: t.nav.research,     icon: Search,    to: '/research', accent: 'bg-chart-2/10 text-chart-2' },
    { label: t.dashboard.goEvidence,     desc: t.nav.evidence,     icon: FileText,  to: '/evidence', accent: 'bg-chart-3/10 text-chart-3' },
    { label: t.dashboard.goReports,      desc: t.nav.reports,      icon: BarChart3, to: '/reports',  accent: 'bg-chart-4/10 text-chart-4' },
  ];

  return (
    <div className="p-4 md:p-6 space-y-6">

      {/* ── header ── */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-5 h-5 rounded-sm bg-primary flex items-center justify-center">
              <FlaskConical className="h-3 w-3 text-primary-foreground" />
            </div>
            <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">
              {lang === 'zh' ? '产学研智能研究平台' : 'Industry-Research Platform'}
            </p>
          </div>
          <h1 className="text-2xl font-bold text-foreground text-balance">{t.dashboard.pageTitle}</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{t.dashboard.pageDesc}</p>
        </div>
        <Button size="sm" onClick={() => navigate('/')} className="shrink-0">
          <Sparkles className="h-3.5 w-3.5 mr-1.5" />
          {t.dashboard.goContentInput}
        </Button>
      </div>

      {/* ── stat cards ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        <StatCard
          label={t.dashboard.statKbItems}
          value={kbItems.length}
          subLabel={t.dashboard.statAll}
          subValue={kbItems.length}
          icon={BookOpen}
          accent="text-primary"
          loading={loading}
        />
        <StatCard
          label={t.dashboard.statTopics}
          value={topics.length}
          subLabel={t.dashboard.statCompleted}
          subValue={completedTopics}
          icon={FolderOpen}
          accent="text-chart-2"
          loading={loading}
        />
        <StatCard
          label={t.dashboard.statCards}
          value={cards.length}
          subLabel={t.dashboard.statArchived}
          subValue={archivedCards}
          icon={FileText}
          accent="text-chart-3"
          loading={loading}
        />
        <StatCard
          label={t.dashboard.statReports}
          value={reports.length}
          subLabel={t.dashboard.statCompleted}
          subValue={completedReports}
          icon={BarChart3}
          accent="text-chart-4"
          loading={loading}
        />
      </div>

      {/* ── charts row ── */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">

        {/* evidence dimension pie */}
        <Card className="h-full">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-balance">{t.dashboard.evidenceDistrib}</CardTitle>
          </CardHeader>
          <CardContent className="pb-4">
            {loading ? (
              <Skeleton className="h-40 bg-muted" />
            ) : dimData.length === 0 ? (
              <div className="h-40 flex items-center justify-center text-xs text-muted-foreground">{t.dashboard.noActivity}</div>
            ) : (
              <div className="w-full min-w-0 overflow-hidden h-44">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={dimData} cx="50%" cy="44%" outerRadius={60} dataKey="value" stroke="none">
                      {dimData.map((_, i) => (
                        <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                    <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8, fontSize: 11 }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* knowledge source bar */}
        <Card className="h-full">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-balance">{t.dashboard.knowledgeDistrib}</CardTitle>
          </CardHeader>
          <CardContent className="pb-4">
            {loading ? (
              <Skeleton className="h-40 bg-muted" />
            ) : srcData.length === 0 ? (
              <div className="h-40 flex items-center justify-center text-xs text-muted-foreground">{t.dashboard.noActivity}</div>
            ) : (
              <div className="w-full min-w-0 overflow-hidden h-44">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={srcData} margin={{ top: 8, right: 8, left: -24, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                    <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} allowDecimals={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="value" fill={BAR_COLOR} radius={[3, 3, 0, 0]} maxBarSize={40} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* card status bar */}
        <Card className="h-full">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-balance">{t.dashboard.statusTitle}</CardTitle>
          </CardHeader>
          <CardContent className="pb-4">
            {loading ? (
              <Skeleton className="h-40 bg-muted" />
            ) : cardStatusData.length === 0 ? (
              <div className="h-40 flex items-center justify-center text-xs text-muted-foreground">{t.dashboard.noActivity}</div>
            ) : (
              <div className="w-full min-w-0 overflow-hidden h-44">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={cardStatusData} margin={{ top: 8, right: 8, left: -24, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                    <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} allowDecimals={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="value" fill={BAR_COLOR2} radius={[3, 3, 0, 0]} maxBarSize={40} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── recent lists + quick actions ── */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">

        {/* recent reports */}
        <Card className="h-full flex flex-col">
          <CardHeader className="pb-2 flex-row items-center justify-between">
            <CardTitle className="text-sm font-semibold">{t.dashboard.recentReports}</CardTitle>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-xs text-muted-foreground hover:text-primary" onClick={() => navigate('/reports')}>
              {lang === 'zh' ? '全部' : 'All'} <ArrowRight className="h-3 w-3 ml-1" />
            </Button>
          </CardHeader>
          <CardContent className="flex-1 pb-4">
            {loading ? (
              <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12 bg-muted" />)}</div>
            ) : recentReports.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 gap-2 text-muted-foreground">
                <BarChart3 className="h-7 w-7 opacity-30" />
                <p className="text-xs">{t.dashboard.noReports}</p>
              </div>
            ) : (
              <ul className="space-y-1">
                {recentReports.map((r) => (
                  <li key={r.id}
                    className="flex items-start gap-2 px-2 py-2 rounded-md hover:bg-muted/40 cursor-pointer transition-colors"
                    onClick={() => navigate('/reports')}
                  >
                    <TrendingUp className="h-3.5 w-3.5 text-chart-4 shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{r.title}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{new Date(r.created_at).toLocaleDateString()}</p>
                    </div>
                    <ReportBadge status={r.status} />
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        {/* recent topics */}
        <Card className="h-full flex flex-col">
          <CardHeader className="pb-2 flex-row items-center justify-between">
            <CardTitle className="text-sm font-semibold">{t.dashboard.recentTopics}</CardTitle>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-xs text-muted-foreground hover:text-primary" onClick={() => navigate('/research')}>
              {lang === 'zh' ? '全部' : 'All'} <ArrowRight className="h-3 w-3 ml-1" />
            </Button>
          </CardHeader>
          <CardContent className="flex-1 pb-4">
            {loading ? (
              <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12 bg-muted" />)}</div>
            ) : recentTopics.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 gap-2 text-muted-foreground">
                <Layers className="h-7 w-7 opacity-30" />
                <p className="text-xs">{t.dashboard.noTopics}</p>
              </div>
            ) : (
              <ul className="space-y-1">
                {recentTopics.map((tp) => (
                  <li key={tp.id}
                    className="flex items-start gap-2 px-2 py-2 rounded-md hover:bg-muted/40 cursor-pointer transition-colors"
                    onClick={() => navigate('/research')}
                  >
                    <Search className="h-3.5 w-3.5 text-chart-2 shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{tp.title}</p>
                      {tp.description && (
                        <p className="text-[10px] text-muted-foreground mt-0.5 truncate">{tp.description}</p>
                      )}
                    </div>
                    <TopicBadge status={tp.status} />
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        {/* quick actions */}
        <Card className="h-full flex flex-col">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">{t.dashboard.quickActions}</CardTitle>
          </CardHeader>
          <CardContent className="flex-1 pb-4">
            <div className="flex flex-col gap-2">
              {quickActions.map((a) => (
                <QuickAction key={a.to} {...a} />
              ))}
            </div>
          </CardContent>
        </Card>

      </div>

      {/* ── system overview strip ── */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">{t.dashboard.systemOverview}</CardTitle>
        </CardHeader>
        <CardContent className="pb-4">
          {loading ? (
            <div className="flex gap-6 flex-wrap">
              {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-6 w-32 bg-muted" />)}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { icon: BookOpen,   label: t.nav.knowledge, val: kbItems.length, color: 'text-primary' },
                { icon: Search,     label: t.nav.research,  val: topics.length,  color: 'text-chart-2' },
                { icon: FileText,   label: t.nav.evidence,  val: cards.length,   color: 'text-chart-3' },
                { icon: BarChart3,  label: t.nav.reports,   val: reports.length, color: 'text-chart-4' },
              ].map(({ icon: Icon, label, val, color }) => (
                <div key={label} className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 border border-border">
                  <Icon className={cn('h-4 w-4 shrink-0', color)} />
                  <div className="min-w-0">
                    <p className="text-[11px] text-muted-foreground truncate">{label}</p>
                    <p className="text-lg font-bold text-foreground leading-tight tabular-nums">
                      {loading ? '…' : val}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

    </div>
  );
}
