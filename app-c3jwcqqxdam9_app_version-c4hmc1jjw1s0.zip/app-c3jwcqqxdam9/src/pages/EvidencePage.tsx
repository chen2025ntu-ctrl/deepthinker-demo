import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Archive, Eye, Trash2, Edit2, Check, X, Filter,
  GraduationCap, Briefcase, Users, TrendingUp, FileText,
  AlertTriangle, ShieldCheck, Loader2, CopyX, BookMarked, RefreshCw,
  CheckSquare, Square, RotateCcw, Sparkles
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import { evidenceCardService, topicService, knowledgeService } from '@/services/database';
import type { EvidenceCard, CardStatus, Dimension, Topic } from '@/types/types';
import {
  DIMENSION_LABELS, DIMENSION_COLORS,
  CARD_STATUS_LABELS
} from '@/types/types';
import { cn } from '@/lib/utils';
import { useLang } from '@/contexts/LangContext';
import { SingleRewriteDialog, BatchRewriteDialog, type RewriteResult } from '@/components/common/RewriteCardDialog';

const DIMENSION_ICONS: Record<Dimension, React.ElementType> = {
  academic: GraduationCap,
  industry: Briefcase,
  recruitment: Users,
  investment: TrendingUp,
};

// 按维度渲染结构化内容：遍历实际存在的所有字段，跳过与摘要重复的值
function StructuredContent({
  data,
  summary,
  fieldLabels,
}: {
  dimension: Dimension;
  data: Record<string, string>;
  summary?: string;
  fieldLabels: Record<string, string>;
}) {
  // 过滤：值非空、且与摘要不重复（避免套话）
  const summaryNorm = (summary ?? '').trim().toLowerCase();
  const entries = Object.entries(data).filter(([, v]) => {
    if (!v || !v.trim()) return false;
    // 跳过与摘要完全相同或高度重叠的内容（前 60 字重合视为重复）
    const vNorm = v.trim().toLowerCase();
    if (vNorm === summaryNorm) return false;
    if (summaryNorm.length > 20 && summaryNorm.includes(vNorm.slice(0, 60))) return false;
    return true;
  });

  if (entries.length === 0) return null;

  return (
    <div className="space-y-3">
      {entries.map(([key, value]) => (
        <div key={key} className="grid grid-cols-[5.5rem_1fr] gap-x-3 gap-y-0.5 items-start">
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide pt-0.5 text-right shrink-0">
            {fieldLabels[key] ?? key}
          </span>
          <p className="text-sm text-foreground text-pretty leading-relaxed">{value}</p>
        </div>
      ))}
    </div>
  );
}

// 归一化标题用于重复检测
function normalizeTitle(title: string): string {
  return title.trim().toLowerCase().replace(/[\s\-_·•—]/g, '').replace(/[^\w\u4e00-\u9fa5]/g, '');
}

// 计算去重分组：按 source_url 精确匹配 或 标题归一化匹配
function computeDupGroups(cards: EvidenceCard[]): EvidenceCard[][] {
  const groups: EvidenceCard[][] = [];
  const assignedIds = new Set<string>();

  // 先按 source_url 分组（优先级更高）
  const byUrl = new Map<string, EvidenceCard[]>();
  for (const card of cards) {
    if (!card.source_url) continue;
    const key = card.source_url.trim().toLowerCase();
    if (!byUrl.has(key)) byUrl.set(key, []);
    byUrl.get(key)!.push(card);
  }
  for (const [, group] of byUrl) {
    if (group.length > 1) {
      groups.push(group);
      group.forEach((c) => assignedIds.add(c.id));
    }
  }

  // 再按归一化标题分组（排除已入 URL 分组的）
  const byTitle = new Map<string, EvidenceCard[]>();
  for (const card of cards) {
    if (assignedIds.has(card.id)) continue;
    const key = normalizeTitle(card.title);
    if (!key) continue;
    if (!byTitle.has(key)) byTitle.set(key, []);
    byTitle.get(key)!.push(card);
  }
  for (const [, group] of byTitle) {
    if (group.length > 1) groups.push(group);
  }

  return groups;
}

export default function EvidencePage() {
  const { t, lang } = useLang();
  const [cards, setCards] = useState<EvidenceCard[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterTopic, setFilterTopic] = useState<string>('all');
  const [filterDimension, setFilterDimension] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [viewCard, setViewCard] = useState<EvidenceCard | null>(null);
  const [editCard, setEditCard] = useState<EvidenceCard | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editSummary, setEditSummary] = useState('');
  const [editStructured, setEditStructured] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  // 去重面板
  const [showDupPanel, setShowDupPanel] = useState(false);
  const [dupSelections, setDupSelections] = useState<Set<string>>(new Set()); // 勾选要删除的卡片id
  const [deduping, setDeduping] = useState(false);

  const [syncing, setSyncing] = useState(false);
  const [syncedCardIds, setSyncedCardIds] = useState<Set<string>>(new Set());

  // ── 批量选择状态 ──────────────────────────────────────────────────────────
  const [batchSelected, setBatchSelected] = useState<Set<string>>(new Set());
  const [batchApplying, setBatchApplying] = useState(false);
  const [rewriting, setRewriting] = useState(false);

  // ── LLM 重写状态 ──────────────────────────────────────────────────────────
  const [singleRewriteCard, setSingleRewriteCard] = useState<EvidenceCard | null>(null);
  const [showBatchRewrite, setShowBatchRewrite] = useState(false);

  // STATUS_ACTIONS 依赖翻译，定义在组件内
  const STATUS_ACTIONS: { status: CardStatus; label: string; icon: React.ElementType; cls: string }[] = [
    { status: 'archived', label: t.evidence.actionArchive, icon: Archive, cls: 'text-emerald-600 hover:bg-emerald-50' },
    { status: 'observing', label: t.evidence.actionObserve, icon: Eye, cls: 'text-amber-600 hover:bg-amber-50' },
    { status: 'ignored', label: t.evidence.actionIgnore, icon: Trash2, cls: 'text-muted-foreground hover:bg-muted' },
  ];

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [cardsData, topicsData, syncedIds] = await Promise.all([
        evidenceCardService.listAll(),
        topicService.list(),
        knowledgeService.listSyncedCardIds(),
      ]);
      setCards(cardsData);
      setTopics(topicsData);
      setSyncedCardIds(syncedIds);
    } catch {
      toast.error(t.evidence.toastLoadFail);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void loadData(); }, [loadData]);

  // 计算重复分组（全量，不受筛选影响）
  const dupGroups = useMemo(() => computeDupGroups(cards), [cards]);

  // 所有重复卡片 id 集合（每组中第一张保留，其余标记为重复）
  const dupIds = useMemo(() => {
    const ids = new Set<string>();
    for (const group of dupGroups) {
      group.slice(1).forEach((c) => ids.add(c.id));
    }
    return ids;
  }, [dupGroups]);

  const filtered = cards.filter((c) => {
    if (filterTopic !== 'all' && c.topic_id !== filterTopic) return false;
    if (filterDimension !== 'all' && c.dimension !== filterDimension) return false;
    if (filterStatus !== 'all' && c.status !== filterStatus) return false;
    return true;
  });

  // ── 将证据卡片内容构建为 Markdown ──────────────────────────────────────────
  const buildCardMarkdown = (card: EvidenceCard): { title: string; content: string } => {
    const dimensionLabel = t.dimension[card.dimension] ?? card.dimension;
    const fieldLabels = t.evidence.fieldLabels as Record<string, string>;
    const structured = displayStructured(card);
    const summaryText = displaySummary(card);
    const fieldRows = Object.entries(structured)
      .filter(([, v]) => typeof v === 'string' && v.trim())
      .map(([k, v]) => `**${fieldLabels[k] ?? k}**：${v}`)
      .join('\n\n');
    const content = [
      `# ${card.title}`,
      '',
      `${t.evidence.mdDimension}：${dimensionLabel}`,
      '',
      t.evidence.mdSummary,
      summaryText,
      fieldRows ? `\n${t.evidence.mdStructured}\n\n${fieldRows}` : '',
      card.source_url ? `\n${t.evidence.mdSource}\n\n[${card.source_title ?? card.source_url}](${card.source_url})` : '',
    ].filter(Boolean).join('\n');
    return { title: `[${dimensionLabel}] ${card.title}`, content };
  };

  // ── KB 自动同步更新：卡片内容变更后，若已入库则覆盖写入对应 KB 条目 ─────────
  // 使用固定中文字段（card.summary / card.structured_content）构建 KB 内容，
  // 与界面语言无关，保证 KB 条目始终是完整的中文主版本。
  const buildKBContent = (card: EvidenceCard): { title: string; content: string } => {
    const dimensionLabel = t.dimension[card.dimension] ?? card.dimension;
    const fieldLabels = t.evidence.fieldLabels as Record<string, string>;
    const structured = card.structured_content ?? {};
    const fieldRows = Object.entries(structured)
      .filter(([, v]) => typeof v === 'string' && (v as string).trim())
      .map(([k, v]) => `**${fieldLabels[k] ?? k}**：${v}`)
      .join('\n\n');
    const content = [
      `# ${card.title}`,
      '',
      `${t.evidence.mdDimension}：${dimensionLabel}`,
      '',
      t.evidence.mdSummary,
      card.summary,
      fieldRows ? `\n${t.evidence.mdStructured}\n\n${fieldRows}` : '',
      card.source_url ? `\n${t.evidence.mdSource}\n\n[${card.source_title ?? card.source_url}](${card.source_url})` : '',
    ].filter(Boolean).join('\n');
    return { title: `[${dimensionLabel}] ${card.title}`, content };
  };

  const syncUpdateCardKB = async (card: EvidenceCard): Promise<void> => {
    if (!syncedCardIds.has(card.id)) return; // 未入库，跳过
    const { title, content } = buildKBContent(card);
    const result = await knowledgeService.updateByCardId(card.id, { title, content });
    if (result === 'updated') {
      toast.success(t.evidence.toastKbAutoUpdated, { duration: 2000 });
    }
    // notfound：KB 条目已被删除，静默跳过（不报错，避免干扰主操作）
  };

  // ── 核心 KB 同步（1:1 映射 + 幂等保护）──────────────────────────────────
  // 每张证据卡片对应一条 KB 条目，通过 evidence_card_id 外键锚定，天然幂等。
  // 不再做标题相似度合并（合并逻辑改由知识库页面手动处理），消除了所有歧义路径。
  const syncCardToKB = async (
    card: EvidenceCard,
    alreadySyncedIds: Set<string>
  ): Promise<'created' | 'skipped' | 'error'> => {
    try {
      // 幂等保护：已在 syncedCardIds 集合中，直接跳过
      if (alreadySyncedIds.has(card.id)) return 'skipped';

      const { title, content } = buildCardMarkdown(card);
      await knowledgeService.create({
        title,
        content,
        source_type: 'evidence',
        evidence_card_id: card.id,
      });
      return 'created';
    } catch (e) {
      console.error('[KB sync] 写入失败 card.id=' + card.id, e);
      return 'error';
    }
  };

  // ── 状态变更（含入库同步）────────────────────────────────────────────────
  const handleStatusChange = async (card: EvidenceCard, status: CardStatus) => {
    const newStatus = card.status === status ? 'pending' : status;
    try {
      await evidenceCardService.updateStatus(card.id, newStatus);
      setCards((prev) => prev.map((c) => (c.id === card.id ? { ...c, status: newStatus } : c)));
      toast.success(t.evidence.toastStatusChanged.replace('{label}', t.cardStatus[newStatus]));
    } catch {
      toast.error(t.common.error);
      return;
    }

    if (newStatus === 'archived') {
      const result = await syncCardToKB(card, syncedCardIds);
      if (result === 'created') {
        setSyncedCardIds((prev) => new Set([...prev, card.id]));
        toast.success(t.evidence.toastKbSynced, { duration: 2500 });
      } else if (result === 'skipped') {
        // 已同步，静默跳过
      } else {
        toast.warning(t.evidence.toastKbFail);
      }
    }
  };

  // ── 批量补同步：所有入库但 KB 缺失的卡片 ────────────────────────────────
  const handleResyncAll = async () => {
    const unsynced = cards.filter((c) => c.status === 'archived' && !syncedCardIds.has(c.id));
    if (!unsynced.length) {
      toast.success(t.evidence.kbAllSynced);
      return;
    }
    setSyncing(true);
    let created = 0, errors = 0;
    // 使用当前 syncedCardIds 快照，避免并发重复写入
    const snapshot = new Set(syncedCardIds);
    for (const card of unsynced) {
      const result = await syncCardToKB(card, snapshot);
      if (result === 'created') {
        snapshot.add(card.id);
        created++;
      } else if (result === 'error') {
        errors++;
      }
    }
    setSyncedCardIds(snapshot);
    setSyncing(false);
    if (errors > 0) {
      toast.warning(t.evidence.resyncDoneWithError
        .replace('{created}', String(created))
        .replace('{errors}', String(errors)));
    } else {
      toast.success(t.evidence.resyncDone.replace('{created}', String(created)));
    }
  };

  // 未同步数量（已入库但还没有 KB 条目）
  const unsyncedCount = useMemo(
    () => cards.filter((c) => c.status === 'archived' && !syncedCardIds.has(c.id)).length,
    [cards, syncedCardIds]
  );

  const openEdit = (card: EvidenceCard) => {
    setEditCard(card);
    setEditTitle(card.title);
    setEditSummary(card.summary);
    setEditStructured({ ...card.structured_content });
  };

  const handleSaveEdit = async () => {
    if (!editCard) return;
    setSaving(true);
    try {
      await evidenceCardService.update(editCard.id, {
        title: editTitle,
        summary: editSummary,
        structured_content: editStructured,
      });
      const updatedCard = { ...editCard, title: editTitle, summary: editSummary, structured_content: editStructured };
      setCards((prev) => prev.map((c) => c.id === editCard.id ? updatedCard : c));
      toast.success(t.evidence.toastSaved);
      setEditCard(null);
      // 若该卡片已入库，静默同步更新 KB 条目
      syncUpdateCardKB(updatedCard).catch(() =>
        toast.warning(t.evidence.toastKbAutoUpdateFail, { duration: 3000 })
      );
    } catch {
      toast.error(t.evidence.toastSaveFail);
    } finally {
      setSaving(false);
    }
  };

  // 打开去重面板：默认勾选每组中非第一张的卡片（建议删除项）
  const openDupPanel = () => {
    const ids = new Set<string>();
    for (const group of dupGroups) {
      group.slice(1).forEach((c) => ids.add(c.id));
    }
    setDupSelections(ids);
    setShowDupPanel(true);
  };

  // 执行去重：删除所有勾选的卡片
  const handleDedup = async () => {
    if (dupSelections.size === 0) return;
    setDeduping(true);
    try {
      await evidenceCardService.batchRemove([...dupSelections]);
      setCards((prev) => prev.filter((c) => !dupSelections.has(c.id)));
      toast.success(t.evidence.toastDedupDone.replace('{n}', String(dupSelections.size)));
      setShowDupPanel(false);
      setDupSelections(new Set());
    } catch {
      toast.error(t.evidence.toastDedupFail);
    } finally {
      setDeduping(false);
    }
  };

  const toggleDupSelection = (id: string) => {
    setDupSelections((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // ── 批量选中操作 ──────────────────────────────────────────────────────────
  const toggleBatchSelect = (id: string) => {
    setBatchSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const selectByTopic = (topicId: string) => {
    const ids = filtered.filter((c) => c.topic_id === topicId).map((c) => c.id);
    setBatchSelected((prev) => {
      const next = new Set(prev);
      ids.forEach((id) => next.add(id));
      return next;
    });
  };

  const selectAllFiltered = () => setBatchSelected(new Set(filtered.map((c) => c.id)));
  const clearBatchSelect = () => setBatchSelected(new Set());

  // 批量更新状态：ignored 状态等同删除
  const handleBatchStatus = async (status: CardStatus) => {
    if (batchSelected.size === 0) return;
    setBatchApplying(true);
    const ids = [...batchSelected];
    try {
      if (status === 'ignored') {
        // 忽略 = 删除
        const confirm = window.confirm(
          t.evidence.batchIgnoreConfirm.replace('{n}', String(ids.length))
        );
        if (!confirm) { setBatchApplying(false); return; }
        await evidenceCardService.batchRemove(ids);
        setCards((prev) => prev.filter((c) => !batchSelected.has(c.id)));
        setBatchSelected(new Set());
        toast.success(t.evidence.batchIgnoreDone.replace('{n}', String(ids.length)));
      } else {
        await evidenceCardService.batchUpdateStatus(ids, status);
        setCards((prev) => prev.map((c) => batchSelected.has(c.id) ? { ...c, status } : c));
        // 如果批量入库，逐一同步 KB
        if (status === 'archived') {
          const snapshot = new Set(syncedCardIds);
          for (const id of ids) {
            const card = cards.find((c) => c.id === id);
            if (card && !snapshot.has(id)) {
              const result = await syncCardToKB(card, snapshot);
              if (result === 'created') snapshot.add(id);
            }
          }
          setSyncedCardIds(snapshot);
        }
        setBatchSelected(new Set());
        toast.success(t.evidence.batchDone.replace('{n}', String(ids.length)));
      }
    } catch {
      toast.error(t.common.error);
    } finally {
      setBatchApplying(false);
    }
  };

  // ── 重写现有知识库条目（用完整内容覆盖）──────────────────────────────────
  const handleRewriteKB = async () => {
    const syncedCards = cards.filter((c) => syncedCardIds.has(c.id));
    if (syncedCards.length === 0) { toast.info(t.evidence.kbAllSynced); return; }
    const confirm = window.confirm(t.evidence.rewriteKBConfirm);
    if (!confirm) return;
    setRewriting(true);
    let updated = 0, skipped = 0;
    try {
      for (const card of syncedCards) {
        const { title, content } = buildCardMarkdown(card);
        const result = await knowledgeService.updateByCardId(card.id, { title, content });
        if (result === 'updated') updated++; else skipped++;
      }
      toast.success(
        t.evidence.rewriteKBDone
          .replace('{updated}', String(updated))
          .replace('{skipped}', String(skipped))
      );
    } catch {
      toast.error(t.evidence.rewriteKBFail);
    } finally {
      setRewriting(false);
    }
  };

  const statusBadgeCls: Record<CardStatus, string> = {
    pending: 'bg-muted text-muted-foreground',
    archived: 'bg-emerald-50 text-emerald-600 border-emerald-200',
    observing: 'bg-amber-50 text-amber-600 border-amber-200',
    ignored: 'bg-muted text-muted-foreground/60',
  };

  const topicTitle = (id: string) => topics.find((tp) => tp.id === id)?.title ?? t.evidence.unknownTopic;

  // ── 语言切换显示助手：英文模式优先用 en 字段 ─────────────────────────────
  const displaySummary = (card: EvidenceCard) =>
    lang === 'en' && card.summary_en ? card.summary_en : card.summary;

  const displayStructured = (card: EvidenceCard): Record<string, string> => {
    if (lang === 'en' && card.structured_content_en && Object.values(card.structured_content_en).some((v) => v?.trim())) {
      return card.structured_content_en as Record<string, string>;
    }
    return card.structured_content;
  };

  // ── LLM 重写回调 ──────────────────────────────────────────────────────────
  const handleSingleRewriteSaved = (updated: EvidenceCard) => {
    setCards((prev) => prev.map((c) => c.id === updated.id ? updated : c));
    // 若已入库，同步更新 KB
    syncUpdateCardKB(updated).catch(() =>
      toast.warning(t.evidence.toastKbAutoUpdateFail, { duration: 3000 })
    );
  };

  const handleBatchRewriteSaved = (updates: Map<string, RewriteResult>) => {
    setCards((prev) =>
      prev.map((c) => {
        const u = updates.get(c.id);
        return u ? {
          ...c,
          summary: u.summary,
          structured_content: u.structured_content,
          summary_en: u.summary_en,
          structured_content_en: u.structured_content_en,
        } : c;
      })
    );
    setShowBatchRewrite(false);

    // 对所有已入库的重写卡片批量同步 KB
    const syncBatch = async () => {
      let synced = 0;
      for (const [cardId, result] of updates) {
        if (!syncedCardIds.has(cardId)) continue;
        const base = cards.find((c) => c.id === cardId);
        if (!base) continue;
        const updatedCard: EvidenceCard = {
          ...base,
          summary: result.summary,
          structured_content: result.structured_content,
          summary_en: result.summary_en,
          structured_content_en: result.structured_content_en,
        };
        try {
          const r = await knowledgeService.updateByCardId(cardId, buildKBContent(updatedCard));
          if (r === 'updated') synced++;
        } catch { /* 静默失败，不中断循环 */ }
      }
      if (synced > 0) {
        toast.success(t.evidence.toastBatchKbAutoUpdated.replace('{n}', String(synced)), { duration: 3000 });
      }
    };
    syncBatch().catch(() => toast.warning(t.evidence.toastKbAutoUpdateFail, { duration: 3000 }));
  };

  return (
    <div className="p-6">
      <div className="mb-6 flex flex-col md:flex-row md:items-start md:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground text-balance">{t.evidence.pageTitle}</h1>
          <p className="text-sm text-muted-foreground mt-1">{t.evidence.pageDesc}</p>
        </div>
        <div className="flex gap-2 shrink-0 self-start flex-wrap">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setShowBatchRewrite(true)}
            disabled={loading || cards.length === 0}
          >
            <Sparkles className="h-3.5 w-3.5 mr-1.5" />{t.evidence.llmRewriteAllBtn}
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => void handleRewriteKB()}
            disabled={rewriting || syncing || loading}
          >
            {rewriting
              ? <><Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" />{t.evidence.rewritingKBBtn}</>
              : <><RotateCcw className="h-3.5 w-3.5 mr-1.5" />{t.evidence.rewriteKBBtn}</>}
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => void handleResyncAll()}
            disabled={syncing || rewriting || loading}
          >
            {syncing
              ? <><Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" />{t.evidence.resyncingBtn}</>
              : <><RefreshCw className="h-3.5 w-3.5 mr-1.5" />{t.evidence.resyncBtn}</>}
          </Button>
        </div>
      </div>

      {/* 未同步提示横幅 */}
      {!loading && unsyncedCount > 0 && (
        <div className="flex items-center gap-3 mb-4 p-3 bg-blue-50 border border-blue-200 text-blue-800 text-sm">
          <BookMarked className="h-4 w-4 shrink-0" />
          <span className="flex-1 text-pretty">
            {t.evidence.kbUnsyncedBanner.replace('{n}', String(unsyncedCount))}
          </span>
          <Button
            size="sm"
            variant="ghost"
            className="border border-blue-300 text-blue-800 hover:bg-blue-100 shrink-0"
            onClick={() => void handleResyncAll()}
            disabled={syncing}
          >
            {syncing
              ? <><Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" />{t.evidence.resyncingBtn}</>
              : t.evidence.resyncBtn}
          </Button>
        </div>
      )}

      {/* 去重提示横幅 */}
      {!loading && dupGroups.length > 0 && (
        <div className="flex items-center gap-3 mb-4 p-3 bg-amber-50 border border-amber-200 text-amber-800 text-sm">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span className="flex-1 text-pretty">
            {t.evidence.dupBannerText.replace('{groups}', String(dupGroups.length)).replace('{count}', String(dupIds.size))}
          </span>
          <Button
            size="sm"
            variant="ghost"
            className="border border-amber-300 text-amber-800 hover:bg-amber-100 shrink-0"
            onClick={openDupPanel}
          >
            <CopyX className="h-3.5 w-3.5 mr-1.5" />
            {t.evidence.dupViewBtn}
          </Button>
        </div>
      )}

      {/* 已完成去重提示 */}
      {!loading && dupGroups.length === 0 && cards.length > 0 && (
        <div className="flex items-center gap-2 mb-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm">
          <ShieldCheck className="h-4 w-4 shrink-0" />
          <span>{t.evidence.dupCleanText}</span>
        </div>
      )}

      {/* 筛选栏 */}
      <div className="flex flex-wrap gap-3 mb-6">
        <Select value={filterTopic} onValueChange={setFilterTopic}>
          <SelectTrigger className="w-44 shrink-0">
            <SelectValue placeholder={t.evidence.filterAllTopics} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t.evidence.filterAllTopics}</SelectItem>
            {topics.map((tp) => (
              <SelectItem key={tp.id} value={tp.id}>{tp.title}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filterDimension} onValueChange={setFilterDimension}>
          <SelectTrigger className="w-36 shrink-0">
            <SelectValue placeholder={t.evidence.filterAllDimensions} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t.evidence.filterAllDimensions}</SelectItem>
            {(Object.entries(t.dimension) as [Dimension, string][]).map(([k, v]) => (
              <SelectItem key={k} value={k}>{v}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-32 shrink-0">
            <SelectValue placeholder={t.evidence.filterAllStatuses} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t.evidence.filterAllStatuses}</SelectItem>
            <SelectItem value="pending">{t.evidence.statusPending}</SelectItem>
            <SelectItem value="archived">{t.evidence.statusArchived}</SelectItem>
            <SelectItem value="observing">{t.evidence.statusObserving}</SelectItem>
            <SelectItem value="ignored">{t.evidence.statusIgnored}</SelectItem>
          </SelectContent>
        </Select>

        <div className="flex items-center gap-2 text-sm text-muted-foreground ml-auto">
          <Filter className="h-4 w-4" />
          <span>{t.evidence.cardCount.replace('{n}', String(filtered.length))}</span>
        </div>
      </div>

      {/* 批量操作工具栏 */}
      <div className="flex flex-wrap items-center gap-2 mb-4 p-3 bg-muted/40 border border-border">
        {/* 专题快速选中 */}
        <Select onValueChange={(val) => { if (val !== 'none') selectByTopic(val); }}>
          <SelectTrigger className="h-8 w-44 text-xs shrink-0">
            <SelectValue placeholder={t.evidence.batchSelectTopic} />
          </SelectTrigger>
          <SelectContent>
            {topics.map((tp) => (
              <SelectItem key={tp.id} value={tp.id} className="text-xs">{tp.title}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button size="sm" variant="outline" className="h-8 text-xs" onClick={selectAllFiltered}>
          <CheckSquare className="h-3.5 w-3.5 mr-1" />{t.evidence.batchSelectAll}
        </Button>
        {batchSelected.size > 0 && (
          <>
            <span className="text-xs font-semibold text-primary px-2 py-1 bg-primary/10 border border-primary/20">
              {t.evidence.batchSelected.replace('{n}', String(batchSelected.size))}
            </span>
            <Button size="sm" className="h-8 text-xs bg-emerald-600 hover:bg-emerald-700 text-white" disabled={batchApplying} onClick={() => void handleBatchStatus('archived')}>
              {batchApplying ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Archive className="h-3 w-3 mr-1" />}
              {t.evidence.batchArchiveBtn}
            </Button>
            <Button size="sm" className="h-8 text-xs bg-amber-500 hover:bg-amber-600 text-white" disabled={batchApplying} onClick={() => void handleBatchStatus('observing')}>
              {batchApplying ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Eye className="h-3 w-3 mr-1" />}
              {t.evidence.batchObserveBtn}
            </Button>
            <Button size="sm" variant="outline" className="h-8 text-xs text-destructive border-destructive/30 hover:bg-destructive/10" disabled={batchApplying} onClick={() => void handleBatchStatus('ignored')}>
              {batchApplying ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Trash2 className="h-3 w-3 mr-1" />}
              {t.evidence.batchIgnoreBtn}
            </Button>
            <Button size="sm" variant="ghost" className="h-8 text-xs text-muted-foreground ml-1" onClick={clearBatchSelect}>
              <Square className="h-3.5 w-3.5 mr-1" />{t.evidence.batchClear}
            </Button>
          </>
        )}
      </div>

      {/* 卡片网格 */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-48 bg-muted" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
          <FileText className="h-10 w-10 mb-3 opacity-30" />
          <p className="font-medium">{t.evidence.emptyTitle}</p>
          <p className="text-sm mt-1">{t.evidence.emptyDesc}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((card) => {
            const Icon = DIMENSION_ICONS[card.dimension];
            const isDup = dupIds.has(card.id);
            const isKbSynced = syncedCardIds.has(card.id);
            return (
              <Card key={card.id} className={cn(
                'h-full flex flex-col',
                card.status === 'ignored' && 'opacity-50',
                isDup && 'ring-1 ring-amber-300',
                batchSelected.has(card.id) && 'ring-2 ring-primary bg-primary/5'
              )}>
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Checkbox
                      checked={batchSelected.has(card.id)}
                      onCheckedChange={() => toggleBatchSelect(card.id)}
                      className="shrink-0"
                    />
                    <span className={cn('flex items-center gap-1 text-xs font-medium px-2 py-0.5 border', DIMENSION_COLORS[card.dimension])}>
                      <Icon className="h-3 w-3" />
                      {t.dimension[card.dimension]}
                    </span>
                    <Badge variant="outline" className={cn('text-xs', statusBadgeCls[card.status])}>
                      {t.cardStatus[card.status]}
                    </Badge>
                    {/* KB 同步状态标记：仅在已入库时显示 */}
                    {card.status === 'archived' && (
                      <Badge
                        variant="outline"
                        className={cn(
                          'text-xs gap-1',
                          isKbSynced
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                            : 'bg-orange-50 text-orange-600 border-orange-300'
                        )}
                      >
                        {isKbSynced
                          ? <><ShieldCheck className="h-2.5 w-2.5" />{t.evidence.kbSynced}</>
                          : <><BookMarked className="h-2.5 w-2.5" />{t.evidence.kbUnsynced}</>}
                      </Badge>
                    )}
                    {isDup && (
                      <Badge variant="outline" className="text-xs bg-amber-50 text-amber-600 border-amber-300">
                        <AlertTriangle className="h-2.5 w-2.5 mr-1" />{t.evidence.dupBadge}
                      </Badge>
                    )}
                    <span className="text-xs text-muted-foreground ml-auto truncate max-w-28">{topicTitle(card.topic_id)}</span>
                  </div>
                  <CardTitle className="text-sm mt-1 text-balance leading-snug">{card.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col gap-3 pt-0">
                  <p className="text-sm text-muted-foreground text-pretty flex-1">{displaySummary(card)}</p>
                  <div className="flex items-center gap-1 flex-wrap">
                    {STATUS_ACTIONS.map(({ status, label, icon: ActionIcon, cls }) => (
                      <button
                        key={status}
                        onClick={() => void handleStatusChange(card, status)}
                        className={cn(
                          'flex items-center gap-1 px-2 py-1 text-xs border transition-colors',
                          card.status === status ? 'font-semibold border-current' : 'border-border',
                          cls
                        )}
                      >
                        <ActionIcon className="h-3 w-3" />
                        {label}
                        {card.status === status && <Check className="h-3 w-3 ml-0.5" />}
                      </button>
                    ))}
                    <div className="flex gap-1 ml-auto">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7 text-primary hover:bg-primary/10"
                        title={t.evidence.llmRewriteBtn}
                        onClick={() => setSingleRewriteCard(card)}
                      >
                        <Sparkles className="h-3 w-3" />
                      </Button>
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setViewCard(card)}>
                        <Eye className="h-3 w-3" />
                      </Button>
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openEdit(card)}>
                        <Edit2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  {card.source_url && (
                    <a href={card.source_url} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline truncate block">
                      {card.source_title ?? card.source_url}
                    </a>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* 查看卡片 Dialog */}
      <Dialog open={!!viewCard} onOpenChange={() => setViewCard(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-balance leading-snug pr-6">{viewCard?.title}</DialogTitle>
          </DialogHeader>
          {viewCard && (
            <div className="space-y-5">
              {/* 元数据行：维度 + 状态 + 专题 */}
              <div className="flex items-center gap-2 flex-wrap">
                {(() => { const Icon = DIMENSION_ICONS[viewCard.dimension]; return (
                  <span className={cn('flex items-center gap-1 text-xs font-medium px-2 py-0.5 border', DIMENSION_COLORS[viewCard.dimension])}>
                    <Icon className="h-3 w-3" />{t.dimension[viewCard.dimension]}
                  </span>
                ); })()}
                <Badge variant="outline" className={cn('text-xs', statusBadgeCls[viewCard.status])}>
                  {t.cardStatus[viewCard.status]}
                </Badge>
                <span className="text-xs text-muted-foreground ml-auto truncate">{topicTitle(viewCard.topic_id)}</span>
              </div>

              {/* 摘要：直接展示，不加冗余标题 */}
              <p className="text-sm text-foreground text-pretty leading-relaxed">{displaySummary(viewCard)}</p>

              {/* 结构化字段：仅当有非重复内容时显示，带分隔线 */}
              {(() => {
                const structured = displayStructured(viewCard);
                const summaryText = displaySummary(viewCard);
                if (Object.keys(structured).length === 0) return null;
                const summaryNorm = summaryText.trim().toLowerCase();
                const hasUniqueFields = Object.values(structured).some((v) => {
                  if (!v?.trim()) return false;
                  const vNorm = v.trim().toLowerCase();
                  return vNorm !== summaryNorm && !(summaryNorm.length > 20 && summaryNorm.includes(vNorm.slice(0, 60)));
                });
                if (!hasUniqueFields) return null;
                return (
                  <div className="border-t border-border pt-4">
                    <StructuredContent
                      dimension={viewCard.dimension}
                      data={structured}
                      summary={summaryText}
                      fieldLabels={t.evidence.fieldLabels as Record<string, string>}
                    />
                  </div>
                );
              })()}

              {/* 来源链接 */}
              {viewCard.source_url && (
                <div className="border-t border-border pt-4 flex items-start gap-2">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide shrink-0 pt-0.5">{t.evidence.sourceLabel}</span>
                  <a
                    href={viewCard.source_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-primary hover:underline break-all leading-relaxed"
                  >
                    {viewCard.source_title && viewCard.source_title !== viewCard.title
                      ? viewCard.source_title
                      : viewCard.source_url}
                  </a>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* 编辑卡片 Dialog */}
      <Dialog open={!!editCard} onOpenChange={() => setEditCard(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{t.evidence.editCard}</DialogTitle>
          </DialogHeader>
          {editCard && (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-normal block mb-1">{t.evidence.titleLabel}</label>
                <Input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} />
              </div>
              <div>
                <label className="text-sm font-normal block mb-1">{t.evidence.summaryLabel}</label>
                <Textarea value={editSummary} onChange={(e) => setEditSummary(e.target.value)} rows={4} />
              </div>
              <div>
                <label className="text-sm font-normal block mb-2">{t.evidence.structuredFieldsLabel}</label>
                {Object.keys(editStructured).length === 0 && (
                  <p className="text-xs text-muted-foreground mb-2">{t.evidence.noStructuredFields}</p>
                )}
                {Object.entries(editStructured).map(([key, val]) => (
                  <div key={key} className="flex gap-2 mb-2 items-start">
                    <span className="text-xs text-muted-foreground py-2 w-20 shrink-0 text-right">
                      {(t.evidence.fieldLabels as Record<string, string>)[key] ?? key}
                    </span>
                    <Textarea
                      value={val}
                      onChange={(e) => setEditStructured((prev) => ({ ...prev, [key]: e.target.value }))}
                      rows={2}
                      className="flex-1"
                    />
                  </div>
                ))}
              </div>
              <div className="flex gap-3">
                <Button onClick={() => void handleSaveEdit()} disabled={saving} className="flex-1">
                  {saving ? t.common.saving : <><Check className="h-4 w-4 mr-2" />{t.common.save}</>}
                </Button>
                <Button variant="outline" onClick={() => setEditCard(null)}>
                  <X className="h-4 w-4 mr-2" />{t.common.cancel}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* 去重面板 Dialog */}
      <Dialog open={showDupPanel} onOpenChange={(open) => { if (!open) setShowDupPanel(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-3xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CopyX className="h-4 w-4 text-amber-500" />
              {t.evidence.dupDialogTitle}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground text-pretty">
              {t.evidence.dupDialogDesc.replace('{groups}', String(dupGroups.length))}
            </p>

            <div className="flex gap-2 text-xs">
              <button
                className="text-primary hover:underline"
                onClick={() => {
                  const allDup = new Set<string>();
                  dupGroups.forEach((g) => g.slice(1).forEach((c) => allDup.add(c.id)));
                  setDupSelections(allDup);
                }}
              >
                {t.evidence.dupRecommend}
              </button>
              <span className="text-muted-foreground">·</span>
              <button className="text-muted-foreground hover:underline" onClick={() => setDupSelections(new Set())}>
                {t.evidence.dupClearAll}
              </button>
            </div>

            <div className="space-y-4">
              {dupGroups.map((group, gi) => (
                <div key={gi} className="border border-amber-200 bg-amber-50/50">
                  <div className="px-3 py-2 border-b border-amber-200 bg-amber-100/60">
                    <span className="text-xs font-semibold text-amber-700">
                      {t.evidence.dupGroupLabel.replace('{n}', String(gi + 1)).replace('{count}', String(group.length))}
                      {group[0].source_url ? ` ${t.evidence.dupSameSource}` : ` ${t.evidence.dupSameTitle}`}
                    </span>
                  </div>
                  <div className="divide-y divide-amber-100">
                    {group.map((card, ci) => {
                      const isChecked = dupSelections.has(card.id);
                      return (
                        <label
                          key={card.id}
                          className={cn(
                            'flex items-start gap-3 px-3 py-2.5 cursor-pointer hover:bg-amber-50 transition-colors',
                            isChecked && 'bg-red-50/60'
                          )}
                        >
                          <Checkbox checked={isChecked} onCheckedChange={() => toggleDupSelection(card.id)} className="mt-0.5 shrink-0" />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap mb-0.5">
                              {ci === 0 && (
                                <Badge variant="outline" className="text-[10px] bg-emerald-50 text-emerald-600 border-emerald-200 shrink-0">
                                  {t.evidence.dupRecommend.split('（')[0]}
                                </Badge>
                              )}
                              <span className={cn('text-xs px-1.5 py-0.5 border font-medium shrink-0', DIMENSION_COLORS[card.dimension])}>
                                {t.dimension[card.dimension]}
                              </span>
                              <span className="text-xs text-muted-foreground shrink-0">{topicTitle(card.topic_id)}</span>
                            </div>
                            <p className="text-sm font-medium text-foreground text-balance leading-snug">{card.title}</p>
                            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2 text-pretty">{displaySummary(card)}</p>
                            {card.source_url && (
                              <a href={card.source_url} target="_blank" rel="noopener noreferrer"
                                className="text-xs text-primary hover:underline truncate block mt-0.5"
                                onClick={(e) => e.stopPropagation()}
                              >
                                {card.source_url}
                              </a>
                            )}
                          </div>
                          {isChecked && (
                            <Badge variant="outline" className="text-[10px] bg-red-50 text-red-500 border-red-200 shrink-0 self-center">
                              {t.common.delete}
                            </Badge>
                          )}
                        </label>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-3 pt-2 border-t border-border">
              <Button onClick={() => void handleDedup()} disabled={dupSelections.size === 0 || deduping} className="flex-1">
                {deduping ? (
                  <><Loader2 className="h-4 w-4 animate-spin mr-2" />{t.common.loading}</>
                ) : (
                  <><Trash2 className="h-4 w-4 mr-2" />{t.evidence.dupExecuteBtn.replace('{n}', String(dupSelections.size))}</>
                )}
              </Button>
              <Button variant="outline" onClick={() => setShowDupPanel(false)}>{t.common.cancel}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* AI 单卡片重写 Dialog */}
      <SingleRewriteDialog
        card={singleRewriteCard}
        onClose={() => setSingleRewriteCard(null)}
        onSaved={handleSingleRewriteSaved}
      />

      {/* AI 批量重写 Dialog */}
      <BatchRewriteDialog
        cards={filtered}
        open={showBatchRewrite}
        onClose={() => setShowBatchRewrite(false)}
        onAllSaved={handleBatchRewriteSaved}
      />
    </div>
  );
}
