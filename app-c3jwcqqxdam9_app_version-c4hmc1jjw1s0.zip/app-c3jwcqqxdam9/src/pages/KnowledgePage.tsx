import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Search, Trash2, Edit2, Check, X, BookOpen,
  FileText, Video, Type, Archive, Clock, GitMerge,
  Plus, ChevronRight, Hash, Eye, AlertTriangle, RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { knowledgeService } from '@/services/database';
import type { KnowledgeItem, SourceType } from '@/types/types';
import { SOURCE_TYPE_LABELS } from '@/types/types';
import EditableMarkdown from '@/components/common/EditableMarkdown';
import { cn } from '@/lib/utils';
import { useLang } from '@/contexts/LangContext';

const SOURCE_ICONS: Record<SourceType, React.ElementType> = {
  video: Video,
  text: Type,
  document: FileText,
  evidence: Archive,
};

const SOURCE_BADGE_CLS: Record<SourceType, string> = {
  text: 'bg-muted text-muted-foreground border-border',
  video: 'bg-blue-50 text-blue-600 border-blue-200',
  document: 'bg-amber-50 text-amber-600 border-amber-200',
  evidence: 'bg-emerald-50 text-emerald-600 border-emerald-200',
};

/** 提取 Markdown 首个 # 标题 */
function extractMdTitle(content: string): string {
  return /^#\s+(.+)/m.exec(content)?.[1]?.trim() ?? '';
}

/** 从内容中提取首段摘要（去掉 md 符号）*/
function extractSnippet(content: string, maxLen = 140): string {
  return content
    .replace(/^#+\s+.+$/gm, '')
    .replace(/\*\*?|__?|~~|`/g, '')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/\n{2,}/g, '\n')
    .trim()
    .slice(0, maxLen);
}

/** 规范化标题用于分组（去掉维度前缀标签） */
function normalizeGroupTitle(title: string): string {
  return title.replace(/^\[[^\]]+\]\s*/, '').toLowerCase().trim();
}

/** 计算两个标题的词覆盖相似度（0~1） */
function titleSimilarity(a: string, b: string): number {
  const wordsA = new Set(a.toLowerCase().split(/[\s\-_,，。、\[\]（）()]+/).filter((w) => w.length >= 2));
  const wordsB = new Set(b.toLowerCase().split(/[\s\-_,，。、\[\]（）()]+/).filter((w) => w.length >= 2));
  if (!wordsA.size || !wordsB.size) return 0;
  const intersection = [...wordsA].filter((w) => wordsB.has(w)).length;
  return intersection / Math.max(wordsA.size, wordsB.size);
}

// ──────────────────────────────────────────────────────────────────────────────
// 去重合并 Dialog
// ──────────────────────────────────────────────────────────────────────────────
interface MergeDialogProps {
  open: boolean;
  newTitle: string;
  newContent: string;
  candidates: KnowledgeItem[];
  onMerge: (targetId: string) => Promise<void>;
  onCreateNew: () => Promise<void>;
  onClose: () => void;
}

function MergeDialog({ open, newTitle, newContent, candidates, onMerge, onCreateNew, onClose }: MergeDialogProps) {
  const { t } = useLang();
  const [selected, setSelected] = useState<string | null>(null);
  const [merging, setMerging] = useState(false);

  const handleMerge = async () => {
    if (!selected) return;
    setMerging(true);
    try { await onMerge(selected); } finally { setMerging(false); }
  };
  const handleNew = async () => {
    setMerging(true);
    try { await onCreateNew(); } finally { setMerging(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-500" />
            {t.knowledge.mergeDialogTitle}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="p-3 bg-muted/50 border border-border text-sm text-muted-foreground text-pretty">
            {t.knowledge.mergeDialogDesc.replace('{title}', newTitle)}
          </div>

          <div className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
              {t.knowledge.mergeSelectLabel}
            </p>
            {candidates.map((c) => (
              <label
                key={c.id}
                className={cn(
                  'flex items-start gap-3 p-3 border cursor-pointer transition-colors',
                  selected === c.id
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:bg-muted/50'
                )}
              >
                <input
                  type="radio"
                  name="merge-target"
                  value={c.id}
                  checked={selected === c.id}
                  onChange={() => setSelected(c.id)}
                  className="mt-0.5 shrink-0 accent-[hsl(var(--primary))]"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground text-balance">{c.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2 text-pretty">
                    {extractSnippet(c.content, 100)}
                  </p>
                  <p className="text-xs text-muted-foreground/60 mt-1">
                    {t.knowledge.lastUpdated}{new Date(c.updated_at).toLocaleDateString()}
                  </p>
                </div>
                <Badge variant="outline" className={cn('text-xs shrink-0', SOURCE_BADGE_CLS[c.source_type])}>
                  {SOURCE_TYPE_LABELS[c.source_type]}
                </Badge>
              </label>
            ))}
          </div>

          <div className="p-3 bg-muted/30 border border-border text-xs text-muted-foreground">
            <p className="font-medium text-foreground mb-1">{t.knowledge.newContentPreview}</p>
            <p className="line-clamp-3 text-pretty">{extractSnippet(newContent, 200)}</p>
          </div>

          <div className="flex gap-3 pt-1">
            <Button
              onClick={() => void handleMerge()}
              disabled={!selected || merging}
              className="flex-1"
            >
              {merging ? t.knowledge.processing : <><GitMerge className="h-4 w-4 mr-2" />{t.knowledge.mergeBtn}</>}
            </Button>
            <Button
              variant="outline"
              onClick={() => void handleNew()}
              disabled={merging}
              className="flex-1"
            >
              <Plus className="h-4 w-4 mr-2" />{t.knowledge.createNewBtn}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// 知识条目详情（维基页面风格）
// ──────────────────────────────────────────────────────────────────────────────
interface ArticleViewProps {
  item: KnowledgeItem;
  onEdit: () => void;
  onClose: () => void;
}

function ArticleView({ item, onEdit, onClose }: ArticleViewProps) {
  const { t } = useLang();
  const Icon = SOURCE_ICONS[item.source_type];
  const headings = [...item.content.matchAll(/^(#{1,3})\s+(.+)$/gm)].map((m) => ({
    level: m[1].length,
    text: m[2].trim(),
  }));

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-4xl max-h-[90dvh] overflow-y-auto">
        <DialogHeader className="pb-2 border-b border-border">
          <div className="flex items-start gap-3">
            <div className="flex-1 min-w-0">
              <DialogTitle className="text-xl font-bold text-balance leading-tight">{item.title}</DialogTitle>
              <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                <Badge variant="outline" className={cn('text-xs', SOURCE_BADGE_CLS[item.source_type])}>
                  <Icon className="h-2.5 w-2.5 mr-1" />
                  {SOURCE_TYPE_LABELS[item.source_type]}
                </Badge>
                <span className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  {new Date(item.updated_at).toLocaleDateString()}
                </span>
              </div>
            </div>
            <Button size="sm" variant="outline" onClick={onEdit} className="shrink-0">
              <Edit2 className="h-3.5 w-3.5 mr-1.5" />{t.common.edit}
            </Button>
          </div>
        </DialogHeader>

        <div className="flex gap-6 mt-2">
          {headings.length > 0 && (
            <div className="hidden md:block w-44 shrink-0">
              <div className="sticky top-0 bg-muted/30 border border-border p-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
                  {t.knowledge.tocTitle}
                </p>
                <ul className="space-y-1">
                  {headings.map((h, idx) => (
                    <li
                      key={idx}
                      className="text-xs text-muted-foreground hover:text-foreground truncate transition-colors"
                      style={{ paddingLeft: `${(h.level - 1) * 8}px` }}
                    >
                      <ChevronRight className="h-2.5 w-2.5 inline mr-0.5 opacity-50" />
                      {h.text}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}
          <div className="flex-1 min-w-0 prose prose-sm max-w-none text-foreground">
            <pre className="whitespace-pre-wrap font-sans text-sm text-foreground leading-relaxed">
              {item.content}
            </pre>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// 主页面
// ──────────────────────────────────────────────────────────────────────────────
export default function KnowledgePage() {
  const { t } = useLang();
  const [items, setItems] = useState<KnowledgeItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | SourceType>('all');
  const [viewItem, setViewItem] = useState<KnowledgeItem | null>(null);
  const [editItem, setEditItem] = useState<KnowledgeItem | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  // 新建条目
  const [showNew, setShowNew] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newSourceType] = useState<SourceType>('text');
  const [creating, setCreating] = useState(false);
  // 去重 merge dialog
  const [mergeCtx, setMergeCtx] = useState<{
    title: string; content: string; sourceType: SourceType; candidates: KnowledgeItem[]
  } | null>(null);

  const loadItems = useCallback(async () => {
    setLoading(true);
    try {
      setItems(await knowledgeService.list());
    } catch {
      toast.error(t.knowledge.toastLoadFail);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void loadItems(); }, [loadItems]);

  const filtered = useMemo(() => {
    return items.filter((item) => {
      const q = searchQuery.toLowerCase();
      const matchSearch = !q || item.title.toLowerCase().includes(q) || item.content.toLowerCase().includes(q);
      const matchType = filterType === 'all' || item.source_type === filterType;
      return matchSearch && matchType;
    });
  }, [items, searchQuery, filterType]);

  // 按来源类型分组（维基分类）
  const grouped = useMemo(() => {
    const groups: Record<string, KnowledgeItem[]> = {
      evidence: [],
      video: [],
      document: [],
      text: [],
    };
    for (const item of filtered) {
      (groups[item.source_type] ?? groups.text).push(item);
    }
    return groups;
  }, [filtered]);

  // 统计各类型数量
  const typeCounts = useMemo(() => {
    const c: Record<SourceType, number> = { evidence: 0, video: 0, document: 0, text: 0 };
    for (const item of items) c[item.source_type] = (c[item.source_type] ?? 0) + 1;
    return c;
  }, [items]);

  // ── 编辑 ──
  const handleEdit = (item: KnowledgeItem) => {
    setViewItem(null);
    setEditItem(item);
    setEditTitle(item.title);
    setEditContent(item.content);
  };

  const handleSave = async () => {
    if (!editItem) return;
    setSaving(true);
    try {
      await knowledgeService.update(editItem.id, { title: editTitle, content: editContent });
      setItems((prev) =>
        prev.map((i) => i.id === editItem.id ? { ...i, title: editTitle, content: editContent } : i)
      );
      toast.success(t.knowledge.toastSaved);
      setEditItem(null);
    } catch { toast.error(t.knowledge.toastSaveFail); }
    finally { setSaving(false); }
  };

  // ── 删除 ──
  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await knowledgeService.remove(deleteId);
      setItems((prev) => prev.filter((i) => i.id !== deleteId));
      toast.success(t.knowledge.toastDeleted);
    } catch { toast.error(t.knowledge.toastDeleteFail); }
    finally { setDeleteId(null); }
  };

  // ── 新建（带去重校验）──
  const handleCreateNew = async () => {
    if (!newTitle.trim() || !newContent.trim()) {
      toast.error(t.knowledge.toastEmptyFields);
      return;
    }
    setCreating(true);
    try {
      const candidates = await knowledgeService.findSimilar(newTitle);
      const similar = candidates.filter((c) => titleSimilarity(c.title, newTitle) >= 0.5);
      if (similar.length > 0) {
        setMergeCtx({ title: newTitle, content: newContent, sourceType: newSourceType, candidates: similar });
        setCreating(false);
        return;
      }
      await doCreateNew(newTitle, newContent, newSourceType);
    } catch { toast.error(t.knowledge.toastCreateFail); }
    finally { setCreating(false); }
  };

  const doCreateNew = async (title: string, content: string, sourceType: SourceType) => {
    await knowledgeService.create({ title, content, source_type: sourceType });
    toast.success(t.knowledge.toastCreated);
    setShowNew(false);
    setNewTitle('');
    setNewContent('');
    setMergeCtx(null);
    await loadItems();
  };

  const doMerge = async (targetId: string) => {
    if (!mergeCtx) return;
    const section = `## ${t.knowledge.newContentPreview}（${new Date().toLocaleDateString()}）\n\n${mergeCtx.content}`;
    await knowledgeService.appendContent(targetId, section);
    const now = new Date().toISOString();
    setItems((prev) =>
      prev.map((i) => {
        if (i.id !== targetId) return i;
        const section2 = `## ${t.knowledge.newContentPreview}（${new Date().toLocaleDateString()}）\n\n${mergeCtx.content}`;
        return { ...i, content: `${i.content}\n\n---\n\n${section2}`, updated_at: now };
      })
    );
    toast.success(t.knowledge.toastMerged);
    setMergeCtx(null);
    setShowNew(false);
    setNewTitle('');
    setNewContent('');
  };

  // ── 渲染卡片 ──
  const renderItem = (item: KnowledgeItem) => {
    const Icon = SOURCE_ICONS[item.source_type];
    const snippet = extractSnippet(item.content);
    return (
      <div
        key={item.id}
        className="group flex items-start gap-3 py-3 border-b border-border last:border-0 hover:bg-muted/30 px-2 -mx-2 transition-colors cursor-pointer"
        onClick={() => setViewItem(item)}
      >
        <div className="shrink-0 mt-0.5 w-6 h-6 flex items-center justify-center bg-muted border border-border">
          <Icon className="h-3 w-3 text-muted-foreground" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="text-sm font-semibold text-primary hover:underline text-balance leading-snug">
              {item.title}
            </h3>
          </div>
          {snippet && (
            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2 text-pretty">{snippet}</p>
          )}
          <p className="text-[11px] text-muted-foreground/60 mt-1">
            <Clock className="h-2.5 w-2.5 inline mr-1" />
            {new Date(item.updated_at).toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' })}
          </p>
        </div>
        <div className="flex gap-0.5 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={(e) => e.stopPropagation()}>
          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => handleEdit(item)}>
            <Edit2 className="h-3 w-3" />
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setDeleteId(item.id)}>
            <Trash2 className="h-3 w-3 text-destructive" />
          </Button>
        </div>
      </div>
    );
  };

  // ── 动态 SECTION_CONFIG（依赖翻译）──
  const SECTION_CONFIG: { type: SourceType; label: string; desc: string }[] = [
    { type: 'evidence', label: t.knowledge.evidenceSection, desc: t.knowledge.evidenceSectionDesc },
    { type: 'video',    label: t.knowledge.videoSection,    desc: t.knowledge.videoSectionDesc },
    { type: 'document', label: t.knowledge.documentSection, desc: t.knowledge.documentSectionDesc },
    { type: 'text',     label: t.knowledge.textSection,     desc: t.knowledge.textSectionDesc },
  ];

  return (
    <div className="flex h-full min-h-screen">
      {/* 左侧目录栏（维基导航样式）*/}
      <aside className="hidden lg:flex flex-col w-56 shrink-0 border-r border-border bg-card">
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <BookOpen className="h-4 w-4 text-primary shrink-0" />
            <span className="font-semibold text-sm text-foreground">{t.knowledge.pageTitle}</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {t.knowledge.totalCount.replace('{n}', String(items.length))}
          </p>
        </div>

        {/* 分类导航 */}
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          <button
            onClick={() => setFilterType('all')}
            className={cn(
              'w-full flex items-center justify-between px-2 py-1.5 text-sm transition-colors',
              filterType === 'all' ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:bg-muted hover:text-foreground'
            )}
          >
            <span className="flex items-center gap-2"><Hash className="h-3.5 w-3.5" />{t.knowledge.allEntries}</span>
            <Badge variant="outline" className="text-xs h-4 px-1">{items.length}</Badge>
          </button>

          <Separator className="my-2" />
          <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-2 mb-1">
            {t.knowledge.bySourceType}
          </p>

          {SECTION_CONFIG.map(({ type, label }) => {
            const Icon = SOURCE_ICONS[type];
            const count = typeCounts[type];
            return (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={cn(
                  'w-full flex items-center justify-between px-2 py-1.5 text-sm transition-colors',
                  filterType === type ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                )}
              >
                <span className="flex items-center gap-2"><Icon className="h-3.5 w-3.5" />{label}</span>
                {count > 0 && <Badge variant="outline" className="text-xs h-4 px-1">{count}</Badge>}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-border">
          <Button size="sm" className="w-full" onClick={() => setShowNew(true)}>
            <Plus className="h-3.5 w-3.5 mr-1.5" />{t.knowledge.newEntry}
          </Button>
        </div>
      </aside>

      {/* 主内容区 */}
      <main className="flex-1 min-w-0 flex flex-col">
        {/* 顶部工具栏 */}
        <div className="sticky top-0 z-10 bg-card/95 backdrop-blur border-b border-border px-6 py-3 flex flex-col md:flex-row gap-3">
          <div className="relative flex-1 min-w-0">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={t.knowledge.searchPlaceholder}
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          {/* 移动端分类筛选 */}
          <Select value={filterType} onValueChange={(v) => setFilterType(v as typeof filterType)}>
            <SelectTrigger className="w-full md:w-36 shrink-0 lg:hidden">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t.knowledge.filterAll}</SelectItem>
              <SelectItem value="evidence">{t.knowledge.filterEvidence}</SelectItem>
              <SelectItem value="video">{t.knowledge.filterVideo}</SelectItem>
              <SelectItem value="document">{t.knowledge.filterDocument}</SelectItem>
              <SelectItem value="text">{t.knowledge.filterText}</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex gap-2 shrink-0">
            <Button size="sm" variant="outline" onClick={() => void loadItems()}>
              <RefreshCw className="h-3.5 w-3.5" />
            </Button>
            <Button size="sm" className="lg:hidden" onClick={() => setShowNew(true)}>
              <Plus className="h-3.5 w-3.5 mr-1" />{t.common.new}
            </Button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {loading ? (
            <div className="space-y-3">
              {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-16 w-full bg-muted" />)}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
              <BookOpen className="h-12 w-12 mb-3 opacity-20" />
              <p className="font-medium">
                {searchQuery ? t.knowledge.emptySearch.replace('{q}', searchQuery) : t.knowledge.emptyTitle}
              </p>
              <p className="text-sm mt-1">
                {!searchQuery && t.knowledge.emptyDesc}
              </p>
            </div>
          ) : filterType === 'all' ? (
            /* 全部视图：按类型分段展示 */
            SECTION_CONFIG.map(({ type, label, desc }) => {
              const sectionItems = grouped[type];
              if (!sectionItems?.length) return null;
              const Icon = SOURCE_ICONS[type];
              return (
                <section key={type}>
                  <div className="flex items-center gap-3 mb-3 pb-2 border-b-2 border-border">
                    <div className={cn(
                      'flex items-center gap-1.5 px-2 py-0.5 text-xs font-semibold border',
                      SOURCE_BADGE_CLS[type]
                    )}>
                      <Icon className="h-3 w-3" />
                      {label}
                    </div>
                    <span className="text-xs text-muted-foreground">{desc}</span>
                    <span className="ml-auto text-xs text-muted-foreground">
                      {t.knowledge.recordCount.replace('{n}', String(sectionItems.length))}
                    </span>
                  </div>
                  <div className="divide-y divide-transparent">
                    {sectionItems.map(renderItem)}
                  </div>
                </section>
              );
            })
          ) : (
            /* 单类型视图 */
            <div>
              <div className="flex items-center gap-2 mb-4">
                {(() => { const Icon = SOURCE_ICONS[filterType]; return <Icon className="h-4 w-4 text-muted-foreground" />; })()}
                <span className="text-sm font-semibold text-foreground">
                  {SECTION_CONFIG.find((s) => s.type === filterType)?.label}
                </span>
                <span className="text-xs text-muted-foreground">
                  {t.knowledge.recordCount.replace('{n}', String(filtered.length))}
                </span>
              </div>
              <div className="divide-y divide-transparent">
                {filtered.map(renderItem)}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* 条目详情（维基文章样式）*/}
      {viewItem && (
        <ArticleView item={viewItem} onEdit={() => handleEdit(viewItem)} onClose={() => setViewItem(null)} />
      )}

      {/* 编辑 Dialog */}
      <Dialog open={!!editItem} onOpenChange={() => setEditItem(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-3xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>{t.knowledge.editEntry}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-normal block mb-1">{t.knowledge.titleLabel}</label>
              <Input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-normal block mb-1">{t.knowledge.contentLabel}</label>
              <EditableMarkdown value={editContent} onChange={setEditContent} />
            </div>
            <div className="flex gap-3">
              <Button onClick={() => void handleSave()} disabled={saving} className="flex-1">
                {saving ? t.common.saving : <><Check className="h-4 w-4 mr-2" />{t.common.save}</>}
              </Button>
              <Button variant="outline" onClick={() => setEditItem(null)}>
                <X className="h-4 w-4 mr-2" />{t.common.cancel}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* 新建条目 Dialog（带去重提示）*/}
      <Dialog open={showNew} onOpenChange={setShowNew}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>{t.knowledge.newTitle}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="flex items-start gap-2 p-3 bg-blue-50 border border-blue-200 text-xs text-blue-700">
              <GitMerge className="h-3.5 w-3.5 shrink-0 mt-0.5" />
              <span>{t.knowledge.dedupHint}</span>
            </div>
            <div>
              <label className="text-sm font-normal block mb-1">{t.knowledge.titleLabel}</label>
              <Input
                placeholder={t.knowledge.titleLabel + '...'}
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-normal block mb-1">{t.knowledge.contentLabel}</label>
              <Textarea
                placeholder={t.knowledge.contentPlaceholder}
                className="min-h-48 font-mono text-sm resize-y"
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
              />
            </div>
            <div className="flex gap-3">
              <Button onClick={() => void handleCreateNew()} disabled={creating} className="flex-1">
                {creating ? t.knowledge.submitChecking : <><Plus className="h-4 w-4 mr-2" />{t.knowledge.submitBtn}</>}
              </Button>
              <Button variant="outline" onClick={() => setShowNew(false)}>{t.common.cancel}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* 去重合并 Dialog */}
      {mergeCtx && (
        <MergeDialog
          open
          newTitle={mergeCtx.title}
          newContent={mergeCtx.content}
          candidates={mergeCtx.candidates}
          onMerge={(id) => doMerge(id)}
          onCreateNew={() => doCreateNew(mergeCtx.title, mergeCtx.content, mergeCtx.sourceType)}
          onClose={() => setMergeCtx(null)}
        />
      )}

      {/* 删除确认 */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>{t.common.confirmDelete}</AlertDialogTitle>
            <AlertDialogDescription>{t.common.confirmDeleteDesc}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t.common.cancel}</AlertDialogCancel>
            <AlertDialogAction onClick={() => void handleDelete()}>{t.common.delete}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
