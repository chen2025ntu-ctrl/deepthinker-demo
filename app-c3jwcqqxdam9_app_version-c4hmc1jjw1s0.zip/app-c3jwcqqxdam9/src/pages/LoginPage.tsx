import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { FlaskConical, Eye, EyeOff, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';
import { useLang } from '@/contexts/LangContext';

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useLang();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);

  const from = (location.state as { from?: string })?.from ?? '/';

  const validateUsername = (u: string) => /^[a-zA-Z0-9_]+$/.test(u);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      toast.error(t.login.errFillAll);
      return;
    }
    if (!validateUsername(username)) {
      toast.error(t.login.errUsernameFormat);
      return;
    }
    if (mode === 'register') {
      if (password !== confirmPassword) {
        toast.error(t.login.errPasswordMismatch);
        return;
      }
      if (password.length < 8) {
        toast.error(t.login.errPasswordShort);
        return;
      }
      if (!agreed) {
        toast.error(t.login.errAgree);
        return;
      }
    }

    setLoading(true);
    try {
      const email = `${username}@miaoda.com`;

      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) {
          toast.error(t.login.errLoginFail);
        } else {
          toast.success(t.login.successLogin);
          navigate(from, { replace: true });
        }
      } else {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) {
          const msg = error.message?.includes('already registered')
            ? t.login.errUsernameTaken
            : t.login.errRegisterFail.replace('{msg}', error.message);
          toast.error(msg);
        } else {
          toast.success(t.login.successRegister);
          navigate(from, { replace: true });
        }
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="flex items-center justify-center w-12 h-12 bg-primary rounded-sm mb-3">
            <FlaskConical className="h-6 w-6 text-primary-foreground" />
          </div>
          <h1 className="text-lg font-bold text-foreground text-balance text-center">
            {t.login.title}
          </h1>
          <p className="text-xs text-muted-foreground mt-1">{t.login.subtitle}</p>
        </div>

        {/* 模式切换 */}
        <div className="flex border border-border mb-6">
          {(['login', 'register'] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`flex-1 py-2 text-sm font-medium transition-colors ${
                mode === m
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              {m === 'login' ? t.login.loginTab : t.login.registerTab}
            </button>
          ))}
        </div>

        {/* 表单 */}
        <form onSubmit={(e) => void handleSubmit(e)} className="space-y-4">
          <div>
            <label className="text-sm font-normal text-foreground block mb-1.5">{t.login.usernameLabel}</label>
            <Input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder={t.login.usernamePlaceholder}
              autoComplete="username"
              disabled={loading}
            />
          </div>
          <div>
            <label className="text-sm font-normal text-foreground block mb-1.5">{t.login.passwordLabel}</label>
            <div className="relative">
              <Input
                type={showPwd ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={mode === 'register' ? t.login.passwordPlaceholderNew : t.login.passwordPlaceholderLogin}
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                disabled={loading}
                className="pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPwd((v) => !v)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          {mode === 'register' && (
            <>
              <div>
                <label className="text-sm font-normal text-foreground block mb-1.5">{t.login.confirmPasswordLabel}</label>
                <Input
                  type={showPwd ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder={t.login.confirmPasswordPlaceholder}
                  autoComplete="new-password"
                  disabled={loading}
                />
              </div>
              <div className="flex items-start gap-2.5 min-h-12">
                <Checkbox
                  id="agree"
                  checked={agreed}
                  onCheckedChange={(c) => setAgreed(!!c)}
                  disabled={loading}
                  className="mt-0.5 shrink-0"
                />
                <label htmlFor="agree" className="text-xs text-muted-foreground leading-relaxed cursor-pointer">
                  {t.login.agreePrefix}
                  <span className="text-primary mx-0.5 hover:underline cursor-pointer">{t.login.agreeTerms}</span>
                  {t.login.agreeAnd}
                  <span className="text-primary mx-0.5 hover:underline cursor-pointer">{t.login.agreePrivacy}</span>
                  {t.login.agreeSuffix}
                </label>
              </div>
            </>
          )}

          <Button type="submit" className="w-full h-10" disabled={loading}>
            {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            {mode === 'login' ? t.login.loginBtn : t.login.registerBtn}
          </Button>
        </form>

        <p className="text-center text-xs text-muted-foreground mt-6">
          {mode === 'login' ? t.login.noAccount : t.login.hasAccount}
          <button
            onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
            className="text-primary ml-1 hover:underline"
          >
            {mode === 'login' ? t.login.goRegister : t.login.goLogin}
          </button>
        </p>
      </div>
    </div>
  );
}
