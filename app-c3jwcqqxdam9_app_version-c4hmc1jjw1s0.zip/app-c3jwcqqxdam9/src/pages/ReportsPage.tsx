import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Plus, Loader2, Download, Edit2, Check, X, Eye,
  Trash2, BarChart3, Layers
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { reportService, topicService, evidenceCardService } from '@/services/database';
import type { ResearchReport, Topic, EvidenceCard } from '@/types/types';
import { DIMENSION_LABELS, DIMENSION_COLORS } from '@/types/types';
import { sendStreamRequest, parseGeminiChunk } from '@/lib/sse';
import { cn } from '@/lib/utils';
import { useLang } from '@/contexts/LangContext';

export default function ReportsPage() {
  const { t, lang } = useLang();
  const [reports, setReports] = useState<ResearchReport[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedTopicIds, setSelectedTopicIds] = useState<Set<string>>(new Set());
  const [createTitle, setCreateTitle] = useState('');
  const [topicCards, setTopicCards] = useState<EvidenceCard[]>([]);
  const [selectedCardIds, setSelectedCardIds] = useState<Set<string>>(new Set());
  const [loadingCards, setLoadingCards] = useState(false);
  const [creating, setCreating] = useState(false);
  const [viewReport, setViewReport] = useState<ResearchReport | null>(null);
  const [editReport, setEditReport] = useState<ResearchReport | null>(null);
  const [editContent, setEditContent] = useState('');
  const [editTitle, setEditTitle] = useState('');
  const [saving, setSaving] = useState(false);
  const [generatingId, setGeneratingId] = useState<string | null>(null);
  const [streamContent, setStreamContent] = useState('');
  const abortRef = useRef<AbortController | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [reps, tops] = await Promise.all([reportService.list(), topicService.list()]);
      setReports(reps);
      setTopics(tops);
    } catch {
      toast.error(t.reports.toastLoadFail);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void loadData(); }, [loadData]);

  const handleTopicToggle = async (topicId: string, checked: boolean) => {
    const next = new Set(selectedTopicIds);
    if (checked) next.add(topicId);
    else next.delete(topicId);
    setSelectedTopicIds(next);

    if (next.size === 0) {
      setTopicCards([]);
      setSelectedCardIds(new Set());
      return;
    }

    setLoadingCards(true);
    try {
      const results = await Promise.all([...next].map((id) => evidenceCardService.listByTopic(id)));
      const allCards = results.flat().filter((c) => c.status === 'archived');
      setTopicCards(allCards);
      setSelectedCardIds(new Set(allCards.map((c) => c.id)));
      if (!createTitle) {
        const names = [...next].map((id) => topics.find((tp) => tp.id === id)?.title ?? '').filter(Boolean);
        if (names.length === 1) {
          setCreateTitle(t.reports.autoTitleSingle.replace('{name}', names[0]));
        } else if (names.length > 1) {
          setCreateTitle(t.reports.autoTitleMulti.replace('{names}', names.slice(0, 2).join(t.reports.topicNameSep)));
        }
      }
    } catch {
      toast.error(t.reports.toastCardsFail);
    } finally {
      setLoadingCards(false);
    }
  };

  const resetCreateForm = () => {
    setCreateTitle('');
    setSelectedTopicIds(new Set());
    setTopicCards([]);
    setSelectedCardIds(new Set());
  };

  const handleCreate = async () => {
    if (!createTitle.trim() || selectedTopicIds.size === 0) {
      toast.error(t.reports.toastErrorFill);
      return;
    }
    if (selectedCardIds.size === 0) {
      toast.error(t.reports.toastErrorCards);
      return;
    }
    setCreating(true);
    try {
      const topicIdsArr = [...selectedTopicIds];
      const report = await reportService.create({
        topic_id: topicIdsArr[0],
        topic_ids: topicIdsArr,
        title: createTitle,
        evidence_card_ids: Array.from(selectedCardIds),
      });
      toast.success(t.reports.toastGenerated);
      setShowCreateDialog(false);
      resetCreateForm();
      await loadData();
      void handleGenerate(report);
    } catch {
      toast.error(t.reports.toastCreateFail);
    } finally {
      setCreating(false);
    }
  };

  const handleGenerate = async (report: ResearchReport) => {
    setGeneratingId(report.id);
    setStreamContent('');

    let cards: EvidenceCard[] = [];
    try {
      const allTopicIds = report.topic_ids?.length ? report.topic_ids : [report.topic_id];
      const results = await Promise.all(allTopicIds.map((id) => evidenceCardService.listByTopic(id)));
      const all = results.flat();
      cards = all.filter((c) => report.evidence_card_ids.includes(c.id));
    } catch {
      toast.error(t.reports.toastCardsFail);
      setGeneratingId(null);
      return;
    }

    await reportService.update(report.id, { status: 'generating' });
    setReports((prev) => prev.map((r) => (r.id === report.id ? { ...r, status: 'generating' } : r)));

    abortRef.current = new AbortController();
    let fullContent = '';

    // 英文模式优先读取 en 版卡片字段，保证 prompt 语言一致
    const cardSummaries = cards
      .map((c, i) => {
        const dimLabel = lang === 'en' ? (t.dimension[c.dimension] ?? c.dimension) : DIMENSION_LABELS[c.dimension];
        const summary = lang === 'en' && c.summary_en ? c.summary_en : c.summary;
        return `[${t.evidence.cardLabel}${i + 1}] [${dimLabel}] ${c.title}\n${t.evidence.summaryLabel}${summary}`;
      })
      .join('\n\n');

    const allTopicIds = report.topic_ids?.length ? report.topic_ids : [report.topic_id];
    const topicTitles = allTopicIds.map((id) => topics.find((tp) => tp.id === id)?.title ?? '').filter(Boolean);

    try {
      await sendStreamRequest({
        functionName: 'generate-report',
        requestBody: { topicTitles, reportTitle: report.title, cardSummaries, lang },
        onData: (data) => {
          const chunk = parseGeminiChunk(data);
          if (chunk) { fullContent += chunk; setStreamContent(fullContent); }
        },
        onComplete: async () => {
          // 根据当前语言保存到对应列
          const contentUpdate = lang === 'en'
            ? { content_en: fullContent, status: 'completed' as const }
            : { content: fullContent, status: 'completed' as const };
          await reportService.update(report.id, contentUpdate);
          setReports((prev) =>
            prev.map((r) => (r.id === report.id ? { ...r, ...contentUpdate } : r))
          );
          setGeneratingId(null);
          setStreamContent('');
          toast.success(t.reports.toastGenerateDone);
        },
        onError: async (err) => {
          toast.error(`${t.reports.toastGenerateFail}：${err.message}`);
          await reportService.update(report.id, { status: 'draft' });
          setReports((prev) => prev.map((r) => (r.id === report.id ? { ...r, status: 'draft' } : r)));
          setGeneratingId(null);
          setStreamContent('');
        },
        signal: abortRef.current.signal,
      });
    } catch {
      setGeneratingId(null);
    }
  };

  const handleSaveEdit = async () => {
    if (!editReport) return;
    setSaving(true);
    try {
      const contentUpdate = lang === 'en'
        ? { title: editTitle, content_en: editContent }
        : { title: editTitle, content: editContent };
      await reportService.update(editReport.id, contentUpdate);
      setReports((prev) =>
        prev.map((r) => (r.id === editReport.id ? { ...r, ...contentUpdate } : r))
      );
      toast.success(t.reports.toastSaved);
      setEditReport(null);
    } catch {
      toast.error(t.reports.toastSaveFail);
    } finally {
      setSaving(false);
    }
  };

  const handleDownload = (report: ResearchReport) => {
    const body = lang === 'en' ? (report.content_en || report.content) : report.content;
    const blob = new Blob([body], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.title}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDelete = async (id: string) => {
    try {
      await reportService.remove(id);
      setReports((prev) => prev.filter((r) => r.id !== id));
      toast.success(t.reports.toastDeleted);
    } catch {
      toast.error(t.reports.toastDeleteFail);
    }
  };

  const getTopicNames = (report: ResearchReport) => {
    const ids = report.topic_ids?.length ? report.topic_ids : [report.topic_id];
    return ids.map((id) => topics.find((tp) => tp.id === id)?.title ?? '').filter(Boolean).join(t.reports.topicNameSep);
  };

  const statusBadge = (status: ResearchReport['status']) => {
    const map: Record<string, { label: string; cls: string }> = {
      draft:      { label: t.reports.statusDraft,      cls: 'bg-muted text-muted-foreground' },
      generating: { label: t.reports.statusGenerating, cls: 'bg-blue-50 text-blue-600 border-blue-200' },
      completed:  { label: t.reports.statusCompleted,  cls: 'bg-emerald-50 text-emerald-600 border-emerald-200' },
    };
    const cfg = map[status] ?? map['draft'];
    return <Badge variant="outline" className={cfg.cls}>{cfg.label}</Badge>;
  };

  return (
    <div className="p-6">
      <div className="mb-6 flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground text-balance">{t.reports.pageTitle}</h1>
          <p className="text-sm text-muted-foreground mt-1">{t.reports.pageDesc}</p>
        </div>
        <Button onClick={() => setShowCreateDialog(true)} size="sm">
          <Plus className="h-4 w-4 mr-1" />{t.reports.newReport}
        </Button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-28 bg-muted" />)}
        </div>
      ) : reports.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
          <BarChart3 className="h-10 w-10 mb-3 opacity-30" />
          <p className="font-medium">{t.reports.noReports}</p>
          <p className="text-sm mt-1">{t.reports.noReportsDesc}</p>
        </div>
      ) : (
        <div className="space-y-4">
          {reports.map((report) => {
            const isGenerating = generatingId === report.id;
            const multiTopic = (report.topic_ids?.length ?? 0) > 1;
            return (
              <Card key={report.id}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <h3 className="font-semibold text-foreground text-balance">{report.title}</h3>
                        {statusBadge(isGenerating ? 'generating' : report.status)}
                        {multiTopic && (
                          <Badge variant="outline" className="text-xs bg-purple-50 text-purple-600 border-purple-200">
                            <Layers className="h-3 w-3 mr-1" />
                            {t.reports.multiTopicBadge.replace('{n}', String(report.topic_ids.length))}
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mb-2">
                        {t.reports.topicLabel}{getTopicNames(report)} · {t.reports.evidenceCardCount.replace('{n}', String(report.evidence_card_ids.length))} ·{' '}
                        {new Date(report.created_at).toLocaleDateString()}
                      </p>
                      {isGenerating && streamContent && (
                        <div className="bg-muted/40 border border-border p-3 max-h-32 overflow-y-auto">
                          <pre className="whitespace-pre-wrap font-sans text-xs text-foreground">{streamContent}</pre>
                          <span className="inline-block w-1 h-3 bg-primary animate-pulse ml-0.5" />
                        </div>
                      )}
                      {isGenerating && !streamContent && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Loader2 className="h-3 w-3 animate-spin" /><span>{t.reports.generatingLabel}</span>
                        </div>
                      )}
                      {!isGenerating && report.content && (
                        <p className="text-sm text-muted-foreground line-clamp-2 text-pretty">
                          {(lang === 'en' ? (report.content_en || report.content) : report.content).replace(/^#+\s*/gm, '').slice(0, 200)}
                        </p>
                      )}
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      {(report.status === 'completed' || report.status === 'draft') && !isGenerating && (
                        <>
                          <Button size="icon" variant="ghost" title={t.common.view} onClick={() => setViewReport(report)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button size="icon" variant="ghost" title={t.common.edit} onClick={() => {
                            setEditReport(report); setEditTitle(report.title);
                            setEditContent(lang === 'en' ? (report.content_en || '') : report.content);
                          }}>
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button size="icon" variant="ghost" title={t.common.download} onClick={() => handleDownload(report)}>
                            <Download className="h-4 w-4" />
                          </Button>
                          {report.status === 'draft' && (
                            <Button size="sm" variant="outline" onClick={() => void handleGenerate(report)}>
                              {t.reports.regenBtn}
                            </Button>
                          )}
                        </>
                      )}
                      {isGenerating && (
                        <Button size="sm" variant="outline" onClick={() => abortRef.current?.abort()}>
                          {t.reports.stopBtn}
                        </Button>
                      )}
                      {!isGenerating && (
                        <Button size="icon" variant="ghost" onClick={() => void handleDelete(report.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* 新建报告 Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={(o) => { setShowCreateDialog(o); if (!o) resetCreateForm(); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{t.reports.newReportTitle}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-normal">{t.reports.selectTopicsLabel}</label>
                <span className="text-xs text-muted-foreground">
                  {t.reports.selectedCount.replace('{n}', String(selectedTopicIds.size))}
                </span>
              </div>
              {topics.length === 0 ? (
                <p className="text-sm text-muted-foreground py-3 text-center bg-muted/30">
                  {t.reports.noTopicsHint}
                </p>
              ) : (
                <div className="border border-border divide-y divide-border max-h-48 overflow-y-auto">
                  {topics.map((topic) => (
                    <label key={topic.id} className="flex items-center gap-3 px-3 py-2.5 cursor-pointer hover:bg-muted/40 transition-colors">
                      <Checkbox
                        checked={selectedTopicIds.has(topic.id)}
                        onCheckedChange={(v) => void handleTopicToggle(topic.id, !!v)}
                        className="shrink-0"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-foreground truncate">{topic.title}</p>
                        {topic.description && (
                          <p className="text-xs text-muted-foreground truncate">{topic.description}</p>
                        )}
                      </div>
                    </label>
                  ))}
                </div>
              )}
            </div>

            <div>
              <label className="text-sm font-normal block mb-1">{t.reports.reportTitle}</label>
              <Input
                placeholder={t.reports.titlePlaceholder}
                value={createTitle}
                onChange={(e) => setCreateTitle(e.target.value)}
              />
            </div>

            {loadingCards && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground py-2">
                <Loader2 className="h-3 w-3 animate-spin" />{t.reports.loadingCards}
              </div>
            )}
            {!loadingCards && selectedTopicIds.size > 0 && topicCards.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-normal">{t.reports.selectCardsLabel}</label>
                  <div className="flex items-center gap-2">
                    <button className="text-xs text-primary hover:underline"
                      onClick={() => setSelectedCardIds(new Set(topicCards.map((c) => c.id)))}>
                      {t.reports.selectAll}
                    </button>
                    <span className="text-muted-foreground text-xs">/</span>
                    <button className="text-xs text-muted-foreground hover:underline"
                      onClick={() => setSelectedCardIds(new Set())}>
                      {t.reports.deselectAll}
                    </button>
                    <span className="text-xs text-muted-foreground">
                      {t.reports.selectedCards
                        .replace('{sel}', String(selectedCardIds.size))
                        .replace('{total}', String(topicCards.length))}
                    </span>
                  </div>
                </div>
                <div className="max-h-52 overflow-y-auto border border-border divide-y divide-border">
                  {topicCards.map((card) => (
                    <label key={card.id} className="flex items-start gap-2 cursor-pointer hover:bg-muted/30 px-3 py-2 transition-colors">
                      <Checkbox
                        checked={selectedCardIds.has(card.id)}
                        onCheckedChange={(v) => {
                          setSelectedCardIds((prev) => {
                            const next = new Set(prev);
                            if (v) next.add(card.id); else next.delete(card.id);
                            return next;
                          });
                        }}
                        className="mt-0.5 shrink-0"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className={cn('text-xs px-1 border', DIMENSION_COLORS[card.dimension])}>
                            {DIMENSION_LABELS[card.dimension]}
                          </span>
                          <span className="text-sm text-foreground truncate">{card.title}</span>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">{card.summary}</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            )}
            {!loadingCards && selectedTopicIds.size > 0 && topicCards.length === 0 && (
              <div className="text-sm text-muted-foreground text-center py-4 bg-muted/30">
                {t.reports.noCardsHint}
              </div>
            )}

            <div className="flex gap-3 pt-1">
              <Button
                className="flex-1"
                onClick={() => void handleCreate()}
                disabled={creating || !createTitle.trim() || selectedTopicIds.size === 0 || selectedCardIds.size === 0}
              >
                {creating
                  ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />{t.reports.creating}</>
                  : t.reports.createBtn}
              </Button>
              <Button variant="outline" onClick={() => { setShowCreateDialog(false); resetCreateForm(); }}>
                {t.common.cancel}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* 查看报告 */}
      <Dialog open={!!viewReport} onOpenChange={() => setViewReport(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-4xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-balance">{viewReport?.title}</DialogTitle>
          </DialogHeader>
          {viewReport && (() => {
            const displayContent = lang === 'en'
              ? (viewReport.content_en || '')
              : (viewReport.content || '');
            const missingHint = lang === 'en' && !viewReport.content_en
              ? t.reports.noEnContent
              : lang === 'zh' && !viewReport.content
              ? t.reports.noZhContent
              : null;
            return (
              <div>
                <div className="flex gap-2 mb-4">
                  {statusBadge(viewReport.status)}
                  <Button size="sm" variant="outline" onClick={() => handleDownload(viewReport)}>
                    <Download className="h-3 w-3 mr-1" />{t.reports.downloadMd}
                  </Button>
                </div>
                {missingHint ? (
                  <div className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-3">
                    <p className="text-sm text-center text-pretty">{missingHint}</p>
                    <Button size="sm" variant="outline" onClick={() => { setViewReport(null); void handleGenerate(viewReport); }}>
                      {t.reports.regenBtn}
                    </Button>
                  </div>
                ) : (
                  <pre className="whitespace-pre-wrap font-sans text-sm text-foreground bg-muted/30 p-4 overflow-auto leading-relaxed">
                    {displayContent || t.reports.noContent}
                  </pre>
                )}
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      {/* 编辑报告 */}
      <Dialog open={!!editReport} onOpenChange={() => setEditReport(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-4xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>{t.reports.editReportTitle}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-normal block mb-1">{t.reports.titleFieldLabel}</label>
              <Input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-normal block mb-1">{t.reports.bodyFieldLabel}</label>
              <textarea
                className="w-full min-h-96 p-3 font-mono text-sm border border-border bg-card text-foreground resize-y focus:outline-none focus:ring-1 focus:ring-ring"
                value={editContent}
                onChange={(e) => setEditContent(e.target.value)}
              />
            </div>
            <div className="flex gap-3">
              <Button className="flex-1" onClick={() => void handleSaveEdit()} disabled={saving}>
                {saving ? t.common.saving : <><Check className="h-4 w-4 mr-2" />{t.common.save}</>}
              </Button>
              <Button variant="outline" onClick={() => setEditReport(null)}>
                <X className="h-4 w-4 mr-2" />{t.common.cancel}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
