import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Search, Plus, Loader2, ChevronDown, ChevronRight,
  Trash2, Edit2, Check, X, RefreshCw,
  BookOpen, GraduationCap, Briefcase, Users, TrendingUp,
  Sliders, PlayCircle, PlusCircle, Target,
  Share2, UserPlus, GripVertical, MoreHorizontal,
  ChevronLeft, Layers,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';
import { topicService, subQueryService, topicCollaboratorService } from '@/services/database';
import type { Topic, SubQuery, Dimension, TopicCollaborator } from '@/types/types';
import { DIMENSION_LABELS, DIMENSION_COLORS } from '@/types/types';
import { cn } from '@/lib/utils';
import { useLang } from '@/contexts/LangContext';
import { useAuth } from '@/contexts/AuthContext';

// ── 维度图标映射 ──────────────────────────────────────────────────────────
const DIMENSION_ICONS: Record<Dimension, React.ElementType> = {
  academic: GraduationCap,
  industry: Briefcase,
  recruitment: Users,
  investment: TrendingUp,
};
const ALL_DIMENSIONS: Dimension[] = ['academic', 'industry', 'recruitment', 'investment'];

// ── 树构建工具 ────────────────────────────────────────────────────────────
function buildTree(flat: Topic[]): Topic[] {
  const map = new Map<string, Topic & { children: Topic[] }>();
  flat.forEach((t) => map.set(t.id, { ...t, children: [] }));
  const roots: Topic[] = [];
  flat.forEach((t) => {
    const node = map.get(t.id)!;
    if (t.parent_id && map.has(t.parent_id)) {
      map.get(t.parent_id)!.children!.push(node);
    } else {
      roots.push(node);
    }
  });
  return roots;
}

function flattenTree(tree: Topic[]): Topic[] {
  const result: Topic[] = [];
  const visit = (nodes: Topic[]) => {
    nodes.forEach((n) => {
      result.push(n);
      if (n.children?.length) visit(n.children);
    });
  };
  visit(tree);
  return result;
}

// ── ResearchState ─────────────────────────────────────────────────────────
interface ResearchState {
  subQueries: SubQuery[];
  phase: 'idle' | 'generating' | 'editing' | 'searching' | 'done';
  breadth: number;
}

// ══════════════════════════════════════════════════════════════════════════
export default function ResearchPage() {
  const { t } = useLang();
  const { profile } = useAuth();

  const BREADTH_LABELS: Record<number, { label: string; desc: string }> = {
    1: { label: t.research.breadth1Label, desc: t.research.breadth1Desc },
    2: { label: t.research.breadth2Label, desc: t.research.breadth2Desc },
    3: { label: t.research.breadth3Label, desc: t.research.breadth3Desc },
    4: { label: t.research.breadth4Label, desc: t.research.breadth4Desc },
    5: { label: t.research.breadth5Label, desc: t.research.breadth5Desc },
  };

  // ── 数据状态 ──
  const [topics, setTopics] = useState<Topic[]>([]);
  const [treeRoots, setTreeRoots] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTopicId, setSelectedTopicId] = useState<string | null>(null);
  const [collapsedNodes, setCollapsedNodes] = useState<Set<string>>(new Set());

  // ── 编辑状态 ──
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameText, setRenameText] = useState('');
  const [deleteTopicId, setDeleteTopicId] = useState<string | null>(null);
  const [addingChildOf, setAddingChildOf] = useState<string | null>(null); // parentId, null = root
  const [newTopicTitle, setNewTopicTitle] = useState('');
  const [addingTopic, setAddingTopic] = useState(false);
  const [showAddRoot, setShowAddRoot] = useState(false);

  // ── 协作状态 ──
  const [shareTopicId, setShareTopicId] = useState<string | null>(null);
  const [collaborators, setCollaborators] = useState<TopicCollaborator[]>([]);
  const [inviteUsername, setInviteUsername] = useState('');
  const [inviting, setInviting] = useState(false);

  // ── 拖拽状态 ──
  const [dragId, setDragId] = useState<string | null>(null);
  const [dropTargetId, setDropTargetId] = useState<string | null>(null);

  // ── 研究状态 ──
  const [researchStates, setResearchStates] = useState<Record<string, ResearchState>>({});
  const [editingQuery, setEditingQuery] = useState<{ id: string; text: string } | null>(null);
  const [addingQuery, setAddingQuery] = useState<{ topicId: string; dimension: Dimension; text: string } | null>(null);

  // ── 移动端展开面板 ──
  const [mobileShowWorkspace, setMobileShowWorkspace] = useState(false);

  const loadTopics = useCallback(async () => {
    setLoading(true);
    try {
      const data = await topicService.list();
      setTopics(data);
      setTreeRoots(buildTree(data));
    } catch {
      toast.error(t.research.toastLoadFail);
    } finally {
      setLoading(false);
    }
  }, [t.research.toastLoadFail]);

  useEffect(() => { void loadTopics(); }, [loadTopics]);

  const selectedTopic = topics.find((tp) => tp.id === selectedTopicId) ?? null;

  // ── 加载指定专题的研究状态 ──
  const ensureResearchState = useCallback(async (topicId: string) => {
    if (researchStates[topicId]) return;
    try {
      const sqs = await subQueryService.listByTopic(topicId);
      setResearchStates((prev) => ({
        ...prev,
        [topicId]: {
          subQueries: sqs,
          phase: sqs.length > 0 ? 'editing' : 'idle',
          breadth: 3,
        },
      }));
    } catch {
      toast.error(t.research.toastLoadSubFail);
    }
  }, [researchStates, t.research.toastLoadSubFail]);

  const handleSelectTopic = (topicId: string) => {
    setSelectedTopicId(topicId);
    setMobileShowWorkspace(true);
    void ensureResearchState(topicId);
  };

  // ── 折叠/展开子节点 ──
  const toggleCollapse = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCollapsedNodes((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  // ── 重命名 ──
  const startRename = (topic: Topic, e: React.MouseEvent) => {
    e.stopPropagation();
    setRenamingId(topic.id);
    setRenameText(topic.title);
  };

  const commitRename = async (id: string) => {
    if (!renameText.trim()) { setRenamingId(null); return; }
    try {
      await topicService.update(id, { title: renameText.trim() });
      setTopics((prev) => prev.map((t) => t.id === id ? { ...t, title: renameText.trim() } : t));
      setTreeRoots(buildTree(topics.map((t) => t.id === id ? { ...t, title: renameText.trim() } : t)));
    } catch {
      toast.error(t.common.error);
    } finally {
      setRenamingId(null);
    }
  };

  // ── 添加专题（根/子） ──
  const handleAddTopic = async (parentId: string | null) => {
    if (!newTopicTitle.trim()) return;
    setAddingTopic(true);
    try {
      // 计算 sort_order（同级末尾）
      const siblings = topics.filter((t) => t.parent_id === parentId);
      const maxOrder = siblings.reduce((m, t) => Math.max(m, t.sort_order ?? 0), -1);
      const created = await topicService.create({
        title: newTopicTitle.trim(),
        parent_id: parentId ?? undefined,
        sort_order: maxOrder + 1,
      });
      toast.success(t.research.toastTopicCreated);
      setNewTopicTitle('');
      setAddingChildOf(null);
      setShowAddRoot(false);
      await loadTopics();
      handleSelectTopic(created.id);
    } catch {
      toast.error(t.common.error);
    } finally {
      setAddingTopic(false);
    }
  };

  // ── 删除专题 ──
  const handleDeleteTopic = async () => {
    if (!deleteTopicId) return;
    try {
      await topicService.remove(deleteTopicId);
      if (selectedTopicId === deleteTopicId) {
        setSelectedTopicId(null);
        setMobileShowWorkspace(false);
      }
      setResearchStates((prev) => { const n = { ...prev }; delete n[deleteTopicId]; return n; });
      toast.success(t.research.toastTopicDeleted);
      await loadTopics();
    } catch {
      toast.error(t.research.toastDeleteFail);
    } finally {
      setDeleteTopicId(null);
    }
  };

  // ── 拖拽排序（同级） ──
  const handleDragStart = (e: React.DragEvent, id: string) => {
    setDragId(id);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent, id: string) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (id !== dragId) setDropTargetId(id);
  };

  const handleDrop = async (e: React.DragEvent, targetId: string) => {
    e.preventDefault();
    setDropTargetId(null);
    if (!dragId || dragId === targetId) { setDragId(null); return; }

    const dragTopic = topics.find((t) => t.id === dragId);
    const targetTopic = topics.find((t) => t.id === targetId);
    if (!dragTopic || !targetTopic) { setDragId(null); return; }

    // 只允许同级重排序
    if (dragTopic.parent_id !== targetTopic.parent_id) {
      toast.error(t.research.sameParentOnlyError);
      setDragId(null);
      return;
    }

    // 重新计算 sort_order：交换
    const newOrder = targetTopic.sort_order;
    const oldOrder = dragTopic.sort_order;
    try {
      await topicService.update(dragId, { sort_order: newOrder });
      await topicService.update(targetId, { sort_order: oldOrder });
      await loadTopics();
    } catch {
      toast.error(t.common.error);
    }
    setDragId(null);
  };

  // ── 协作管理 ──
  const openShareDialog = async (topicId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setShareTopicId(topicId);
    setInviteUsername('');
    try {
      const list = await topicCollaboratorService.listByTopic(topicId);
      setCollaborators(list);
    } catch {
      toast.error(t.common.error);
    }
  };

  const handleInvite = async () => {
    if (!inviteUsername.trim() || !shareTopicId) return;
    setInviting(true);
    try {
      const found = await topicCollaboratorService.findUserByUsername(inviteUsername.trim());
      if (!found) {
        toast.error(t.research.inviteUserNotFound.replace('{username}', inviteUsername));
        return;
      }
      await topicCollaboratorService.add(shareTopicId, found.id);
      const list = await topicCollaboratorService.listByTopic(shareTopicId);
      setCollaborators(list);
      setInviteUsername('');
      toast.success(t.research.inviteSuccess.replace('{username}', found.username));
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('duplicate') || msg.includes('unique')) {
        toast.error(t.research.alreadyCollaborator);
      } else {
        toast.error(t.research.inviteFailed.replace('{msg}', msg));
      }
    } finally {
      setInviting(false);
    }
  };

  const handleRemoveCollaborator = async (topicId: string, collaboratorId: string) => {
    try {
      await topicCollaboratorService.remove(topicId, collaboratorId);
      setCollaborators((prev) => prev.filter((c) => c.collaborator_id !== collaboratorId));
      toast.success(t.research.removeCollaboratorSuccess);
    } catch {
      toast.error(t.common.error);
    }
  };

  // ── 生成子检索 ──
  const handleGenerateSubQueries = async (topic: Topic, breadth: number) => {
    setResearchStates((prev) => ({ ...prev, [topic.id]: { ...prev[topic.id]!, phase: 'generating' } }));
    try {
      await subQueryService.removeByTopic(topic.id);
      const { data, error } = await supabase.functions.invoke('generate-sub-queries', {
        body: { topicTitle: topic.title, topicDescription: topic.description ?? '', breadth },
      });
      if (error) { const msg = await error?.context?.text?.(); throw new Error(msg || error.message); }
      const generated = (data as { queries: Array<{ dimension: Dimension; query_text: string }> }).queries;
      await subQueryService.batchCreate(
        generated.map((q, idx) => ({ topic_id: topic.id, dimension: q.dimension, query_text: q.query_text, is_enabled: true, sort_order: idx }))
      );
      const sqs = await subQueryService.listByTopic(topic.id);
      setResearchStates((prev) => ({ ...prev, [topic.id]: { ...prev[topic.id]!, subQueries: sqs, phase: 'editing' } }));
      toast.success(t.research.toastSubGenerated.replace('{n}', String(sqs.length)));
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('429') || msg.includes('频率超限')) toast.error(t.research.toastRateLimit);
      else toast.error(`${t.research.toastGenFail}：${msg}`);
      setResearchStates((prev) => ({ ...prev, [topic.id]: { ...prev[topic.id]!, phase: prev[topic.id]!.subQueries.length > 0 ? 'editing' : 'idle' } }));
    }
  };

  // ── 执行检索 ──
  const handleStartSearch = async (topic: Topic) => {
    const state = researchStates[topic.id];
    if (!state) return;
    const enabledQueries = state.subQueries.filter((q) => q.is_enabled);
    if (enabledQueries.length === 0) { toast.error(t.research.toastNoQuery); return; }
    setResearchStates((prev) => ({ ...prev, [topic.id]: { ...prev[topic.id]!, phase: 'searching' } }));
    try {
      await topicService.updateStatus(topic.id, 'researching');
      const { data, error } = await supabase.functions.invoke('run-research', {
        body: { topicId: topic.id, topicTitle: topic.title, subQueries: enabledQueries.map((q) => ({ id: q.id, dimension: q.dimension, query_text: q.query_text })), searchCount: 5 },
      });
      if (error) { const msg = await error?.context?.text?.(); throw new Error(msg || error.message); }
      const { cardCount } = data as { cardCount: number };
      await topicService.updateStatus(topic.id, 'completed');
      setResearchStates((prev) => ({ ...prev, [topic.id]: { ...prev[topic.id]!, phase: 'done' } }));
      await loadTopics();
      toast.success(t.research.toastSearchDone.replace('{n}', String(cardCount)));
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      toast.error(`${t.research.toastSearchFail}：${msg}`);
      await topicService.updateStatus(topic.id, 'pending');
      setResearchStates((prev) => ({ ...prev, [topic.id]: { ...prev[topic.id]!, phase: 'editing' } }));
    }
  };

  // ── 子检索操作 ──
  const handleToggleQuery = async (topicId: string, queryId: string, enabled: boolean) => {
    try {
      await subQueryService.update(queryId, { is_enabled: enabled });
      setResearchStates((prev) => ({
        ...prev,
        [topicId]: { ...prev[topicId]!, subQueries: prev[topicId]!.subQueries.map((q) => q.id === queryId ? { ...q, is_enabled: enabled } : q) },
      }));
    } catch { toast.error(t.common.error); }
  };

  const handleSaveQueryText = async (topicId: string) => {
    if (!editingQuery) return;
    try {
      await subQueryService.update(editingQuery.id, { query_text: editingQuery.text });
      setResearchStates((prev) => ({
        ...prev,
        [topicId]: { ...prev[topicId]!, subQueries: prev[topicId]!.subQueries.map((q) => q.id === editingQuery.id ? { ...q, query_text: editingQuery.text } : q) },
      }));
      setEditingQuery(null);
    } catch { toast.error(t.common.error); }
  };

  const handleDeleteQuery = async (topicId: string, queryId: string) => {
    try {
      await subQueryService.remove(queryId);
      setResearchStates((prev) => ({
        ...prev,
        [topicId]: { ...prev[topicId]!, subQueries: prev[topicId]!.subQueries.filter((q) => q.id !== queryId) },
      }));
    } catch { toast.error(t.common.error); }
  };

  const handleAddQuery = async (topicId: string) => {
    if (!addingQuery || !addingQuery.text.trim()) return;
    try {
      const existing = researchStates[topicId]?.subQueries ?? [];
      await subQueryService.batchCreate([{ topic_id: topicId, dimension: addingQuery.dimension, query_text: addingQuery.text.trim(), is_enabled: true, sort_order: existing.length }]);
      const sqs = await subQueryService.listByTopic(topicId);
      setResearchStates((prev) => ({ ...prev, [topicId]: { ...prev[topicId]!, subQueries: sqs } }));
      setAddingQuery(null);
      toast.success(t.research.toastQueryAdded);
    } catch { toast.error(t.common.error); }
  };

  // ── 状态徽章 ──
  const statusBadge = (status: Topic['status']) => {
    const map = {
      pending:     { label: t.research.statusPending,     cls: 'bg-muted text-muted-foreground' },
      researching: { label: t.research.statusResearching, cls: 'bg-blue-50 text-blue-600 border-blue-200' },
      completed:   { label: t.research.statusCompleted,   cls: 'bg-emerald-50 text-emerald-600 border-emerald-200' },
    };
    const cfg = map[status];
    return <Badge variant="outline" className={cn('text-[10px] px-1.5 py-0 shrink-0', cfg.cls)}>{cfg.label}</Badge>;
  };

  const isOwner = (topic: Topic) => !topic.owner_id || topic.owner_id === profile?.id;

  // ── 渲染树节点（递归） ──
  const renderTreeNode = (topic: Topic, depth: number = 0): React.ReactNode => {
    const hasChildren = (topic.children?.length ?? 0) > 0;
    const isCollapsed = collapsedNodes.has(topic.id);
    const isSelected = selectedTopicId === topic.id;
    const isDragging = dragId === topic.id;
    const isDropTarget = dropTargetId === topic.id;
    const owned = isOwner(topic);

    return (
      <div key={topic.id} className={cn('select-none', depth > 0 && 'ml-4 border-l border-border pl-0')}>
        <div
          draggable
          onDragStart={(e) => handleDragStart(e, topic.id)}
          onDragOver={(e) => handleDragOver(e, topic.id)}
          onDrop={(e) => void handleDrop(e, topic.id)}
          onDragEnd={() => { setDragId(null); setDropTargetId(null); }}
          onClick={() => handleSelectTopic(topic.id)}
          className={cn(
            'group flex items-center gap-1 px-2 py-1.5 cursor-pointer transition-colors rounded-sm',
            isSelected ? 'bg-primary/10 border border-primary/30' : 'hover:bg-muted/60',
            isDragging && 'opacity-40',
            isDropTarget && 'bg-primary/5 border border-primary/20 border-dashed',
            depth > 0 && 'rounded-l-none border-l-2 border-l-border ml-3'
          )}
        >
          {/* 拖拽手柄 */}
          <span className="opacity-0 group-hover:opacity-50 transition-opacity shrink-0 cursor-grab active:cursor-grabbing">
            <GripVertical className="h-3.5 w-3.5 text-muted-foreground" />
          </span>

          {/* 展开/折叠按钮 */}
          <button
            className="shrink-0 w-4 h-4 flex items-center justify-center text-muted-foreground hover:text-foreground"
            onClick={(e) => hasChildren ? toggleCollapse(topic.id, e) : e.stopPropagation()}
          >
            {hasChildren
              ? (isCollapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />)
              : <span className="w-3.5 h-3.5 flex items-center justify-center"><span className="w-1 h-1 bg-border rounded-full" /></span>
            }
          </button>

          {/* 节点标题 */}
          <div className="flex-1 min-w-0 flex items-center gap-1.5">
            {renamingId === topic.id ? (
              <Input
                value={renameText}
                onChange={(e) => setRenameText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') void commitRename(topic.id);
                  if (e.key === 'Escape') setRenamingId(null);
                  e.stopPropagation();
                }}
                onClick={(e) => e.stopPropagation()}
                onBlur={() => void commitRename(topic.id)}
                autoFocus
                className="h-6 text-xs px-1 py-0 flex-1"
              />
            ) : (
              <span className={cn(
                'text-sm truncate flex-1',
                isSelected ? 'font-semibold text-primary' : 'text-foreground'
              )}>
                {topic.title}
              </span>
            )}
            {renamingId !== topic.id && statusBadge(topic.status)}
            {!owned && (
              <Badge variant="outline" className="text-[10px] px-1 py-0 text-purple-600 border-purple-300 bg-purple-50 shrink-0">
                {t.research.collab}
              </Badge>
            )}
          </div>

          {/* 操作按钮 */}
          <div
            className="flex items-center gap-0.5 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
            onClick={(e) => e.stopPropagation()}
          >
            {/* 添加子节点 */}
            <Button
              size="icon" variant="ghost" className="h-6 w-6"
              title={t.research.addSubTopicTitle}
              onClick={(e) => {
                e.stopPropagation();
                setAddingChildOf(topic.id);
                setNewTopicTitle('');
                // 自动展开
                setCollapsedNodes((prev) => { const n = new Set(prev); n.delete(topic.id); return n; });
              }}
            >
              <Plus className="h-3 w-3" />
            </Button>

            {/* 更多菜单 */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="icon" variant="ghost" className="h-6 w-6">
                  <MoreHorizontal className="h-3.5 w-3.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-36">
                <DropdownMenuItem onClick={(e) => startRename(topic, e)}>
                  <Edit2 className="h-3.5 w-3.5 mr-2" />{t.research.rename}
                </DropdownMenuItem>
                {owned && (
                  <DropdownMenuItem onClick={(e) => void openShareDialog(topic.id, e)}>
                    <Share2 className="h-3.5 w-3.5 mr-2" />{t.research.inviteCollab}
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                {owned && (
                  <DropdownMenuItem
                    className="text-destructive focus:text-destructive"
                    onClick={(e) => { e.stopPropagation(); setDeleteTopicId(topic.id); }}
                  >
                    <Trash2 className="h-3.5 w-3.5 mr-2" />{t.common.delete}
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* 添加子节点输入框 */}
        {addingChildOf === topic.id && (
          <div className="ml-7 mt-1 mb-1 flex gap-1.5">
            <Input
              value={newTopicTitle}
              onChange={(e) => setNewTopicTitle(e.target.value)}
              placeholder={t.research.subTopicPlaceholder}
              autoFocus
              className="h-7 text-sm px-2 flex-1"
              onKeyDown={(e) => {
                if (e.key === 'Enter') void handleAddTopic(topic.id);
                if (e.key === 'Escape') { setAddingChildOf(null); setNewTopicTitle(''); }
              }}
            />
            <Button size="icon" className="h-7 w-7 shrink-0" disabled={addingTopic || !newTopicTitle.trim()} onClick={() => void handleAddTopic(topic.id)}>
              {addingTopic ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
            </Button>
            <Button size="icon" variant="ghost" className="h-7 w-7 shrink-0" onClick={() => { setAddingChildOf(null); setNewTopicTitle(''); }}>
              <X className="h-3 w-3" />
            </Button>
          </div>
        )}

        {/* 子节点递归 */}
        {hasChildren && !isCollapsed && (
          <div>
            {topic.children!.map((child) => renderTreeNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  const totalTopics = flattenTree(treeRoots).length;

  return (
    <div className="flex h-[calc(100vh-0px)] overflow-hidden">
      {/* ══ 左：专题树面板 ══ */}
      <div className={cn(
        'flex flex-col border-r border-border bg-card w-full md:w-72 shrink-0 overflow-hidden',
        mobileShowWorkspace ? 'hidden md:flex' : 'flex'
      )}>
        {/* 树面板头部 */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border shrink-0">
          <div className="flex items-center gap-2">
            <Layers className="h-4 w-4 text-primary" />
            <span className="font-semibold text-sm text-foreground">{t.research.pageTitle}</span>
            {totalTopics > 0 && (
              <Badge variant="outline" className="text-xs px-1.5 py-0">{totalTopics}</Badge>
            )}
          </div>
          <Button
            size="icon" variant="ghost" className="h-7 w-7"
            title={t.research.addRootTopicTitle}
            onClick={() => { setShowAddRoot(true); setAddingChildOf(null); setNewTopicTitle(''); }}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        {/* 添加根节点输入框 */}
        {showAddRoot && (
          <div className="px-3 py-2 border-b border-border shrink-0 flex gap-1.5">
            <Input
              value={newTopicTitle}
              onChange={(e) => setNewTopicTitle(e.target.value)}
              placeholder={t.research.newTopicPlaceholder}
              autoFocus
              className="h-7 text-sm px-2 flex-1"
              onKeyDown={(e) => {
                if (e.key === 'Enter') void handleAddTopic(null);
                if (e.key === 'Escape') { setShowAddRoot(false); setNewTopicTitle(''); }
              }}
            />
            <Button size="icon" className="h-7 w-7 shrink-0" disabled={addingTopic || !newTopicTitle.trim()} onClick={() => void handleAddTopic(null)}>
              {addingTopic ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
            </Button>
            <Button size="icon" variant="ghost" className="h-7 w-7 shrink-0" onClick={() => { setShowAddRoot(false); setNewTopicTitle(''); }}>
              <X className="h-3 w-3" />
            </Button>
          </div>
        )}

        {/* 树内容 */}
        <div className="flex-1 overflow-y-auto py-2 px-2">
          {loading ? (
            <div className="space-y-1.5 px-1">
              {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-8 bg-muted" />)}
            </div>
          ) : treeRoots.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 px-4 text-center text-muted-foreground">
              <BookOpen className="h-8 w-8 mb-2 opacity-30" />
              <p className="text-sm font-medium">{t.research.noTopics}</p>
              <p className="text-xs mt-1 text-pretty">{t.research.noTopicsDesc}</p>
              <Button size="sm" className="mt-4 gap-1" onClick={() => setShowAddRoot(true)}>
                <Plus className="h-3.5 w-3.5" />{t.research.newTopicBtn}
              </Button>
            </div>
          ) : (
            <div className="space-y-0.5">
              {treeRoots.map((root) => renderTreeNode(root, 0))}
            </div>
          )}
        </div>

        {/* 树面板底部提示 */}
        {!loading && treeRoots.length > 0 && (
          <div className="px-4 py-2 border-t border-border shrink-0">
            <p className="text-[11px] text-muted-foreground">{t.research.dragHint}</p>
          </div>
        )}
      </div>

      {/* ══ 右：研究工作区 ══ */}
      <div className={cn(
        'flex-1 min-w-0 flex flex-col overflow-hidden',
        !mobileShowWorkspace ? 'hidden md:flex' : 'flex'
      )}>
        {selectedTopic ? (
          <ResearchWorkspace
            topic={selectedTopic}
            state={researchStates[selectedTopic.id]}
            breadthLabels={BREADTH_LABELS}
            editingQuery={editingQuery}
            addingQuery={addingQuery}
            onSetState={(updater) => setResearchStates((prev) => ({ ...prev, [selectedTopic.id]: updater(prev[selectedTopic.id] ?? { subQueries: [], phase: 'idle', breadth: 3 }) }))}
            onGenerateSubQueries={(breadth) => void handleGenerateSubQueries(selectedTopic, breadth)}
            onStartSearch={() => void handleStartSearch(selectedTopic)}
            onToggleQuery={(qId, en) => void handleToggleQuery(selectedTopic.id, qId, en)}
            onSetEditingQuery={setEditingQuery}
            onSaveQueryText={() => void handleSaveQueryText(selectedTopic.id)}
            onDeleteQuery={(qId) => void handleDeleteQuery(selectedTopic.id, qId)}
            onSetAddingQuery={setAddingQuery}
            onAddQuery={() => void handleAddQuery(selectedTopic.id)}
            statusBadge={statusBadge}
            onMobileBack={() => setMobileShowWorkspace(false)}
            t={t}
          />
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground px-8">
            <Search className="h-10 w-10 mb-3 opacity-20" />
            <p className="font-medium text-center text-balance">{t.research.selectTopicHint}</p>
            <p className="text-sm mt-1 text-center text-pretty">{t.research.selectTopicDesc}</p>
          </div>
        )}
      </div>

      {/* ══ 删除确认 Dialog ══ */}
      <Dialog open={!!deleteTopicId} onOpenChange={() => setDeleteTopicId(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle>{t.research.deleteTopicTitle}</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">{t.research.deleteTopicDesc} {t.research.deleteSubtopicNote}</p>
          <div className="flex gap-3 mt-2">
            <Button variant="destructive" className="flex-1" onClick={() => void handleDeleteTopic()}>{t.research.deleteConfirm}</Button>
            <Button variant="outline" onClick={() => setDeleteTopicId(null)}>{t.common.cancel}</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ══ 协作管理 Dialog ══ */}
      <Dialog open={!!shareTopicId} onOpenChange={() => setShareTopicId(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Share2 className="h-4 w-4" />{t.research.inviteCollabTitle}
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground -mt-1">
            {t.research.inviteCollabDesc}
          </p>

          {/* 邀请输入 */}
          <div className="flex gap-2">
            <Input
              placeholder={t.research.inviteUsernamePlaceholder}
              value={inviteUsername}
              onChange={(e) => setInviteUsername(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') void handleInvite(); }}
              className="flex-1"
            />
            <Button onClick={() => void handleInvite()} disabled={inviting || !inviteUsername.trim()}>
              {inviting ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4 mr-1" />}
              {t.research.inviteBtn}
            </Button>
          </div>

          {/* 已有协作者列表 */}
          {collaborators.length > 0 && (
            <div className="space-y-2 mt-1">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">{t.research.collaboratorsList}</p>
              <div className="space-y-1">
                {collaborators.map((c) => (
                  <div key={c.id} className="flex items-center justify-between px-3 py-2 bg-muted/40 rounded-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-sm bg-primary/20 flex items-center justify-center shrink-0">
                        <span className="text-[11px] font-bold text-primary">
                          {c.collaborator_id[0]?.toUpperCase() ?? 'U'}
                        </span>
                      </div>
                      <span className="text-sm text-foreground truncate">{c.collaborator_id}</span>
                    </div>
                    <Button
                      size="icon" variant="ghost" className="h-6 w-6 text-destructive hover:text-destructive"
                      onClick={() => void handleRemoveCollaborator(shareTopicId!, c.collaborator_id)}
                    >
                      <X className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {collaborators.length === 0 && (
            <p className="text-xs text-muted-foreground text-center py-3">{t.research.noCollaborators}</p>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// 研究工作区组件
// ══════════════════════════════════════════════════════════════════════════
interface WorkspaceProps {
  topic: Topic;
  state: ResearchState | undefined;
  breadthLabels: Record<number, { label: string; desc: string }>;
  editingQuery: { id: string; text: string } | null;
  addingQuery: { topicId: string; dimension: Dimension; text: string } | null;
  onSetState: (updater: (prev: ResearchState) => ResearchState) => void;
  onGenerateSubQueries: (breadth: number) => void;
  onStartSearch: () => void;
  onToggleQuery: (id: string, en: boolean) => void;
  onSetEditingQuery: (v: { id: string; text: string } | null) => void;
  onSaveQueryText: () => void;
  onDeleteQuery: (id: string) => void;
  onSetAddingQuery: (v: { topicId: string; dimension: Dimension; text: string } | null) => void;
  onAddQuery: () => void;
  statusBadge: (status: Topic['status']) => React.ReactNode;
  onMobileBack: () => void;
  t: ReturnType<typeof useLang>['t'];
}

function ResearchWorkspace({
  topic, state, breadthLabels, editingQuery, addingQuery,
  onSetState, onGenerateSubQueries, onStartSearch, onToggleQuery,
  onSetEditingQuery, onSaveQueryText, onDeleteQuery, onSetAddingQuery, onAddQuery,
  statusBadge, onMobileBack, t,
}: WorkspaceProps) {
  const rs = state ?? { subQueries: [], phase: 'idle' as const, breadth: 3 };
  const breadth = rs.breadth ?? 3;
  const phase = rs.phase;
  const isGenerating = phase === 'generating';
  const isSearching = phase === 'searching';
  const hasQueries = rs.subQueries.length > 0;
  const enabledCount = rs.subQueries.filter((q) => q.is_enabled).length;
  const breadthCfg = breadthLabels[breadth]!;

  const setBreadth = (v: number) => onSetState((prev) => ({ ...prev, breadth: v }));

  // 面包屑：顶部路径信息
  const headerRef = useRef<HTMLDivElement>(null);

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* 工作区头部 */}
      <div ref={headerRef} className="flex items-center gap-3 px-6 py-4 border-b border-border shrink-0 bg-card">
        <Button
          variant="ghost" size="icon" className="md:hidden h-8 w-8 shrink-0"
          onClick={onMobileBack}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-base font-bold text-foreground truncate">{topic.title}</h2>
            {statusBadge(topic.status)}
          </div>
          {topic.description && (
            <p className="text-xs text-muted-foreground mt-0.5 text-pretty line-clamp-1">{topic.description}</p>
          )}
        </div>
      </div>

      {/* 工作区主体 */}
      <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">

        {/* ── 阶段一：无子检索 ── */}
        {!hasQueries && !isGenerating && (
          <div className="space-y-5 max-w-xl">
            <BreadthControl
              breadth={breadth}
              breadthLabels={breadthLabels}
              breadthTitle={t.research.breadthTitle}
              breadthFocused={t.research.breadthFocused}
              breadthBroad={t.research.breadthBroad}
              onChange={setBreadth}
            />
            <Button className="w-full gap-2" onClick={() => onGenerateSubQueries(breadth)}>
              <Target className="h-4 w-4" />{t.research.generateSubQueries}
            </Button>
          </div>
        )}

        {/* ── 生成中 ── */}
        {isGenerating && (
          <div className="flex flex-col items-center gap-3 py-16 text-muted-foreground">
            <Loader2 className="h-7 w-7 animate-spin text-primary" />
            <p className="text-sm">{t.research.generateHint}</p>
          </div>
        )}

        {/* ── 有子检索 ── */}
        {hasQueries && !isGenerating && (
          <div className="space-y-5 max-w-xl">
            {/* 广度控制 + 重新生成 */}
            <div className="flex flex-col md:flex-row md:items-end gap-4 p-3 bg-muted/30 border rounded-sm">
              <div className="flex-1 min-w-0">
                <BreadthControl breadth={breadth} breadthLabels={breadthLabels} breadthTitle={t.research.breadthTitle} breadthFocused={t.research.breadthFocused} breadthBroad={t.research.breadthBroad} onChange={setBreadth} />
              </div>
              <Button variant="outline" size="sm" className="shrink-0 gap-1" onClick={() => onGenerateSubQueries(breadth)} disabled={isSearching}>
                <RefreshCw className="h-3.5 w-3.5" />{t.research.regenBtn}
              </Button>
            </div>

            {/* 子检索列表 */}
            <div className="space-y-3">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                {t.research.editSubQueries} · {enabledCount}/{rs.subQueries.length}
              </p>
              {ALL_DIMENSIONS.map((dim) => {
                const dimQueries = rs.subQueries.filter((q) => q.dimension === dim);
                const Icon = DIMENSION_ICONS[dim];
                const isAddingHere = addingQuery?.topicId === topic.id && addingQuery?.dimension === dim;
                return (
                  <div key={dim} className="border rounded-sm overflow-hidden">
                    <div className={cn('flex items-center justify-between px-3 py-1.5 text-xs font-medium', DIMENSION_COLORS[dim])}>
                      <div className="flex items-center gap-1.5">
                        <Icon className="h-3 w-3" />
                        <span>{DIMENSION_LABELS[dim]}</span>
                        <span className="opacity-60">{t.research.dimCount.replace('{n}', String(dimQueries.length))}</span>
                      </div>
                      {!isSearching && (
                        <button className="opacity-60 hover:opacity-100" onClick={() => onSetAddingQuery({ topicId: topic.id, dimension: dim, text: '' })}>
                          <PlusCircle className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                    <div className="divide-y">
                      {dimQueries.length === 0 && !isAddingHere && (
                        <div className="px-3 py-2 text-xs text-muted-foreground italic">{t.research.noSubQueries}</div>
                      )}
                      {dimQueries.map((q) => (
                        <div key={q.id} className="flex items-center gap-2 px-3 py-2 group hover:bg-muted/20">
                          <Checkbox checked={q.is_enabled} onCheckedChange={(v) => onToggleQuery(q.id, !!v)} disabled={isSearching} className="shrink-0" />
                          {editingQuery?.id === q.id ? (
                            <div className="flex gap-1.5 flex-1 min-w-0">
                              <Input className="flex-1 h-7 text-sm px-2" value={editingQuery.text} onChange={(e) => onSetEditingQuery({ ...editingQuery, text: e.target.value })} onKeyDown={(e) => { if (e.key === 'Enter') onSaveQueryText(); if (e.key === 'Escape') onSetEditingQuery(null); }} autoFocus />
                              <Button size="icon" className="h-7 w-7 shrink-0" onClick={onSaveQueryText}><Check className="h-3 w-3" /></Button>
                              <Button size="icon" variant="ghost" className="h-7 w-7 shrink-0" onClick={() => onSetEditingQuery(null)}><X className="h-3 w-3" /></Button>
                            </div>
                          ) : (
                            <>
                              <span className={cn('flex-1 min-w-0 text-sm text-pretty', !q.is_enabled && 'line-through text-muted-foreground')}>{q.query_text}</span>
                              {!isSearching && (
                                <div className="flex gap-0.5 shrink-0 opacity-0 group-hover:opacity-100">
                                  <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => onSetEditingQuery({ id: q.id, text: q.query_text })}><Edit2 className="h-3 w-3" /></Button>
                                  <Button size="icon" variant="ghost" className="h-6 w-6 text-destructive" onClick={() => onDeleteQuery(q.id)}><Trash2 className="h-3 w-3" /></Button>
                                </div>
                              )}
                            </>
                          )}
                        </div>
                      ))}
                      {isAddingHere && (
                        <div className="flex gap-1.5 px-3 py-2">
                          <Input className="flex-1 h-7 text-sm px-2" placeholder={t.research.subQueryPlaceholder} value={addingQuery.text} onChange={(e) => onSetAddingQuery({ ...addingQuery, text: e.target.value })} onKeyDown={(e) => { if (e.key === 'Enter') onAddQuery(); if (e.key === 'Escape') onSetAddingQuery(null); }} autoFocus />
                          <Button size="icon" className="h-7 w-7 shrink-0" onClick={onAddQuery} disabled={!addingQuery.text.trim()}><Check className="h-3 w-3" /></Button>
                          <Button size="icon" variant="ghost" className="h-7 w-7 shrink-0" onClick={() => onSetAddingQuery(null)}><X className="h-3 w-3" /></Button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* 执行检索按钮 */}
            <Button className="w-full gap-2" onClick={onStartSearch} disabled={isSearching || enabledCount === 0}>
              {isSearching
                ? <><Loader2 className="h-4 w-4 animate-spin" />{t.research.searching}</>
                : <><PlayCircle className="h-4 w-4" />{t.research.execBtn.replace('{n}', String(enabledCount))}</>
              }
            </Button>
            {enabledCount === 0 && <p className="text-xs text-muted-foreground text-center -mt-2">{t.research.noQueryHint}</p>}
          </div>
        )}
      </div>
    </div>
  );
}

// ── 广度阈值控件 ──────────────────────────────────────────────────────────
function BreadthControl({ breadth, breadthLabels, breadthTitle, breadthFocused, breadthBroad, onChange }: {
  breadth: number;
  breadthLabels: Record<number, { label: string; desc: string }>;
  breadthTitle: string;
  breadthFocused: string;
  breadthBroad: string;
  onChange: (v: number) => void;
}) {
  const cfg = breadthLabels[breadth]!;
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 text-sm font-medium">
          <Sliders className="h-3.5 w-3.5 text-muted-foreground" /><span>{breadthTitle}</span>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <Badge variant="outline" className="text-xs font-semibold text-primary border-primary/40">{cfg.label}</Badge>
          <span className="text-xs text-muted-foreground">{cfg.desc}</span>
        </div>
      </div>
      <Slider value={[breadth]} onValueChange={([v]) => onChange(v ?? 3)} min={1} max={5} step={1} className="w-full" />
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>{breadthFocused}</span><span>{breadthBroad}</span>
      </div>
    </div>
  );
}
