import type { ReactNode } from 'react';
import DashboardPage from './pages/DashboardPage';
import ContentInputPage from './pages/ContentInputPage';
import KnowledgePage from './pages/KnowledgePage';
import ResearchPage from './pages/ResearchPage';
import EvidencePage from './pages/EvidencePage';
import ReportsPage from './pages/ReportsPage';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  public?: boolean;
}

export const routes: RouteConfig[] = [
  { name: 'Dashboard',      path: '/',          element: <DashboardPage /> },
  { name: 'Content Input',  path: '/input',     element: <ContentInputPage /> },
  { name: 'Knowledge Base', path: '/knowledge', element: <KnowledgePage /> },
  { name: 'Topic Research', path: '/research',  element: <ResearchPage /> },
  { name: 'Evidence Cards', path: '/evidence',  element: <EvidencePage /> },
  { name: 'Reports',        path: '/reports',   element: <ReportsPage /> },
];
