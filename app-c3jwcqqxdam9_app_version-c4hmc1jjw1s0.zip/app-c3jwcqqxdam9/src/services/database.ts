import { supabase } from '@/db/supabase';
import type {
  KnowledgeItem,
  Topic,
  TopicCollaborator,
  SubQuery,
  EvidenceCard,
  ResearchReport,
  VideoPipelineJob,
  Dimension,
  CardStatus,
  SourceType,
} from '@/types/types';

// ===== 知识库 =====
export const knowledgeService = {
  async list(): Promise<KnowledgeItem[]> {
    const { data, error } = await supabase
      .from('knowledge_items')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  /** 全文搜索（标题 + 内容关键词） */
  async search(query: string): Promise<KnowledgeItem[]> {
    const q = query.trim().toLowerCase();
    if (!q) return this.list();
    const { data, error } = await supabase
      .from('knowledge_items')
      .select('*')
      .or(`title.ilike.%${q}%,content.ilike.%${q}%`)
      .order('updated_at', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  /**
   * 根据标题关键词查找已有相似条目（用于去重校验）
   * 返回标题包含相同关键词（≥50% 覆盖率）的条目
   */
  async findSimilar(title: string): Promise<KnowledgeItem[]> {
    // 分词：提取所有 2+ 字符的词
    const words = title
      .toLowerCase()
      .split(/[\s\-_,，。、【】()（）\[\]]+/)
      .filter((w) => w.length >= 2);
    if (!words.length) return [];

    // 用最有代表性的词（最长的 2 个）查询
    const keyWords = [...words].sort((a, b) => b.length - a.length).slice(0, 2);
    const conditions = keyWords.map((w) => `title.ilike.%${w}%`).join(',');
    const { data, error } = await supabase
      .from('knowledge_items')
      .select('*')
      .or(conditions)
      .order('updated_at', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(item: {
    title: string;
    content: string;
    source_type: SourceType;
    original_content?: string;
    evidence_card_id?: string;
  }): Promise<void> {
    // 使用纯 insert（不附加 .select()），避免因 RLS 仅允许 INSERT 不允许 SELECT 导致的写入失败
    const { error } = await supabase.from('knowledge_items').insert(item);
    if (error) throw error;
  },

  /** 根据证据卡片 ID 查找已同步的 KB 条目（用于单张幂等判断） */
  async findByCardId(cardId: string): Promise<KnowledgeItem | null> {
    const { data, error } = await supabase
      .from('knowledge_items')
      .select('*')
      .eq('evidence_card_id', cardId)
      .maybeSingle();
    if (error) throw error;
    return data ?? null;
  },

  /** 一次性获取所有已同步的 evidence_card_id 集合（用于批量状态展示） */
  async listSyncedCardIds(): Promise<Set<string>> {
    const { data, error } = await supabase
      .from('knowledge_items')
      .select('evidence_card_id')
      .not('evidence_card_id', 'is', null);
    if (error) throw error;
    return new Set((data ?? []).map((r) => r.evidence_card_id as string));
  },

  async update(id: string, updates: Partial<Pick<KnowledgeItem, 'title' | 'content'>>): Promise<void> {
    const { error } = await supabase
      .from('knowledge_items')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id);
    if (error) throw error;
  },

  /** 追加内容到已有条目（维基式合并：在原内容末尾添加新章节） */
  async appendContent(id: string, newSection: string): Promise<void> {
    const { data: existing, error: fetchErr } = await supabase
      .from('knowledge_items')
      .select('content')
      .eq('id', id)
      .maybeSingle();
    if (fetchErr) throw fetchErr;
    const merged = `${existing?.content ?? ''}\n\n---\n\n${newSection}`;
    await this.update(id, { content: merged });
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('knowledge_items').delete().eq('id', id);
    if (error) throw error;
  },

  /** 按 evidence_card_id 更新对应知识库条目的 title + content（重写） */
  async updateByCardId(cardId: string, updates: { title: string; content: string }): Promise<'updated' | 'notfound'> {
    const { data, error } = await supabase
      .from('knowledge_items')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('evidence_card_id', cardId)
      .select('id')
      .maybeSingle();
    if (error) throw error;
    return data ? 'updated' : 'notfound';
  },
};

// ===== 专题 =====
export const topicService = {
  async list(): Promise<Topic[]> {
    const { data, error } = await supabase
      .from('topics')
      .select('*')
      .order('sort_order', { ascending: true })
      .order('created_at', { ascending: true });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(topic: {
    title: string;
    description?: string;
    source_content?: string;
    parent_id?: string | null;
    sort_order?: number;
  }): Promise<Topic> {
    const { data, error } = await supabase.from('topics').insert(topic).select().maybeSingle();
    if (error) throw error;
    return data as Topic;
  },

  async update(id: string, updates: Partial<Pick<Topic, 'title' | 'description' | 'parent_id' | 'sort_order'>>): Promise<void> {
    const { error } = await supabase.from('topics').update(updates).eq('id', id);
    if (error) throw error;
  },

  async updateStatus(id: string, status: Topic['status']): Promise<void> {
    const { error } = await supabase.from('topics').update({ status }).eq('id', id);
    if (error) throw error;
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('topics').delete().eq('id', id);
    if (error) throw error;
  },
};

// ===== 专题协作 =====
export const topicCollaboratorService = {
  async listByTopic(topicId: string): Promise<TopicCollaborator[]> {
    const { data, error } = await supabase
      .from('topic_collaborators')
      .select('id, topic_id, collaborator_id, created_at')
      .eq('topic_id', topicId)
      .order('created_at', { ascending: true });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  /** 通过用户名搜索用户（调用 DB 安全函数） */
  async findUserByUsername(username: string): Promise<{ id: string; username: string } | null> {
    const { data, error } = await supabase.rpc('find_user_by_username', { p_username: username });
    if (error) throw error;
    return (data as { id: string; username: string }[])?.[0] ?? null;
  },

  async add(topicId: string, collaboratorId: string): Promise<void> {
    const { error } = await supabase
      .from('topic_collaborators')
      .insert({ topic_id: topicId, collaborator_id: collaboratorId });
    if (error) throw error;
  },

  async remove(topicId: string, collaboratorId: string): Promise<void> {
    const { error } = await supabase
      .from('topic_collaborators')
      .delete()
      .eq('topic_id', topicId)
      .eq('collaborator_id', collaboratorId);
    if (error) throw error;
  },
};

// ===== 子检索 =====
export const subQueryService = {
  async listByTopic(topicId: string): Promise<SubQuery[]> {
    const { data, error } = await supabase
      .from('sub_queries')
      .select('*')
      .eq('topic_id', topicId)
      .order('sort_order', { ascending: true });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(sq: {
    topic_id: string;
    dimension: Dimension;
    query_text: string;
    sort_order?: number;
  }): Promise<void> {
    const { error } = await supabase.from('sub_queries').insert(sq);
    if (error) throw error;
  },

  async batchCreate(queries: Omit<SubQuery, 'id' | 'created_at' | 'updated_at'>[]): Promise<void> {
    const { error } = await supabase.from('sub_queries').insert(queries);
    if (error) throw error;
  },

  async update(id: string, updates: Partial<Pick<SubQuery, 'query_text' | 'is_enabled'>>): Promise<void> {
    const { error } = await supabase.from('sub_queries').update(updates).eq('id', id);
    if (error) throw error;
  },

  async removeByTopic(topicId: string): Promise<void> {
    const { error } = await supabase.from('sub_queries').delete().eq('topic_id', topicId);
    if (error) throw error;
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('sub_queries').delete().eq('id', id);
    if (error) throw error;
  },
};

// ===== 证据卡片 =====
export const evidenceCardService = {
  async listByTopic(topicId: string): Promise<EvidenceCard[]> {
    const { data, error } = await supabase
      .from('evidence_cards')
      .select('*')
      .eq('topic_id', topicId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async listAll(): Promise<EvidenceCard[]> {
    const { data, error } = await supabase
      .from('evidence_cards')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(card: Omit<EvidenceCard, 'id' | 'created_at' | 'updated_at'>): Promise<void> {
    const { error } = await supabase.from('evidence_cards').insert(card);
    if (error) throw error;
  },

  async batchCreate(cards: Omit<EvidenceCard, 'id' | 'created_at' | 'updated_at'>[]): Promise<void> {
    const { error } = await supabase.from('evidence_cards').insert(cards);
    if (error) throw error;
  },

  async update(id: string, updates: Partial<Pick<EvidenceCard, 'title' | 'summary' | 'structured_content' | 'status' | 'summary_en' | 'structured_content_en'>>): Promise<void> {
    const { error } = await supabase.from('evidence_cards').update(updates).eq('id', id);
    if (error) throw error;
  },

  async updateStatus(id: string, status: CardStatus): Promise<void> {
    const { error } = await supabase.from('evidence_cards').update({ status }).eq('id', id);
    if (error) throw error;
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('evidence_cards').delete().eq('id', id);
    if (error) throw error;
  },

  async batchRemove(ids: string[]): Promise<void> {
    if (ids.length === 0) return;
    const { error } = await supabase.from('evidence_cards').delete().in('id', ids);
    if (error) throw error;
  },

  async batchUpdateStatus(ids: string[], status: CardStatus): Promise<void> {
    if (ids.length === 0) return;
    const { error } = await supabase
      .from('evidence_cards')
      .update({ status })
      .in('id', ids);
    if (error) throw error;
  },
};

// ===== 研究报告 =====
export const reportService = {
  async list(): Promise<ResearchReport[]> {
    const { data, error } = await supabase
      .from('research_reports')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async listByTopic(topicId: string): Promise<ResearchReport[]> {
    const { data, error } = await supabase
      .from('research_reports')
      .select('*')
      .eq('topic_id', topicId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(report: {
    topic_id: string;
    topic_ids: string[];
    title: string;
    evidence_card_ids: string[];
  }): Promise<ResearchReport> {
    const { data, error } = await supabase
      .from('research_reports')
      .insert({ ...report, content: '', status: 'draft' })
      .select()
      .maybeSingle();
    if (error) throw error;
    return data as ResearchReport;
  },

  async update(id: string, updates: Partial<Pick<ResearchReport, 'title' | 'content' | 'content_en' | 'status' | 'evidence_card_ids'>>): Promise<void> {
    const { error } = await supabase.from('research_reports').update(updates).eq('id', id);
    if (error) throw error;
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('research_reports').delete().eq('id', id);
    if (error) throw error;
  },
};

// ===== 视频流水线任务 =====
export const videoPipelineService = {
  /** 根据 job_id 获取最新任务状态 */
  async getJob(id: string): Promise<VideoPipelineJob | null> {
    const { data, error } = await supabase
      .from('video_pipeline_jobs')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    if (error) throw error;
    return data as VideoPipelineJob | null;
  },

  /** 订阅任务状态变更（Realtime） */
  subscribeJob(id: string, onChange: (job: VideoPipelineJob) => void) {
    return supabase
      .channel(`vp-job-${id}`)
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'video_pipeline_jobs',
        filter: `id=eq.${id}`,
      }, (payload) => {
        onChange(payload.new as VideoPipelineJob);
      })
      .subscribe();
  },
};
