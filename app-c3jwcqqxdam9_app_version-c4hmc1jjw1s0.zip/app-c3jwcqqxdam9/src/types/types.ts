// 用户角色
export type UserRole = 'user' | 'admin';

// 用户档案
export interface Profile {
  id: string;
  email: string | null;
  username: string;
  phone: string | null;
  role: UserRole;
  created_at: string;
}

// 专题协作关系
export interface TopicCollaborator {
  id: string;
  topic_id: string;
  collaborator_id: string;
  created_at: string;
  // 联查字段
  collaborator?: Pick<Profile, 'id' | 'username'>;
}

// 来源类型
export type SourceType = 'video' | 'text' | 'document' | 'evidence';

// 视频处理流水线状态
export type VideoPipelineStatus =
  | 'pending'
  | 'uploading_bos'
  | 'asr_submitted'
  | 'asr_processing'
  | 'transcribing'
  | 'formatting'
  | 'completed'
  | 'failed';

// 视频流水线任务
export interface VideoPipelineJob {
  id: string;
  owner_id: string;
  video_url: string;
  status: VideoPipelineStatus;
  stage_label: string | null;
  bos_audio_key: string | null;
  asr_task_id: string | null;
  transcript: string | null;
  markdown: string | null;
  srt_content: string | null;
  error_msg: string | null;
  created_at: string;
  updated_at: string;
}



// 检索维度
export type Dimension = 'academic' | 'industry' | 'recruitment' | 'investment';

// 专题状态
export type TopicStatus = 'pending' | 'researching' | 'completed';

// 证据卡片状态
export type CardStatus = 'pending' | 'archived' | 'observing' | 'ignored';

// 研报状态
export type ReportStatus = 'draft' | 'generating' | 'completed';

// 知识库条目
export interface KnowledgeItem {
  id: string;
  title: string;
  content: string;
  source_type: SourceType;
  original_content: string | null;
  evidence_card_id: string | null;
  created_at: string;
  updated_at: string;
}

// 研究专题
export interface Topic {
  id: string;
  title: string;
  description: string | null;
  source_content: string | null;
  status: TopicStatus;
  owner_id: string | null;
  parent_id: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
  // 客户端运行时字段（非 DB 列）
  children?: Topic[];
  is_shared?: boolean; // 是否为协作专题（非本人创建，被邀请的）
}

// 子检索方向
export interface SubQuery {
  id: string;
  topic_id: string;
  dimension: Dimension;
  query_text: string;
  is_enabled: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

// 检索结果
export interface SearchResult {
  id: string;
  topic_id: string;
  sub_query_id: string | null;
  dimension: Dimension;
  title: string;
  url: string | null;
  snippet: string | null;
  raw_content: string | null;
  created_at: string;
}

// 证据卡片结构化内容（按维度）
export interface AcademicContent {
  method: string;
  findings: string;
  conclusion: string;
}

export interface IndustryContent {
  scenario: string;
  solution: string;
  effect: string;
}

export interface RecruitmentContent {
  requirements: string;
  skills: string;
  distribution: string;
}

export interface InvestmentContent {
  stage: string;
  track: string;
  logic: string;
}

export type StructuredContent = AcademicContent | IndustryContent | RecruitmentContent | InvestmentContent;

// 证据卡片
export interface EvidenceCard {
  id: string;
  topic_id: string;
  search_result_id: string | null;
  dimension: Dimension;
  title: string;
  summary: string;
  structured_content: Record<string, string>;
  // 英文版内容（AI 重写后生成）
  summary_en: string | null;
  structured_content_en: Record<string, string> | null;
  source_url: string | null;
  source_title: string | null;
  status: CardStatus;
  created_at: string;
  updated_at: string;
}

// 研究报告
export interface ResearchReport {
  id: string;
  topic_id: string;
  topic_ids: string[];
  title: string;
  content: string;
  content_en: string;
  evidence_card_ids: string[];
  status: ReportStatus;
  created_at: string;
  updated_at: string;
}

// 维度标签配置（中文默认，UI 层应使用 t.dimension[dim] 实现 i18n）
export const DIMENSION_LABELS: Record<Dimension, string> = {
  academic: '前沿学术',
  industry: '产业应用',
  recruitment: '招聘JD',
  investment: '创投信息',
};

export const DIMENSION_COLORS: Record<Dimension, string> = {
  academic: 'text-blue-600 bg-blue-50 border-blue-200',
  industry: 'text-emerald-600 bg-emerald-50 border-emerald-200',
  recruitment: 'text-amber-600 bg-amber-50 border-amber-200',
  investment: 'text-purple-600 bg-purple-50 border-purple-200',
};

export const CARD_STATUS_LABELS: Record<CardStatus, string> = {
  pending: '待处理',
  archived: '已入库',
  observing: '观察中',
  ignored: '已忽略',
};

export const SOURCE_TYPE_LABELS: Record<SourceType, string> = {
  video: '视频',
  text: '文本',
  document: '文档',
  evidence: '证据卡片',
};
