import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const LLM_ENDPOINT =
  "https://app-c3jwcqqxdam9-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse";

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
    if (!apiKey) throw new Error("服务器配置错误，缺少 API Key");

    const { content } = await req.json() as { content: string };
    if (!content?.trim()) {
      return new Response(JSON.stringify({ topics: [] }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const prompt = `请从以下内容中提取关键研究主题，以JSON格式返回。

要求：
1. 提取 2-5 个核心研究主题
2. 每个主题有 title（简洁标题，10字以内）和 description（一句话说明，30字以内）
3. 主题应有研究价值，可以进行深度探索
4. 只返回JSON，格式如下：
{"topics": [{"title": "...", "description": "..."}]}

内容：
${content.slice(0, 3000)}`;

    const llmResp = await fetch(LLM_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Gateway-Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
      }),
      signal: AbortSignal.timeout(120_000),
    });

    if (!llmResp.ok || !llmResp.body) {
      if (llmResp.status === 429) {
        return new Response(
          JSON.stringify({ error: "LLM调用频率超限，请稍等片刻后再试（429）" }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (llmResp.status === 402) {
        return new Response(
          JSON.stringify({ error: "API余额不足，请联系管理员（402）" }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      throw new Error(`LLM error: ${llmResp.status}`);
    }

    const reader = llmResp.body.getReader();
    const decoder = new TextDecoder("utf-8");
    let buffer = "";
    let fullText = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data:")) continue;
        const dataStr = line.slice(5).trim();
        if (!dataStr || dataStr === "[DONE]") continue;
        try {
          const frame = JSON.parse(dataStr) as {
            candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
          };
          const text = frame?.candidates?.[0]?.content?.parts?.[0]?.text;
          if (text) fullText += text;
        } catch { /* skip malformed frame */ }
      }
    }

    const jsonMatch = /\{[\s\S]*\}/.exec(fullText);
    if (!jsonMatch) throw new Error("LLM返回格式错误，请重试");
    const parsed = JSON.parse(jsonMatch[0]) as {
      topics: Array<{ title: string; description: string }>;
    };

    return new Response(JSON.stringify(parsed), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    const status = message.includes("429") ? 429 : 500;
    return new Response(JSON.stringify({ error: message }), {
      status,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
