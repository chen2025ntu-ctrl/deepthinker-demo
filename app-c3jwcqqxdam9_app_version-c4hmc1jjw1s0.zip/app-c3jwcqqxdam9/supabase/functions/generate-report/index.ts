import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const LLM_ENDPOINT =
  "https://app-c3jwcqqxdam9-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse";

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
    if (!apiKey) throw new Error("Server configuration error");

    const body = await req.json() as {
      topicTitles?: string[];
      topicTitle?: string;
      reportTitle: string;
      cardSummaries: string;
      lang?: string;
    };

    const lang = body.lang === "en" ? "en" : "zh";

    const topicTitles: string[] = body.topicTitles?.length
      ? body.topicTitles
      : body.topicTitle
      ? [body.topicTitle]
      : [];

    const cardCount = (body.cardSummaries.match(/\n\n/g)?.length ?? 0) + 1;
    const multiTopic = topicTitles.length > 1;

    let prompt: string;

    if (lang === "en") {
      const topicsLine = multiTopic
        ? `Research Topics (${topicTitles.length} topics): ${topicTitles.join(", ")}`
        : `Research Topic: ${topicTitles[0] ?? ""}`;

      prompt = `Based on the evidence cards below, write a professional research report in English.

${topicsLine}
Report Title: ${body.reportTitle}

Evidence Cards (${cardCount} total):
${body.cardSummaries}

Report Requirements:
1. Complete structure: Abstract → Research Background → Academic Progress → Industry Applications → Talent Demand → Investment Trends → Conclusions & Outlook
2. Objective content; cite evidence by number, e.g. [Evidence 1]
3. Professional, concise, academic tone
4. Appropriate length (1500–3000 words)
5. Use Markdown format with headings, paragraphs, and bold emphasis
${multiTopic ? "6. Integrate multiple topics; highlight connections and intersections across sections" : ""}

Output the report body directly, without any preamble or explanation.`;
    } else {
      const topicsLine = multiTopic
        ? `研究主题（共 ${topicTitles.length} 个专题）：${topicTitles.join("、")}`
        : `研究主题：${topicTitles[0] ?? ""}`;

      prompt = `请基于以下证据卡片，撰写一篇专业的研究报告。

${topicsLine}
报告标题：${body.reportTitle}

证据卡片（共 ${cardCount} 张）：
${body.cardSummaries}

报告要求：
1. 结构完整：摘要 → 研究背景 → 学术进展 → 产业应用 → 人才需求 → 投资动态 → 结论与展望
2. 内容客观，引用证据时注明来源编号，如【证据1】
3. 语言专业、简洁，学术风格
4. 篇幅适中（1500-3000字）
5. 使用 Markdown 格式，包含标题、段落、重点加粗
${multiTopic ? "6. 综合多专题内容，在各章节中体现不同专题的关联与交叉" : ""}

直接输出报告正文，不要额外解释。`;
    }

    const llmResp = await fetch(LLM_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Gateway-Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
      }),
      signal: AbortSignal.timeout(180_000),
    });

    if (!llmResp.ok || !llmResp.body) {
      if (llmResp.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded, please retry later" }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      throw new Error(`LLM error: ${llmResp.status}`);
    }

    const { readable, writable } = new TransformStream();
    llmResp.body.pipeTo(writable).catch(() => {});

    return new Response(readable, {
      headers: {
        ...corsHeaders,
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
      },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
