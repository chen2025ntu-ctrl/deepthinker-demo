import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const DIMENSIONS = ["academic", "industry", "recruitment", "investment"];
const DIMENSION_PROMPTS: Record<string, string> = {
  academic: "前沿学术研究（期刊论文、研究进展、方法论创新）",
  industry: "产业应用案例（行业落地、解决方案、企业实践）",
  recruitment: "招聘JD分析（岗位技能要求、行业人才需求趋势）",
  investment: "创投动态（融资事件、投资赛道、市场机会分析）",
};

// 根据广度级别映射每个维度应生成的子检索数量
// breadth: 1=精准(1-2), 2=较精准(2), 3=均衡(3), 4=较广泛(4), 5=广泛(5-6)
function getBreadthConfig(breadth: number): { perDim: number; totalHint: string } {
  const clamp = Math.min(Math.max(Math.round(breadth), 1), 5);
  const map: Record<number, { perDim: number; totalHint: string }> = {
    1: { perDim: 1, totalHint: "4个（每维度1个，高度聚焦）" },
    2: { perDim: 2, totalHint: "8个（每维度2个，较精准）" },
    3: { perDim: 3, totalHint: "12个（每维度3个，均衡）" },
    4: { perDim: 4, totalHint: "16个（每维度4个，较广泛）" },
    5: { perDim: 5, totalHint: "20个（每维度5个，广泛探索）" },
  };
  return map[clamp]!;
}

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
    if (!apiKey) throw new Error("服务器配置错误");

    const { topicTitle, topicDescription, breadth = 3 } = await req.json() as {
      topicTitle: string;
      topicDescription?: string;
      breadth?: number; // 1=精准 ~ 5=广泛，控制每维度子检索数量
    };

    const { perDim, totalHint } = getBreadthConfig(breadth);
    const dimDescriptions = DIMENSIONS.map((d) => `- ${d}: ${DIMENSION_PROMPTS[d]}`).join("\n");

    const prompt = `你是一个专业的学术与产业研究规划助手。请为以下研究主题生成系统化的拓展检索方向，以JSON格式返回。

研究主题：${topicTitle}
${topicDescription ? `主题描述：${topicDescription}` : ""}

生成要求：
1. 共生成 ${totalHint}，4个维度平均分配
2. 每个维度恰好生成 ${perDim} 个子检索方向
3. 子检索内容要具体、可直接用于搜索引擎检索（关键词组合或问句）
4. 各维度定义：
${dimDescriptions}
5. 不同子检索之间要有差异性，覆盖不同角度（如：前沿方向、主流应用、具体场景、比较研究等）
6. 只返回JSON，不要有任何额外说明，格式：
{"queries": [{"dimension": "academic|industry|recruitment|investment", "query_text": "具体检索内容"}]}`;

    const llmResp = await fetch(
      "https://app-c3jwcqqxdam9-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Gateway-Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: prompt }] }],
        }),
        signal: AbortSignal.timeout(120_000),
      }
    );

    if (!llmResp.ok || !llmResp.body) {
      if (llmResp.status === 429) throw new Error("LLM调用频率超限，请稍后重试");
      throw new Error(`LLM error: ${llmResp.status}`);
    }

    const reader = llmResp.body.getReader();
    const decoder = new TextDecoder("utf-8");
    let buffer = "";
    let fullText = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data:")) continue;
        const dataStr = line.slice(5).trim();
        if (!dataStr || dataStr === "[DONE]") continue;
        try {
          const frame = JSON.parse(dataStr) as {
            candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
          };
          const text = frame?.candidates?.[0]?.content?.parts?.[0]?.text;
          if (text) fullText += text;
        } catch { /* skip malformed frame */ }
      }
    }

    const jsonMatch = /\{[\s\S]*\}/.exec(fullText);
    if (!jsonMatch) throw new Error("LLM返回格式错误，请重试");
    const parsed = JSON.parse(jsonMatch[0]) as {
      queries: Array<{ dimension: string; query_text: string }>;
    };

    return new Response(JSON.stringify(parsed), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    const status = message.includes("429") ? 429 : 500;
    return new Response(JSON.stringify({ error: message }), {
      status,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
