import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const LLM_ENDPOINT =
  "https://app-c3jwcqqxdam9-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse";

const STT_ENDPOINT =
  "https://app-c3jwcqqxdam9-api-DY8MNQoqOnMa.gateway.appmedo.com/v1/audio/transcriptions";

// 只有内容足够长或来自 video/document 时才调用 LLM 格式化
const LLM_THRESHOLD = 200;

// ── 平台检测工具函数 ──────────────────────────────────────────────────────────

/** 从各种 YouTube URL 格式中提取 video ID */
function extractYouTubeId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?.*v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/v\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
  ];
  for (const p of patterns) {
    const m = p.exec(url);
    if (m) return m[1];
  }
  return null;
}

/** 从 Bilibili URL 中提取 BV号 或 AV号 */
function extractBilibiliId(url: string): { type: 'bv' | 'av'; id: string } | null {
  const bv = /\/video\/(BV[a-zA-Z0-9]+)/i.exec(url);
  if (bv) return { type: 'bv', id: bv[1] };
  const av = /\/video\/av(\d+)/i.exec(url);
  if (av) return { type: 'av', id: av[1] };
  return null;
}

// ── YouTube 字幕提取 ──────────────────────────────────────────────────────────

interface CaptionTrack {
  baseUrl: string;
  languageCode: string;
  name?: { simpleText?: string };
}

/** 通过 YouTube 页面解析字幕轨道并提取转录文字 */
async function getYouTubeTranscript(videoId: string): Promise<string> {
  console.log(`[youtube] fetching page for video: ${videoId}`);
  const pageResp = await fetch(`https://www.youtube.com/watch?v=${videoId}`, {
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
      "Accept-Language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7",
    },
    signal: AbortSignal.timeout(20_000),
  });
  if (!pageResp.ok) throw new Error(`YouTube 页面请求失败 (${pageResp.status})`);
  const html = await pageResp.text();

  // 从页面 JS 中抠取字幕轨道列表
  const captionMatch = /"captionTracks":(\[.*?\])/s.exec(html);
  if (!captionMatch) {
    throw new Error("该 YouTube 视频没有可用的字幕/转录文字（请检查视频是否公开且有字幕）");
  }

  let captionTracks: CaptionTrack[] = [];
  try {
    captionTracks = JSON.parse(captionMatch[1]) as CaptionTrack[];
  } catch {
    throw new Error("解析 YouTube 字幕轨道失败");
  }

  if (!captionTracks.length) throw new Error("该视频无字幕轨道");

  // 优先选中文字幕，其次英文，再退化为第一条
  const track =
    captionTracks.find((t) => t.languageCode === "zh-Hans" || t.languageCode === "zh") ??
    captionTracks.find((t) => t.languageCode?.startsWith("zh")) ??
    captionTracks.find((t) => t.languageCode === "en") ??
    captionTracks[0];

  console.log(`[youtube] selected caption track: lang=${track.languageCode}`);

  // 获取字幕 XML
  const captionUrl = `${track.baseUrl}&fmt=json3`;
  const captionResp = await fetch(captionUrl, { signal: AbortSignal.timeout(15_000) });
  if (!captionResp.ok) throw new Error(`YouTube 字幕请求失败 (${captionResp.status})`);

  const captionJson = await captionResp.json() as {
    events?: Array<{ segs?: Array<{ utf8?: string }> }>;
  };

  const text = (captionJson.events ?? [])
    .filter((e) => e.segs)
    .map((e) => (e.segs ?? []).map((s) => s.utf8 ?? "").join(""))
    .join(" ")
    .replace(/\s+/g, " ")
    .replace(/\n/g, " ")
    .trim();

  if (!text) throw new Error("YouTube 字幕内容为空");
  console.log(`[youtube] transcript extracted, length=${text.length}`);
  return text;
}

// ── Bilibili 字幕提取 ─────────────────────────────────────────────────────────

/** 从 Bilibili 接口提取视频字幕文字 */
async function getBilibiliTranscript(bvid: string): Promise<string> {
  console.log(`[bilibili] fetching info for: ${bvid}`);

  // 获取视频信息（cid）
  const infoResp = await fetch(
    `https://api.bilibili.com/x/web-interface/view?bvid=${encodeURIComponent(bvid)}`,
    {
      headers: { "User-Agent": "Mozilla/5.0", Referer: "https://www.bilibili.com" },
      signal: AbortSignal.timeout(15_000),
    }
  );
  if (!infoResp.ok) throw new Error(`Bilibili 视频信息请求失败 (${infoResp.status})`);
  const infoData = await infoResp.json() as { code: number; data?: { cid?: number; title?: string } };
  if (infoData.code !== 0) throw new Error(`Bilibili API 返回错误: ${infoData.code}`);
  const cid = infoData.data?.cid;
  if (!cid) throw new Error("无法获取 Bilibili 视频 cid");

  // 获取字幕列表
  const subListResp = await fetch(
    `https://api.bilibili.com/x/player/v2?bvid=${encodeURIComponent(bvid)}&cid=${cid}`,
    {
      headers: { "User-Agent": "Mozilla/5.0", Referer: "https://www.bilibili.com" },
      signal: AbortSignal.timeout(15_000),
    }
  );
  if (!subListResp.ok) throw new Error(`Bilibili 字幕列表请求失败 (${subListResp.status})`);
  const subListData = await subListResp.json() as {
    code: number;
    data?: { subtitle?: { subtitles?: Array<{ subtitle_url: string; lan_doc: string }> } };
  };

  const subtitles = subListData.data?.subtitle?.subtitles ?? [];
  if (!subtitles.length) {
    throw new Error("该 Bilibili 视频没有可用字幕（需要视频开启了 AI 字幕或手动字幕）");
  }

  // 优先中文字幕
  const sub =
    subtitles.find((s) => s.lan_doc?.includes("中文")) ??
    subtitles.find((s) => s.lan_doc?.includes("自动")) ??
    subtitles[0];

  const subUrl = sub.subtitle_url.startsWith("//") ? `https:${sub.subtitle_url}` : sub.subtitle_url;
  const subContentResp = await fetch(subUrl, { signal: AbortSignal.timeout(15_000) });
  if (!subContentResp.ok) throw new Error(`Bilibili 字幕文件下载失败 (${subContentResp.status})`);
  const subJson = await subContentResp.json() as { body?: Array<{ content: string }> };

  const text = (subJson.body ?? []).map((item) => item.content).join(" ").trim();
  if (!text) throw new Error("Bilibili 字幕内容为空");
  console.log(`[bilibili] transcript extracted, length=${text.length}`);
  return text;
}

async function callLLM(apiKey: string, prompt: string): Promise<string> {
  const resp = await fetch(LLM_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Gateway-Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
    }),
    signal: AbortSignal.timeout(120_000),
  });

  if (!resp.ok || !resp.body) {
    const errText = await resp.text().catch(() => "");
    if (resp.status === 429) throw new Error("LLM调用频率超限，请稍等片刻后重试（429）");
    if (resp.status === 402) throw new Error("API余额不足，请联系管理员（402）");
    throw new Error(`LLM error: ${resp.status} ${errText}`);
  }

  const reader = resp.body.getReader();
  const decoder = new TextDecoder("utf-8");
  let buffer = "";
  let result = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const dataStr = line.slice(5).trim();
      if (!dataStr || dataStr === "[DONE]") continue;
      try {
        const frame = JSON.parse(dataStr) as {
          candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
        };
        const text = frame?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (text) result += text;
      } catch { /* skip malformed frame */ }
    }
  }
  return result;
}

// 调用 Whisper STT，传入视频/音频公开 URL
async function callSTT(apiKey: string, fileUrl: string): Promise<string> {
  const sttParams = new URLSearchParams({
    file: fileUrl,
    response_format: "json",
    language: "chinese",
  });

  const sttResp = await fetch(STT_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "X-Gateway-Authorization": `Bearer ${apiKey}`,
    },
    body: sttParams.toString(),
    signal: AbortSignal.timeout(240_000), // 视频转录最长等 4 分钟
  });

  if (!sttResp.ok) {
    const errText = await sttResp.text().catch(() => "");
    if (sttResp.status === 429) throw new Error("语音转文字频率超限，请稍后重试（429）");
    if (sttResp.status === 402) throw new Error("API余额不足，请联系管理员（402）");
    // 422/400 通常是文件格式或 URL 不可访问
    if (sttResp.status === 422 || sttResp.status === 400) {
      throw new Error(`视频链接无法访问或格式不支持，请确认 URL 是可直接下载的视频文件链接（${sttResp.status}）`);
    }
    throw new Error(`语音转文字失败 (${sttResp.status}): ${errText}`);
  }

  const sttData = await sttResp.json() as { text?: string };
  const transcript = (sttData.text ?? "").trim();
  if (!transcript) throw new Error("音频转录结果为空，请检查视频是否包含语音内容");
  return transcript;
}

// 将纯文本简单包装成 Markdown（无需 LLM）
function wrapAsMarkdown(text: string, fileName?: string): string {
  const title = fileName ? `# ${fileName.replace(/\.[^.]+$/, "")}\n\n` : "";
  return `${title}${text.trim()}`;
}

// 构建视频转录专用的 LLM 整理 Prompt
function buildVideoPrompt(transcript: string, fileName?: string): string {
  const titleHint = fileName && fileName !== "在线视频" ? `视频标题：${fileName}\n\n` : "";
  return `你是一名专业的内容整理助手。以下是一段视频的语音转录文字，请将其整理为结构清晰的 Markdown 文档，适合用于学术/行业研究知识库。

${titleHint}转录文字：
${transcript}

整理要求：
1. 提取核心观点和关键信息，去除口语化的冗余词（"嗯"、"那么"、"就是说"等）
2. 按内容逻辑划分章节，使用合适的 Markdown 标题层级（# ## ###）
3. 数据、结论、案例等重要信息用列表或引用块（>）突出
4. 保留专业术语、人名、机构名的准确表述
5. 最终输出纯 Markdown，不要有额外解释或前言`;
}

// 构建通用文本整理 Prompt
function buildTextPrompt(content: string): string {
  return `请将以下内容整理为结构清晰的 Markdown 格式。
要求：
1. 提取关键信息，用合适的标题层级组织
2. 保持原意，适当精简冗余内容
3. 如有列表、步骤等，使用 Markdown 列表格式
4. 输出纯 Markdown，不要有额外解释

原始内容：
${content}`;
}

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
    if (!apiKey) throw new Error("服务器配置错误，缺少 API Key");

    const body = await req.json() as {
      type: "text" | "video" | "document";
      content?: string;
      fileUrl?: string;
      fileName?: string;
    };

    let rawText = "";
    let transcript = "";   // 原始转录文字（仅 video 类型）
    let needsLLM = false;
    let isVideo = false;

    if (body.type === "video" && body.fileUrl) {
      const url = body.fileUrl.trim();
      console.log(`[process-content] video url: ${url}`);

      // ── 平台路由：优先通过字幕接口获取文字，避免消耗 STT 配额 ──
      const youtubeId = extractYouTubeId(url);
      const bilibiliId = extractBilibiliId(url);

      if (youtubeId) {
        // YouTube：解析字幕轨道
        console.log(`[process-content] detected YouTube, videoId=${youtubeId}`);
        transcript = await getYouTubeTranscript(youtubeId);
      } else if (bilibiliId) {
        // Bilibili：解析 AI 字幕
        console.log(`[process-content] detected Bilibili, bvid=${bilibiliId.id}`);
        transcript = await getBilibiliTranscript(bilibiliId.id);
      } else {
        // 通用直链视频：调用 Whisper STT
        console.log(`[process-content] direct video url, calling STT`);
        transcript = await callSTT(apiKey, url);
      }

      rawText = transcript;
      needsLLM = true;
      isVideo = true;
      console.log(`[process-content] transcript ready, length=${transcript.length}`);
    } else {
      rawText = body.content ?? "";
      needsLLM = body.type === "document" || rawText.length > LLM_THRESHOLD;
    }

    if (!rawText.trim()) {
      return new Response(JSON.stringify({ markdown: "", transcript: "" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let markdown: string;

    if (needsLLM) {
      // 视频使用专用 prompt，其他内容使用通用 prompt
      const prompt = isVideo
        ? buildVideoPrompt(rawText, body.fileName)
        : buildTextPrompt(rawText);
      console.log(`[process-content] calling LLM (isVideo=${isVideo})`);
      markdown = await callLLM(apiKey, prompt);
      console.log(`[process-content] LLM done, markdown length=${markdown.length}`);
    } else {
      markdown = wrapAsMarkdown(rawText, body.fileName);
    }

    // transcript 字段仅对视频类型返回，前端可用于展示原始转录
    return new Response(JSON.stringify({ markdown, transcript }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("[process-content] error:", message);
    const status = message.includes("429") ? 429 : message.includes("402") ? 402 : 500;
    return new Response(JSON.stringify({ error: message }), {
      status,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
