import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const LLM_ENDPOINT =
  "https://app-c3jwcqqxdam9-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse";

// 按维度定制 structured_content 字段结构
const DIMENSION_FIELDS: Record<string, string[]> = {
  academic: ["method", "findings", "conclusion"],
  industry: ["scenario", "solution", "effect"],
  recruitment: ["requirements", "skills", "distribution"],
  investment: ["stage", "track", "logic"],
};

const FIELD_LABELS_ZH: Record<string, string> = {
  method: "研究方法", findings: "主要发现", conclusion: "结论",
  scenario: "应用场景", solution: "技术方案", effect: "实施效果",
  requirements: "岗位要求", skills: "技能需求", distribution: "行业分布",
  stage: "融资阶段", track: "赛道方向", logic: "投资逻辑",
};

const FIELD_LABELS_EN: Record<string, string> = {
  method: "Method", findings: "Findings", conclusion: "Conclusion",
  scenario: "Scenario", solution: "Solution", effect: "Effect",
  requirements: "Requirements", skills: "Skills", distribution: "Distribution",
  stage: "Stage", track: "Track", logic: "Investment Logic",
};

const DIMENSION_ZH: Record<string, string> = {
  academic: "学术研究", industry: "产业应用", recruitment: "人才招聘", investment: "投融资",
};

const DIMENSION_EN: Record<string, string> = {
  academic: "Academic Research", industry: "Industry Application",
  recruitment: "Talent Recruitment", investment: "Investment & Financing",
};

interface CardInput {
  id: string;
  title: string;
  summary: string;
  structured_content: Record<string, string>;
  source_title: string | null;
  source_url: string | null;
  dimension: string;
}

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
    if (!apiKey) throw new Error("服务器配置错误，缺少 API Key");

    const { card } = await req.json() as { card: CardInput };
    if (!card?.id) {
      return new Response(JSON.stringify({ error: "缺少卡片数据" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const fields = DIMENSION_FIELDS[card.dimension] ?? [];
    const dimensionZH = DIMENSION_ZH[card.dimension] ?? card.dimension;
    const dimensionEN = DIMENSION_EN[card.dimension] ?? card.dimension;

    // 构造现有结构化字段参考文本（中文）
    const existingStructuredZH = fields
      .filter((f) => card.structured_content[f]?.trim())
      .map((f) => `${FIELD_LABELS_ZH[f] ?? f}：${card.structured_content[f]}`)
      .join("\n");

    const sourceRef = card.source_title
      ? `来源：${card.source_title}${card.source_url ? `（${card.source_url}）` : ""}`
      : card.source_url ? `来源：${card.source_url}` : "";

    // 构造 zh/en 结构化字段的 JSON 示例
    const zhFieldsExample = fields.map((f) => `"${f}": "（中文，20-60字）"`).join(",\n        ");
    const enFieldsExample = fields.map((f) => `"${f}": "(English, 15-50 words)"`).join(",\n        ");
    const fieldDescZH = fields.map((f) => `"${f}"（${FIELD_LABELS_ZH[f] ?? f}）`).join("、");
    const fieldDescEN = fields.map((f) => `"${f}"(${FIELD_LABELS_EN[f] ?? f})`).join(", ");

    const prompt = `你是一个专业的产学研情报分析师，同时精通中英文学术写作。

现有一张「${dimensionZH} / ${dimensionEN}」维度的证据卡片，请根据原始信息，**同时**输出高质量的中文版和英文版内容。

## 原始信息
**标题**：${card.title}
**现有摘要**：${card.summary}
${existingStructuredZH ? `**现有结构化字段**：\n${existingStructuredZH}` : ""}
${sourceRef ? `\n${sourceRef}` : ""}

## 重写要求
### 中文版（summary / structured_content）
1. 摘要100-200字，直接呈现核心事实、数据、结论，禁止"本研究""本文认为""综上所述"等空话套话
2. 结构化字段（${fieldDescZH}）：每字段20-60字，聚焦具体内容
3. 无实质内容的字段留空字符串

### 英文版（summary_en / structured_content_en）
1. 摘要100-200 words, present key facts, data, and conclusions directly; no filler phrases like "This paper argues" or "In conclusion"
2. Structured fields (${fieldDescEN}): 15-50 words each, focus on specific content
3. Empty string for fields with no substantive content
4. Professional academic/industry English; do NOT simply translate Chinese — independently express the same core insights

## 输出格式
只返回 JSON，格式如下：
{
  "summary": "（中文摘要）",
  "structured_content": {
    ${zhFieldsExample}
  },
  "summary_en": "(English abstract)",
  "structured_content_en": {
    ${enFieldsExample}
  }
}`;

    const llmResp = await fetch(LLM_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Gateway-Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
      }),
      signal: AbortSignal.timeout(120_000),
    });

    if (!llmResp.ok || !llmResp.body) {
      if (llmResp.status === 429) {
        return new Response(
          JSON.stringify({ error: "LLM调用频率超限，请稍等片刻后再试（429）" }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (llmResp.status === 402) {
        return new Response(
          JSON.stringify({ error: "API余额不足，请联系管理员（402）" }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      throw new Error(`LLM error: ${llmResp.status}`);
    }

    // 读取 SSE 流，拼接完整 LLM 输出
    const reader = llmResp.body.getReader();
    const decoder = new TextDecoder("utf-8");
    let buffer = "";
    let fullText = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data:")) continue;
        const dataStr = line.slice(5).trim();
        if (!dataStr || dataStr === "[DONE]") continue;
        try {
          const frame = JSON.parse(dataStr);
          const text = frame?.candidates?.[0]?.content?.parts?.[0]?.text;
          if (text) fullText += text;
        } catch { /* skip partial frames */ }
      }
    }

    // 解析 JSON（兼容 LLM 输出带 markdown 代码块的情况）
    let parsed: {
      summary: string;
      structured_content: Record<string, string>;
      summary_en: string;
      structured_content_en: Record<string, string>;
    };
    try {
      const jsonMatch = fullText.match(/```(?:json)?\s*([\s\S]*?)```/);
      const jsonStr = jsonMatch ? jsonMatch[1] : fullText;
      parsed = JSON.parse(jsonStr.trim());
    } catch {
      console.error("[rewrite-evidence-card] JSON parse failed:", fullText.slice(0, 300));
      return new Response(
        JSON.stringify({ error: "LLM返回格式解析失败，请重试", raw: fullText.slice(0, 500) }),
        { status: 422, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 清理：只保留本维度字段
    const cleanStructured = (src: Record<string, string> | null | undefined): Record<string, string> => {
      const out: Record<string, string> = {};
      for (const f of fields) out[f] = (src?.[f] ?? "").trim();
      return out;
    };

    return new Response(
      JSON.stringify({
        card_id: card.id,
        summary: (parsed.summary ?? "").trim(),
        structured_content: cleanStructured(parsed.structured_content),
        summary_en: (parsed.summary_en ?? "").trim(),
        structured_content_en: cleanStructured(parsed.structured_content_en),
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    console.error("[rewrite-evidence-card] error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "未知错误" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

