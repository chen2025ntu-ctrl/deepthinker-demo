import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// 维度 → 用于 structured_content 的字段
const STRUCTURED_FIELDS: Record<string, { key: string; label: string }[]> = {
  academic:    [{ key: "method", label: "研究方法" }, { key: "findings", label: "主要发现" }, { key: "conclusion", label: "结论" }],
  industry:    [{ key: "scenario", label: "应用场景" }, { key: "solution", label: "技术方案" }, { key: "effect", label: "实施效果" }],
  recruitment: [{ key: "requirements", label: "岗位要求" }, { key: "skills", label: "技能需求" }, { key: "distribution", label: "行业分布" }],
  investment:  [{ key: "stage", label: "融资阶段" }, { key: "track", label: "赛道方向" }, { key: "logic", label: "投资逻辑" }],
};

const SEARCH_ENDPOINT = "https://app-c3jwcqqxdam9-api-VaOwP8E7dKEa.gateway.appmedo.com/search/FgEFxazBTfRUumJx/smart";

interface SubQueryInput {
  id: string;
  dimension: string;
  query_text: string;
}

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    if (!apiKey) throw new Error("服务器配置错误，缺少 API Key");

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { topicId, topicTitle, subQueries, searchCount } = await req.json() as {
      topicId: string;
      topicTitle: string;
      subQueries: SubQueryInput[];
      searchCount: number;
    };

    const limit = Math.min(Math.max(searchCount ?? 5, 3), 10);
    let totalCards = 0;

    for (const sq of subQueries) {
      // ── 1. 执行 Web 搜索（GET, 正确的端点和参数格式）──
      let webResults: Array<{ name: string; url: string; snippet: string }> = [];
      try {
        const params = new URLSearchParams({
          q: `${sq.query_text} ${topicTitle}`,
          count: String(limit),
          mkt: "zh-CN",
        });
        const searchResp = await fetch(`${SEARCH_ENDPOINT}?${params.toString()}`, {
          method: "GET",
          headers: { "X-Gateway-Authorization": `Bearer ${apiKey}` },
          signal: AbortSignal.timeout(30_000),
        });

        if (searchResp.ok) {
          const raw = await searchResp.json() as {
            webPages?: { value?: Array<{ name?: string; url?: string; snippet?: string }> };
          };
          webResults = (raw.webPages?.value ?? []).map((r) => ({
            name: r.name ?? "",
            url: r.url ?? "",
            snippet: r.snippet ?? "",
          })).filter((r) => r.name && r.url);
        } else {
          console.error(`[run-research] search failed for "${sq.query_text}": HTTP ${searchResp.status}`);
        }
      } catch (e) {
        console.error(`[run-research] search error for "${sq.query_text}":`, e);
      }

      if (webResults.length === 0) {
        console.warn(`[run-research] no results for sub-query: ${sq.query_text}`);
        continue;
      }

      // ── 2. 将每条搜索结果直接入库为证据卡片（无需逐条调用 LLM，避免 429）──
      // structured_content 留空，由用户手动编辑补充维度信息，避免将同一段 snippet
      // 重复填入多个字段（method/findings/conclusion 相同）造成冗余套话。

      // 预先加载当前专题已有卡片的 source_url，用于去重
      const { data: existingCards } = await supabase
        .from("evidence_cards")
        .select("source_url")
        .eq("topic_id", topicId)
        .not("source_url", "is", null);
      const existingUrls = new Set(
        (existingCards ?? []).map((c: { source_url: string }) => (c.source_url ?? "").toLowerCase())
      );

      // 批次内去重：同一次检索结果中也可能有重复 URL
      const seenUrlsInBatch = new Set<string>();

      for (const item of webResults) {
        try {
          const normalizedUrl = item.url.toLowerCase();

          // 跳过已存在或本批次已处理的相同 URL
          if (existingUrls.has(normalizedUrl) || seenUrlsInBatch.has(normalizedUrl)) {
            console.log(`[run-research] skip duplicate url: ${item.url}`);
            continue;
          }
          seenUrlsInBatch.add(normalizedUrl);

          // 结构化字段留空，由用户在编辑中填充，不重复使用 snippet
          const structured_content: Record<string, string> = {};

          // 存储搜索结果记录
          const { data: srData } = await supabase
            .from("search_results")
            .insert({
              topic_id: topicId,
              sub_query_id: sq.id,
              dimension: sq.dimension,
              title: item.name,
              url: item.url,
              snippet: item.snippet,
            })
            .select("id")
            .maybeSingle();

          // 存储证据卡片（summary 使用完整 snippet，不截断）
          const { error: cardError } = await supabase.from("evidence_cards").insert({
            topic_id: topicId,
            search_result_id: srData?.id ?? null,
            dimension: sq.dimension,
            title: item.name.slice(0, 60),
            summary: item.snippet,
            structured_content,
            source_url: item.url,
            source_title: item.name,
            status: "pending",
          });

          if (cardError) {
            console.error("[run-research] insert card error:", cardError.message);
          } else {
            totalCards++;
            existingUrls.add(normalizedUrl); // 更新已知 URL 集，防止跨子检索重复
          }
        } catch (e) {
          console.error("[run-research] card insert exception:", e);
        }
      }
    }

    console.log(`[run-research] done. topicId=${topicId}, totalCards=${totalCards}`);
    return new Response(JSON.stringify({ cardCount: totalCards }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("[run-research] fatal error:", message);
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
