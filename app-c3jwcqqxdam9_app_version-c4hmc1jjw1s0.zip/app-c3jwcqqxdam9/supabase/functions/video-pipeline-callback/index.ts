/**
 * video-pipeline-callback
 *
 * 百度 AASR (rpc/2.0/aasr/v1) Webhook 回调处理器。
 * 当百度云分布式 ASR 任务完成后，以 POST 请求回调此端点。
 *
 * 回调 URL 格式（提交 AASR 任务时透传 job_id）：
 *   POST /video-pipeline-callback?job_id=<job_id>
 *
 * 百度 AASR 回调体格式：
 * {
 *   "task_id": "xxx",
 *   "task_status": "Success" | "Error" | "Running",
 *   "task_result": {
 *     "result": ["sentence1", "sentence2", ...],
 *     "err_no": 0,
 *     "err_msg": "success"
 *   }
 * }
 */

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const LLM_ENDPOINT =
  "https://app-c3jwcqqxdam9-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse";

async function callLLM(apiKey: string, prompt: string): Promise<string> {
  const resp = await fetch(LLM_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${apiKey}` },
    body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: prompt }] }] }),
    signal: AbortSignal.timeout(120_000),
  });
  if (!resp.ok || !resp.body) throw new Error(`LLM error: ${resp.status}`);
  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "", result = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const data = line.slice(5).trim();
      if (!data || data === "[DONE]") continue;
      try {
        const frame = JSON.parse(data) as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> };
        const text = frame?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (text) result += text;
      } catch { /* skip */ }
    }
  }
  return result;
}

function buildVideoPrompt(transcript: string): string {
  return `你是专业内容整理助手，请将以下视频转录文字整理为结构清晰的 Markdown 文档，适合学术/行业研究知识库。

转录文字：
${transcript}

整理要求：
1. 提取核心观点和关键信息，去除口语化冗余词
2. 按内容逻辑划分章节，使用合适的 Markdown 标题层级
3. 数据、结论、案例用列表或引用块 > 突出
4. 保留专业术语、人名、机构名准确表述
5. 输出纯 Markdown，不要额外解释或前言`;
}

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const llmKey = Deno.env.get("INTEGRATIONS_API_KEY") ?? "";
  const supabase = createClient(supabaseUrl, supabaseKey);

  try {
    // 从 query 参数获取 job_id（百度回调时在 URL 中透传）
    const url = new URL(req.url);
    const jobId = url.searchParams.get("job_id");
    if (!jobId) {
      return new Response(JSON.stringify({ error: "缺少 job_id" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // 解析百度 AASR 回调体（支持两种 result 格式）
    const body = await req.json() as {
      task_id?: string;
      task_status?: string;  // "Success" | "Error" | "Running"
      task_result?: {
        result?: string[] | Array<{ res?: string[] }>;  // 可能是 string[] 或对象数组
        err_no?: number;
        err_msg?: string;
      };
      // 部分版本 API 在顶层也有 err_no/err_msg
      err_no?: number;
      err_msg?: string;
    };

    console.log(`[vp-callback] job_id=${jobId}, task_status=${body.task_status}, task_id=${body.task_id}`);

    // 仍在处理中
    if (body.task_status === "Running" || (!body.task_status && !body.err_no)) {
      return new Response(JSON.stringify({ ok: true, note: "task still running" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // 错误处理
    const errNo = body.task_result?.err_no ?? body.err_no ?? 0;
    const errMsg = body.task_result?.err_msg ?? body.err_msg ?? "";
    if (body.task_status === "Error" || (errNo !== 0 && errNo !== undefined)) {
      await supabase.from("video_pipeline_jobs").update({
        status: "failed",
        stage_label: `百度 AASR 转写失败（${errNo}）`,
        error_msg: errMsg || `错误码 ${errNo}`,
      }).eq("id", jobId);
      return new Response(JSON.stringify({ ok: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (body.task_status !== "Success") {
      return new Response(JSON.stringify({ ok: true, note: "unexpected status" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── 提取转录文字（兼容两种 result 数组格式）────────────────────────────────
    const rawResult = body.task_result?.result ?? [];
    let transcript = "";

    if (rawResult.length > 0) {
      if (typeof rawResult[0] === "string") {
        // 格式一：string[]
        transcript = (rawResult as string[]).join(" ").trim();
      } else {
        // 格式二：Array<{res: string[]}>（AASR Pro 格式）
        transcript = (rawResult as Array<{ res?: string[] }>)
          .flatMap((item) => item.res ?? [])
          .join(" ")
          .trim();
      }
    }

    if (!transcript) {
      await supabase.from("video_pipeline_jobs").update({
        status: "failed",
        stage_label: "AASR 结果为空",
        error_msg: "百度 AASR 返回转录内容为空，视频可能无语音",
      }).eq("id", jobId);
      return new Response(JSON.stringify({ ok: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── LLM 整理 Markdown ─────────────────────────────────────────────────────
    await supabase.from("video_pipeline_jobs").update({
      status: "formatting",
      stage_label: "AI 正在整理转录内容…",
      transcript,
    }).eq("id", jobId);

    let markdown = transcript;
    if (llmKey) {
      try {
        markdown = await callLLM(llmKey, buildVideoPrompt(transcript));
      } catch (e) {
        console.warn(`[vp-callback] LLM format failed, using raw transcript: ${e}`);
      }
    }

    // ── 写回数据库，完成 ──────────────────────────────────────────────────────
    await supabase.from("video_pipeline_jobs").update({
      status: "completed",
      stage_label: "处理完成",
      transcript,
      markdown,
    }).eq("id", jobId);

    console.log(`[vp-callback] job ${jobId} completed via webhook`);
    return new Response(JSON.stringify({ ok: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("[vp-callback] error:", message);
    return new Response(JSON.stringify({ error: message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
