/**
 * video-pipeline  (v4 — 百度云 BOS + AASR 全链路版)
 *
 * 完整处理链：
 *   视频 URL
 *     → 音频流提取（YouTube/Bilibili 内部 API，等价于 yt-dlp --extract-audio）
 *     → 流式上传至百度 BOS（REST PUT，等价于 bcecmd 秒级上传）
 *     → 提交百度 AASR 长文件分布式转写任务
 *     → 回调 video-pipeline-callback（LLM 整理 Markdown，Realtime 推送前端）
 *
 * 快速通道（字幕可用时）：
 *   YouTube / Bilibili → 直接读取平台字幕 → LLM → 同步返回（无需等回调）
 *
 * 架构说明：
 *   - 无 yt-dlp / ffmpeg / bcecmd CLI 依赖；全部通过 REST API 实现等价功能
 *   - YouTube 音频：youtubei/v1/player Android 客户端接口（与 yt-dlp 相同数据源）
 *   - BOS 上传：BCE Signature V4 REST PUT，文件极小（仅音频轨，原视频 1-5%）
 *   - ASR：百度 AASR 分布式并行转写，支持几小时音频分钟级完成，含回调 Webhook
 */

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const LLM_ENDPOINT =
  "https://app-c3jwcqqxdam9-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse";

// ── 平台检测 ──────────────────────────────────────────────────────────────────

function extractYouTubeId(url: string): string | null {
  const p = /(?:youtube\.com\/(?:watch\?.*v=|embed\/|v\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/.exec(url);
  return p ? p[1] : null;
}

function extractBilibiliId(url: string): string | null {
  const bv = /\/video\/(BV[a-zA-Z0-9]+)/i.exec(url);
  if (bv) return bv[1];
  const av = /\/video\/av(\d+)/i.exec(url);
  return av ? `av${av[1]}` : null;
}

// ── YouTube 字幕快速通道 ───────────────────────────────────────────────────────

// ── YouTube 字幕快速通道（增强版）────────────────────────────────────────────
//
//   多策略，优先级：
//   1. 从 ytInitialPlayerResponse JSON 提取完整 captionTracks（最可靠）
//   2. 老正则备选（YouTube HTML 结构不同版本兼容）
//   3. 通过 Piped API 获取字幕 URL（HTML 完全无字幕时）

async function getYouTubeCaptions(videoId: string): Promise<string> {
  // ── 策略 1：解析 ytInitialPlayerResponse（完整 player JSON）────────────────
  const watchUrl = `https://www.youtube.com/watch?v=${videoId}`;
  const r = await fetch(watchUrl, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
      "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    },
    signal: AbortSignal.timeout(20_000),
  });
  if (!r.ok) throw new Error("NO_CAPTIONS");
  const html = await r.text();

  interface CaptionTrack { baseUrl: string; languageCode: string; kind?: string }

  // 尝试从完整 ytInitialPlayerResponse 中提取
  let tracks: CaptionTrack[] = [];

  // 方法 A：提取整个 ytInitialPlayerResponse 对象
  const playerRespMatch = /ytInitialPlayerResponse\s*=\s*(\{.+?\});(?:\s*(?:var|const|let)\s|\s*<\/script>)/.exec(html);
  if (playerRespMatch) {
    try {
      const pr = JSON.parse(playerRespMatch[1]) as {
        captions?: { playerCaptionsTracklistRenderer?: { captionTracks?: CaptionTrack[] } }
      };
      tracks = pr.captions?.playerCaptionsTracklistRenderer?.captionTracks ?? [];
    } catch { /* 继续尝试其他方法 */ }
  }

  // 方法 B：老正则（直接匹配 captionTracks 数组）
  if (!tracks.length) {
    const m = /"captionTracks":(\[.*?\])/.exec(html);
    if (m) {
      try { tracks = JSON.parse(m[1]) as CaptionTrack[]; } catch { /* ignore */ }
    }
  }

  // 方法 C：更宽松的正则，处理 HTML 转义字符
  if (!tracks.length) {
    const m2 = /"captionTracks":\s*(\[[\s\S]*?\])(?=,\s*"[a-z])/.exec(html);
    if (m2) {
      try {
        const raw = m2[1].replace(/\\x([0-9A-Fa-f]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16)));
        tracks = JSON.parse(raw) as CaptionTrack[];
      } catch { /* ignore */ }
    }
  }

  if (!tracks.length) throw new Error("NO_CAPTIONS");

  // 优先：手动中文 > 自动中文 > 手动英文 > 自动英文 > 任意
  const pick = (
    tracks.find((t) => t.languageCode.startsWith("zh") && t.kind !== "asr") ??
    tracks.find((t) => t.languageCode.startsWith("zh")) ??
    tracks.find((t) => t.languageCode === "en" && t.kind !== "asr") ??
    tracks.find((t) => t.languageCode === "en") ??
    tracks[0]
  );
  if (!pick?.baseUrl) throw new Error("NO_CAPTIONS");

  // 拼接字幕 URL，尝试 json3 格式（更紧凑），失败则用默认 XML
  const baseUrl = pick.baseUrl.includes("?") ? pick.baseUrl : `${pick.baseUrl}`;
  const capUrl = `${baseUrl}&fmt=json3`;
  const cr = await fetch(capUrl, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; ResearchAgent/2.0)" },
    signal: AbortSignal.timeout(15_000),
  });
  if (!cr.ok) throw new Error("NO_CAPTIONS");

  const json = await cr.json() as { events?: Array<{ segs?: Array<{ utf8?: string }> }> };
  const text = (json.events ?? [])
    .filter((e) => e.segs)
    .map((e) => (e.segs ?? []).map((s) => s.utf8 ?? "").join(""))
    .join(" ")
    .replace(/\s+/g, " ")
    .trim();
  if (!text) throw new Error("NO_CAPTIONS");
  console.log(`[yt-caption] extracted ${text.length} chars (lang=${pick.languageCode} kind=${pick.kind ?? "manual"})`);
  return text;
}

// ── YouTube 音频流提取（等价于 yt-dlp --extract-audio）─────────────────────────
//
//   使用 YouTube 官方 youtubei/v1/player 内部 API（Android 客户端）。
//   Android 客户端返回的流 URL 为直连地址，无 n-sig 签名限制，
//   与 yt-dlp 读取的数据源完全相同。
//   音频格式：itag 140 = m4a 128kbps（典型 10 分钟视频约 10MB）

interface AudioStream {
  url: string;
  mimeType: string;   // e.g. "audio/mp4; codecs=\"mp4a.40.2\""
  bitrate: number;
  contentLength?: string;
}

// ── YouTube 音频流提取（等价于 yt-dlp --extract-audio）─────────────────────────
//
//   策略层级（按优先级）：
//   Layer 1 — 直连 YouTube youtubei API（TVHTML5 → IOS → ANDROID）
//   Layer 2 — Piped / Invidious 开源代理（当 Layer1 被云 IP 封锁时）
//             代理服务器用自己的 IP 访问 YouTube API，返回 googlevideo.com CDN URL
//             CDN URL 不需要认证，任意 IP 均可直接下载
//
//   音频格式优先：itag 140 = m4a 128kbps，典型 10 分钟视频约 10MB

interface YTAdaptiveFormat {
  itag: number;
  url?: string;
  mimeType: string;
  bitrate: number;
  contentLength?: string;
}

interface YTPlayerResponse {
  playabilityStatus?: { status?: string; reason?: string };
  streamingData?: { adaptiveFormats?: YTAdaptiveFormat[] };
}

async function fetchYTPlayer(
  videoId: string,
  clientName: string,
  clientVersion: string,
  extra?: Record<string, string | number>,
): Promise<YTPlayerResponse> {
  const uaMap: Record<string, string> = {
    TVHTML5:  "Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0) AppleWebKit/538.1 (KHTML, like Gecko) Version/6.0 TV Safari/538.1",
    IOS:      "com.google.ios.youtube/19.29.1 (iPhone16,2; U; CPU iOS 17_5_1 like Mac OS X)",
    ANDROID:  "com.google.android.youtube/17.31.35 (Linux; U; Android 11) gzip",
  };
  const resp = await fetch("https://www.youtube.com/youtubei/v1/player", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "User-Agent": uaMap[clientName] ?? "Mozilla/5.0",
    },
    body: JSON.stringify({
      videoId,
      context: { client: { clientName, clientVersion, hl: "en", gl: "US", utcOffsetMinutes: 0, ...extra } },
    }),
    signal: AbortSignal.timeout(20_000),
  });
  if (!resp.ok) throw new Error(`${clientName} player API 返回 ${resp.status}`);
  return resp.json() as Promise<YTPlayerResponse>;
}

/** Layer 2：并行探测所有 Piped / Invidious 代理，取最先成功者（Promise.any）*/
async function getYouTubeAudioViaProxy(videoId: string): Promise<AudioStream> {
  const PROBE_TIMEOUT = 8_000; // 每节点 8s，并行探测总耗时 ≤ 8s

  // ── Piped instances ───────────────────────────────────────────────────────
  const pipedFetch = async (base: string): Promise<AudioStream> => {
    const r = await fetch(`${base}/streams/${videoId}`, {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; ResearchAgent/2.0)" },
      signal: AbortSignal.timeout(PROBE_TIMEOUT),
    });
    if (!r.ok) throw new Error(`${base} → ${r.status}`);
    const data = await r.json() as {
      audioStreams?: Array<{ url?: string; mimeType?: string; format?: string; bitrate?: number; contentLength?: string }>;
      error?: string;
    };
    if (data.error) throw new Error(`${base} error: ${data.error}`);
    const streams = (data.audioStreams ?? []).filter((s) => s.url).sort((a, b) => (b.bitrate ?? 0) - (a.bitrate ?? 0));
    if (!streams.length) throw new Error(`${base}: no audio streams`);
    const best = streams[0];
    const mime = best.mimeType ?? (best.format?.toLowerCase().includes("webm") ? "audio/webm" : "audio/mp4");
    console.log(`[yt-proxy] Piped ${base} OK mime=${mime} bitrate=${best.bitrate}`);
    return { url: best.url!, mimeType: mime, bitrate: best.bitrate ?? 128000, contentLength: best.contentLength };
  };

  // ── Invidious instances ───────────────────────────────────────────────────
  const invidFetch = async (base: string): Promise<AudioStream> => {
    const r = await fetch(`${base}/api/v1/videos/${videoId}?fields=adaptiveFormats`, {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; ResearchAgent/2.0)" },
      signal: AbortSignal.timeout(PROBE_TIMEOUT),
    });
    if (!r.ok) throw new Error(`Invidious ${base} → ${r.status}`);
    const data = await r.json() as {
      adaptiveFormats?: Array<{ url?: string; type?: string; bitrate?: string; itag?: number }>;
      error?: string;
    };
    if (data.error) throw new Error(`Invidious ${base} error: ${data.error}`);
    const audioFormats = (data.adaptiveFormats ?? [])
      .filter((f) => f.type?.startsWith("audio/") && f.url)
      .sort((a, b) => {
        const p = (t?: number) => t === 140 ? 100 : t === 251 ? 90 : t === 250 ? 80 : 0;
        return p(b.itag) - p(a.itag);
      });
    if (!audioFormats.length) throw new Error(`Invidious ${base}: no audio`);
    const best = audioFormats[0];
    console.log(`[yt-proxy] Invidious ${base} OK itag=${best.itag}`);
    return {
      url: best.url!,
      mimeType: best.type?.split(";")[0].trim() ?? "audio/mp4",
      bitrate: parseInt(best.bitrate ?? "128000") || 128000,
    };
  };

  // 全部并行发出，取最先成功者（Promise.any 语义）
  const all: Promise<AudioStream>[] = [
    pipedFetch("https://pipedapi.kavin.rocks"),
    pipedFetch("https://pipedapi.tokhmi.xyz"),
    pipedFetch("https://piped-api.garudalinux.org"),
    pipedFetch("https://api.piped.projectsegfault.com"),
    invidFetch("https://iv.melmac.space"),
    invidFetch("https://invidious.nerdvpn.de"),
    invidFetch("https://invidious.privacydev.net"),
  ];

  try {
    return await Promise.any(all);
  } catch {
    throw new Error("Piped/Invidious 所有 7 个代理节点均无响应（并行 8s 内）");
  }
}

async function getYouTubeAudioStream(videoId: string): Promise<AudioStream> {
  console.log(`[yt-audio] fetching stream info for ${videoId}`);

  // ── Layer 1：直连 YouTube youtubei API ──────────────────────────────────────
  const clients: Array<[string, string, Record<string, string | number>?]> = [
    ["TVHTML5",  "2.0"],
    ["IOS",      "19.29.1", { deviceMake: "Apple", deviceModel: "iPhone16,2", osName: "iPhone", osVersion: "17.5.1.21F90" }],
    ["ANDROID",  "17.31.35", { androidSdkVersion: 30 }],
  ];

  let lastError = "";
  for (const [clientName, clientVersion, extra] of clients) {
    try {
      const data = await fetchYTPlayer(videoId, clientName, clientVersion, extra);
      const status = data.playabilityStatus?.status;
      if (status !== "OK") {
        lastError = `${clientName}: 不可播放（${status}）`;
        console.warn(`[yt-audio] ${lastError}`);
        continue;
      }
      const audioFormats = (data.streamingData?.adaptiveFormats ?? [])
        .filter((f) => f.mimeType.startsWith("audio/") && f.url)
        .sort((a, b) => {
          const p = (t: number) => t === 140 ? 100 : t === 251 ? 90 : t === 250 ? 80 : t === 249 ? 70 : 0;
          return p(b.itag) - p(a.itag);
        });
      if (!audioFormats.length) { lastError = `${clientName}: 无可用音频流`; continue; }
      const best = audioFormats[0];
      console.log(`[yt-audio] Layer1/${clientName} OK — itag=${best.itag} mime=${best.mimeType}`);
      return { url: best.url!, mimeType: best.mimeType, bitrate: best.bitrate, contentLength: best.contentLength };
    } catch (e) {
      lastError = `${clientName}: ${e instanceof Error ? e.message : String(e)}`;
      console.warn(`[yt-audio] ${lastError}`);
    }
  }

  // ── Layer 2：Piped / Invidious 开源代理（云 IP 被封时的可靠回路）──────────
  console.log(`[yt-audio] Layer1 all failed (${lastError}), trying proxy layer`);
  try {
    const stream = await getYouTubeAudioViaProxy(videoId);
    console.log(`[yt-audio] Layer2 proxy OK`);
    return stream;
  } catch (proxyErr) {
    throw new Error(
      `YouTube 音频流提取失败。直连：${lastError}；代理：${proxyErr instanceof Error ? proxyErr.message : proxyErr}`
    );
  }
}

// ── Bilibili 字幕快速通道 + 音频流 ────────────────────────────────────────────

async function getBilibiliCaptions(bvid: string): Promise<string> {
  const infoR = await fetch(
    `https://api.bilibili.com/x/web-interface/view?bvid=${encodeURIComponent(bvid)}`,
    { headers: { "User-Agent": "Mozilla/5.0", Referer: "https://www.bilibili.com" }, signal: AbortSignal.timeout(15_000) }
  );
  const infoData = await infoR.json() as { code: number; data?: { cid?: number } };
  if (infoData.code !== 0) throw new Error("NO_CAPTIONS");
  const cid = infoData.data?.cid;
  if (!cid) throw new Error("NO_CAPTIONS");
  const subR = await fetch(
    `https://api.bilibili.com/x/player/v2?bvid=${encodeURIComponent(bvid)}&cid=${cid}`,
    { headers: { "User-Agent": "Mozilla/5.0", Referer: "https://www.bilibili.com" }, signal: AbortSignal.timeout(15_000) }
  );
  const subData = await subR.json() as { data?: { subtitle?: { subtitles?: Array<{ subtitle_url: string; lan_doc: string }> } } };
  const subs = subData.data?.subtitle?.subtitles ?? [];
  if (!subs.length) throw new Error("NO_CAPTIONS");
  const sub = subs.find((s) => s.lan_doc?.includes("中文")) ?? subs.find((s) => s.lan_doc?.includes("自动")) ?? subs[0];
  const subUrl = sub.subtitle_url.startsWith("//") ? `https:${sub.subtitle_url}` : sub.subtitle_url;
  const subJson = await (await fetch(subUrl, { signal: AbortSignal.timeout(15_000) })).json() as { body?: Array<{ content: string }> };
  const text = (subJson.body ?? []).map((i) => i.content).join(" ").trim();
  if (!text) throw new Error("NO_CAPTIONS");
  return text;
}

async function getBilibiliAudioStream(bvid: string): Promise<AudioStream> {
  console.log(`[bili-audio] fetching stream info for ${bvid}`);
  // Step 1: 获取 cid
  const infoR = await fetch(
    `https://api.bilibili.com/x/web-interface/view?bvid=${encodeURIComponent(bvid)}`,
    { headers: { "User-Agent": "Mozilla/5.0", Referer: "https://www.bilibili.com" }, signal: AbortSignal.timeout(15_000) }
  );
  const infoData = await infoR.json() as { code: number; data?: { cid?: number } };
  if (infoData.code !== 0) throw new Error(`Bilibili API 错误 ${infoData.code}`);
  const cid = infoData.data?.cid;
  if (!cid) throw new Error("无法获取视频 cid");

  // Step 2: 获取音频流 URL（fnval=16 = DASH，包含独立音频轨）
  const streamR = await fetch(
    `https://api.bilibili.com/x/player/playurl?bvid=${encodeURIComponent(bvid)}&cid=${cid}&fnval=16&fourk=1`,
    { headers: { "User-Agent": "Mozilla/5.0", Referer: "https://www.bilibili.com" }, signal: AbortSignal.timeout(15_000) }
  );
  const streamData = await streamR.json() as {
    code: number;
    data?: {
      dash?: {
        audio?: Array<{ id: number; baseUrl: string; bandwidth: number; mimeType?: string }>;
      };
    };
  };
  if (streamData.code !== 0) throw new Error(`Bilibili playurl 错误 ${streamData.code}（可能需要登录）`);

  const audios = streamData.data?.dash?.audio ?? [];
  if (!audios.length) throw new Error("该视频无可用音频流（需要大会员或不支持）");

  // 最高码率音频
  const best = audios.sort((a, b) => b.bandwidth - a.bandwidth)[0];
  console.log(`[bili-audio] selected id=${best.id} bandwidth=${best.bandwidth}`);

  return {
    url: best.baseUrl,
    mimeType: best.mimeType ?? "audio/mp4",
    bitrate: best.bandwidth,
  };
}

// ── BOS 签名（BCE Signature V4）── 等价于 bcecmd ────────────────────────────

function toHex(bytes: Uint8Array): string {
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function hmacSha256(key: Uint8Array, data: string): Promise<Uint8Array> {
  const k = await crypto.subtle.importKey("raw", key, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(data)));
}

async function bosAuthHeader(
  ak: string, sk: string,
  method: string, path: string,
  headers: Record<string, string>,
  queryParams: Record<string, string> = {}
): Promise<string> {
  const now = new Date();
  const timestamp = now.toISOString().replace(/\.\d{3}Z$/, "Z");
  const expiry = 1800;
  const prefix = `bce-auth-v1/${ak}/${timestamp}/${expiry}`;

  const lh: Record<string, string> = {};
  for (const [k, v] of Object.entries(headers)) lh[k.toLowerCase()] = v.trim();

  const canonHeaders = Object.entries(lh)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${encodeURIComponent(k)}:${encodeURIComponent(v)}`)
    .join("\n");
  const signedHeaderNames = Object.keys(lh).sort().join(";");

  const canonQueryStr = Object.entries(queryParams)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join("&");

  const canonRequest = [method.toUpperCase(), encodeURIComponent(path).replace(/%2F/g, "/"), canonQueryStr, canonHeaders].join("\n");

  const signingKey = await hmacSha256(new TextEncoder().encode(sk), prefix);
  const signature = toHex(await hmacSha256(signingKey, canonRequest));

  return `${prefix}/${signedHeaderNames}/${signature}`;
}

function mimeToExt(mime: string): string {
  if (mime.includes("mp4") || mime.includes("m4a")) return "m4a";
  if (mime.includes("webm")) return "webm";
  if (mime.includes("ogg")) return "ogg";
  if (mime.includes("mpeg") || mime.includes("mp3")) return "mp3";
  return "m4a";
}

/** 流式下载音频 → 一次性 PUT 上传至 BOS（等价于 bcecmd 上传）*/
async function streamAudioToBOS(
  audioUrl: string,
  objectKey: string,
  contentType: string,
  ak: string, sk: string,
  bucket: string, region: string,
  refererHeader?: string,
): Promise<string> {
  console.log(`[bos-upload] downloading audio from ${audioUrl.slice(0, 80)}…`);

  const dlHeaders: Record<string, string> = {
    "User-Agent": "Mozilla/5.0 (compatible; ResearchAgent/2.0)",
    "Range": "bytes=0-",
  };
  if (refererHeader) dlHeaders["Referer"] = refererHeader;

  const dlResp = await fetch(audioUrl, { headers: dlHeaders, signal: AbortSignal.timeout(120_000) });
  if (!dlResp.ok && dlResp.status !== 206) throw new Error(`音频下载失败 (${dlResp.status})`);
  if (!dlResp.body) throw new Error("音频流为空");

  // 缓冲音频（音频轨通常 5–50MB，完全可以在内存中完成）
  const MAX_AUDIO = 150 * 1024 * 1024; // 150MB 安全上限
  const chunks: Uint8Array[] = [];
  let total = 0;
  const reader = dlResp.body.getReader();
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.length;
    if (total > MAX_AUDIO) throw new Error("音频文件超过 150MB 上限，请使用更短的视频");
    chunks.push(value);
  }

  const audioData = new Uint8Array(total);
  let offset = 0;
  for (const c of chunks) { audioData.set(c, offset); offset += c.length; }
  console.log(`[bos-upload] downloaded ${(total / 1024 / 1024).toFixed(2)} MB, uploading to BOS`);

  // BOS PUT
  const bosHost = `${bucket}.${region}.bcebos.com`;
  const bosPath = `/${objectKey}`;
  const bosHeaders: Record<string, string> = {
    "Host": bosHost,
    "Content-Type": contentType,
    "Content-Length": String(total),
  };
  const auth = await bosAuthHeader(ak, sk, "PUT", bosPath, bosHeaders);
  bosHeaders["Authorization"] = auth;

  const putResp = await fetch(`https://${bosHost}${bosPath}`, {
    method: "PUT",
    headers: bosHeaders,
    body: audioData,
    signal: AbortSignal.timeout(120_000),
  });

  if (!putResp.ok) {
    const errText = await putResp.text().catch(() => "");
    throw new Error(`BOS 上传失败 (${putResp.status})：${errText.slice(0, 300)}`);
  }

  const publicUrl = `https://${bosHost}/${objectKey}`;
  console.log(`[bos-upload] upload OK → ${publicUrl}`);
  return publicUrl;
}

// ── 百度 AASR 分布式 ASR ──────────────────────────────────────────────────────

async function getBaiduAccessToken(apiKey: string, secretKey: string): Promise<string> {
  const r = await fetch(
    `https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=${encodeURIComponent(apiKey)}&client_secret=${encodeURIComponent(secretKey)}`,
    { method: "POST", signal: AbortSignal.timeout(15_000) }
  );
  if (!r.ok) throw new Error(`Baidu token 获取失败 (${r.status})`);
  const d = await r.json() as { access_token?: string; error?: string };
  if (!d.access_token) throw new Error(`Baidu token 错误：${d.error}`);
  return d.access_token;
}

/** 提交百度 AASR 长文件分布式转写任务，返回 task_id */
async function submitBaiduAAASR(
  token: string,
  speechUrl: string,
  format: string,  // "m4a" | "webm" | "mp3" | "wav"
  callbackUrl: string,
): Promise<string> {
  console.log(`[aasr] submitting job, url=${speechUrl.slice(0, 80)}, format=${format}`);

  const body = {
    speech_url: speechUrl,
    format: format === "webm" ? "webm" : "m4a",  // AASR 支持 m4a / mp3 / wav / webm
    pid: 80001,       // 普通话模型（1737 = 中英混合，80001 = 普通话生产）
    rate: 16000,
    callback_url: callbackUrl,
  };

  const r = await fetch(
    `https://aip.baidubce.com/rpc/2.0/aasr/v1/submit?access_token=${token}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(30_000),
    }
  );

  if (!r.ok) throw new Error(`AASR 提交失败 (${r.status})`);
  const d = await r.json() as { task_id?: string; err_no?: number; err_msg?: string };

  if (d.err_no && d.err_no !== 0) {
    throw new Error(`AASR 错误 ${d.err_no}：${d.err_msg}`);
  }
  if (!d.task_id) throw new Error("AASR 未返回 task_id");

  console.log(`[aasr] task submitted, task_id=${d.task_id}`);
  return d.task_id;
}

/** 主动轮询 AASR 任务状态（作为 webhook 不可达时的降级方案） */
async function pollAAASR(token: string, taskId: string): Promise<string> {
  const MAX_POLLS = 60;  // 最多轮询 60 次 × 10s = 10 分钟
  for (let i = 0; i < MAX_POLLS; i++) {
    await new Promise((r) => setTimeout(r, 10_000));

    const r = await fetch(
      `https://aip.baidubce.com/rpc/2.0/aasr/v1/query?access_token=${token}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ task_ids: [taskId] }),
        signal: AbortSignal.timeout(15_000),
      }
    );
    if (!r.ok) continue;

    const d = await r.json() as {
      tasks_info?: Array<{
        task_id: string;
        task_status: string;
        task_result?: { result?: string[]; err_msg?: string; err_no?: number };
      }>
    };

    const info = d.tasks_info?.[0];
    if (!info) continue;

    console.log(`[aasr-poll] task_id=${taskId} status=${info.task_status} (poll ${i + 1})`);

    if (info.task_status === "Success") {
      const segments = info.task_result?.result ?? [];
      return segments.join(" ").trim();
    }
    if (info.task_status === "Error") {
      throw new Error(`AASR 转写失败：${info.task_result?.err_msg ?? "未知错误"}`);
    }
    // Running → 继续轮询
  }
  throw new Error("AASR 轮询超时（10 分钟），请检查百度云后台任务状态");
}

// ── LLM 格式化 ────────────────────────────────────────────────────────────────

async function callLLM(apiKey: string, prompt: string): Promise<string> {
  const resp = await fetch(LLM_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${apiKey}` },
    body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: prompt }] }] }),
    signal: AbortSignal.timeout(120_000),
  });
  if (!resp.ok || !resp.body) throw new Error(`LLM 调用失败 (${resp.status})`);
  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "", result = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const data = line.slice(5).trim();
      if (!data || data === "[DONE]") continue;
      try {
        const frame = JSON.parse(data) as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> };
        const text = frame?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (text) result += text;
      } catch { /* skip */ }
    }
  }
  return result;
}

function buildMarkdownPrompt(transcript: string, title?: string): string {
  const titleHint = title && title !== "在线视频" ? `视频标题：${title}\n\n` : "";
  return `你是专业内容整理助手。以下是一段视频的语音转录文字，请将其整理为结构清晰的 Markdown 文档，适合学术/行业研究知识库使用。

${titleHint}转录文字：
${transcript}

整理要求：
1. 提取核心观点和关键信息，去除口语化冗余词（"嗯"、"那么"、"就是说"等）
2. 按内容逻辑划分章节，使用合适的 Markdown 标题层级（# ## ###）
3. 数据、结论、案例等重要信息用列表或引用块（>）突出显示
4. 保留专业术语、人名、机构名的准确表述
5. 输出纯 Markdown，不要有额外解释或前言`;
}

// ── Main Handler ──────────────────────────────────────────────────────────────

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");

  // 百度云配置
  const bosAk = Deno.env.get("BAIDU_BCE_AK") ?? "";
  const bosSk = Deno.env.get("BAIDU_BCE_SK") ?? "";
  const bosBucket = Deno.env.get("BAIDU_BOS_BUCKET") ?? "";
  const bosRegion = Deno.env.get("BAIDU_BOS_REGION") ?? "bj";
  const asrApiKey = Deno.env.get("BAIDU_ASR_API_KEY") ?? "";
  const asrSecretKey = Deno.env.get("BAIDU_ASR_SECRET_KEY") ?? "";

  const baiduConfigured = bosAk && bosSk && bosBucket && asrApiKey && asrSecretKey;

  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    const body = await req.json() as { video_url: string; title?: string };
    const { video_url, title } = body;

    if (!video_url?.trim()) {
      return new Response(JSON.stringify({ error: "缺少 video_url 参数" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // 获取登录用户
    let ownerId: string | null = null;
    const authHeader = req.headers.get("Authorization") ?? "";
    if (authHeader.startsWith("Bearer ") && supabaseAnonKey) {
      try {
        const userClient = createClient(supabaseUrl, supabaseAnonKey, {
          global: { headers: { Authorization: authHeader } },
        });
        const { data: { user } } = await userClient.auth.getUser();
        ownerId = user?.id ?? null;
      } catch { /* 匿名 */ }
    }

    // 创建 job 记录
    const jobInsert: Record<string, unknown> = {
      video_url,
      status: "asr_processing",
      stage_label: "正在识别视频平台…",
    };
    if (ownerId) jobInsert.owner_id = ownerId;

    const { data: jobData } = await supabase
      .from("video_pipeline_jobs")
      .insert(jobInsert)
      .select("id")
      .maybeSingle();

    const jobId: string | null = (jobData as { id: string } | null)?.id ?? null;

    const updateJob = async (fields: Record<string, unknown>) => {
      if (!jobId) return;
      await supabase.from("video_pipeline_jobs").update(fields).eq("id", jobId);
    };

    const youtubeId = extractYouTubeId(video_url);
    const bilibiliId = extractBilibiliId(video_url);

    // ────────────────────────────────────────────────────────────────────────
    // 快速通道：平台字幕（无需下载/ASR，秒级返回）
    // ────────────────────────────────────────────────────────────────────────
    if (youtubeId || bilibiliId) {
      try {
        await updateJob({ stage_label: "尝试读取平台字幕…" });
        const captions = youtubeId
          ? await getYouTubeCaptions(youtubeId)
          : await getBilibiliCaptions(bilibiliId!);

        console.log(`[video-pipeline] caption fast-path OK, length=${captions.length}`);
        await updateJob({ status: "formatting", stage_label: "AI 整理 Markdown…", transcript: captions });

        let markdown = captions;
        try {
          if (apiKey) markdown = await callLLM(apiKey, buildMarkdownPrompt(captions, title));
        } catch (e) { console.warn(`[video-pipeline] LLM failed: ${e}`); }

        await updateJob({ status: "completed", stage_label: "处理完成（字幕通道）", markdown });

        return new Response(
          JSON.stringify({ job_id: jobId, status: "completed", transcript_source: "caption", transcript: captions, markdown }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        // 只有真正的严重错误才向上抛出（如鉴权失败等），字幕缺失/网络问题走音频管道
        if (msg.includes("LOGIN_REQUIRED") || msg.includes("UNPLAYABLE")) throw e;
        console.log(`[video-pipeline] caption fast-path skipped (${msg}), trying audio pipeline`);
      }
    }

    // ────────────────────────────────────────────────────────────────────────
    // 主管道：音频提取 → BOS 上传 → 百度 AASR 分布式转写
    // ────────────────────────────────────────────────────────────────────────

    // Step 1：提取音频流 URL（等价于 yt-dlp --extract-audio，仅音频轨）
    await updateJob({ stage_label: "提取音频流…" });

    let audioStream: AudioStream;
    let audioReferer: string | undefined;

    if (youtubeId) {
      try {
        audioStream = await getYouTubeAudioStream(youtubeId);
      } catch (e) {
        // 直连 + 所有代理均失败
        const msg = e instanceof Error ? e.message : String(e);
        console.warn(`[video-pipeline] YouTube all layers failed: ${msg}`);
        // 返回结构化错误码，前端据此展示友好兜底 UI
        const userMsg = "YouTube 链接处理失败（服务器 IP 被反 Bot 系统拦截，视频也无可用字幕）";
        await updateJob({ status: "failed", stage_label: "YouTube 处理失败", error_msg: userMsg });
        return new Response(JSON.stringify({ error: userMsg, error_code: "YOUTUBE_BLOCKED", video_id: youtubeId }), {
          status: 422, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    } else if (bilibiliId) {
      try {
        audioStream = await getBilibiliAudioStream(bilibiliId);
        audioReferer = "https://www.bilibili.com";
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        console.warn(`[video-pipeline] Bilibili audio stream failed: ${msg}`);
        const userMsg = "B站音频流提取失败（可能需要登录或为大会员视频），建议：① 下载视频后上传文件 ② 使用直链视频 URL";
        await updateJob({ status: "failed", stage_label: "B站音频流受限", error_msg: userMsg });
        return new Response(JSON.stringify({ error: userMsg }), {
          status: 422, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    } else {
      // 通用直链：直接使用 URL
      audioStream = { url: video_url, mimeType: "audio/mp4", bitrate: 0 };
    }

    const ext = mimeToExt(audioStream.mimeType);
    const timestamp = Date.now();
    const objectKey = `audio-pipeline/${timestamp}_${jobId ?? "job"}.${ext}`;

    // Step 2：流式上传至 BOS（等价于 bcecmd 秒级上传）
    if (!baiduConfigured) {
      // 百度未配置 → 降级到 Whisper STT
      await updateJob({ stage_label: "百度云未配置，降级使用 Whisper STT…" });
      console.log(`[video-pipeline] Baidu not configured, falling back to Whisper`);
      return await fallbackWhisper(audioStream.url, jobId, title, supabase, updateJob, apiKey ?? "");
    }

    await updateJob({ stage_label: "音频上传至百度 BOS（极小文件，秒级完成）…", status: "uploading_bos" });

    const bosUrl = await streamAudioToBOS(
      audioStream.url,
      objectKey,
      audioStream.mimeType.split(";")[0].trim(),
      bosAk, bosSk, bosBucket, bosRegion,
      audioReferer,
    );

    // Step 3：提交百度 AASR 分布式转写（含回调 URL）
    await updateJob({ stage_label: "提交百度分布式 ASR 任务…", status: "asr_submitted" });

    const asrToken = await getBaiduAccessToken(asrApiKey, asrSecretKey);
    const callbackUrl = `${supabaseUrl}/functions/v1/video-pipeline-callback?job_id=${jobId}`;
    const taskId = await submitBaiduAAASR(asrToken, bosUrl, ext, callbackUrl);

    await updateJob({
      status: "asr_processing",
      stage_label: "百度分布式 ASR 转写中，通过回调自动推送结果…",
      bos_url: bosUrl,
      asr_task_id: taskId,
    });

    console.log(`[video-pipeline] ASR submitted, job_id=${jobId}, task_id=${taskId}`);

    // 异步返回 job_id，前端通过 Realtime 订阅等待 callback 完成
    return new Response(
      JSON.stringify({
        job_id: jobId,
        status: "asr_processing",
        transcript_source: "baidu_aasr",
        message: "分布式 ASR 转写已提交，结果将通过 Webhook 实时推送",
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("[video-pipeline] error:", message);
    const status = message.includes("429") ? 429 : message.includes("402") ? 402 : 500;
    return new Response(JSON.stringify({ error: message }), {
      status, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

// ── Whisper 降级处理（百度未配置时） ─────────────────────────────────────────

async function fallbackWhisper(
  audioUrl: string,
  jobId: string | null,
  title: string | undefined,
  supabase: ReturnType<typeof createClient>,
  updateJob: (fields: Record<string, unknown>) => Promise<void>,
  apiKey: string,
): Promise<Response> {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  };
  const STT_ENDPOINT = "https://app-c3jwcqqxdam9-api-DY8MNQoqOnMa.gateway.appmedo.com/v1/audio/transcriptions";
  const LLM_ENDPOINT = "https://app-c3jwcqqxdam9-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse";

  await updateJob({ stage_label: "Whisper 语音识别中…", status: "transcribing" });

  // 下载音频（仅适用于直链音视频 URL，不适用于 YouTube/Bilibili watch 页面）
  const dlResp = await fetch(audioUrl, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; ResearchAgent/2.0)" },
    signal: AbortSignal.timeout(120_000),
  });
  if (!dlResp.ok || !dlResp.body) throw new Error(`音频下载失败 (${dlResp.status})`);

  // ── 关键校验：必须是音视频内容，否则 Whisper 会 400 ──────────────────────
  const ct = (dlResp.headers.get("content-type") ?? "").toLowerCase();
  const isAudioVideo = ct.startsWith("audio/") || ct.startsWith("video/") || ct.includes("octet-stream");
  if (!isAudioVideo) {
    throw new Error(
      `下载内容不是音视频文件（Content-Type: ${ct || "未知"}）。` +
      `YouTube/Bilibili watch 链接无法直接转写，请使用直链 mp4/mp3/m4a URL，或上传本地音视频文件。`
    );
  }

  const chunks: Uint8Array[] = [];
  let total = 0;
  const reader = dlResp.body.getReader();
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.length;
    chunks.push(value);
  }
  const buf = new Uint8Array(total);
  let off = 0;
  for (const c of chunks) { buf.set(c, off); off += c.length; }

  // Whisper 支持格式：mp3 mp4 mpeg mpga m4a ogg wav webm
  // 根据 Content-Type 选择正确的扩展名和 MIME
  let ext = "m4a";
  let blobType = "audio/mp4";
  if (ct.includes("webm"))  { ext = "webm"; blobType = "audio/webm"; }
  else if (ct.includes("ogg"))   { ext = "ogg";  blobType = "audio/ogg";  }
  else if (ct.includes("wav"))   { ext = "wav";  blobType = "audio/wav";  }
  else if (ct.includes("mpeg") || ct.includes("mp3")) { ext = "mp3"; blobType = "audio/mpeg"; }
  else if (ct.includes("mp4") || ct.includes("m4a") || ct.includes("octet-stream")) {
    ext = "m4a"; blobType = "audio/mp4";
  }

  const form = new FormData();
  form.append("file", new Blob([buf], { type: blobType }), `audio.${ext}`);
  form.append("model", "whisper-1");
  form.append("response_format", "json");
  form.append("language", "zh");

  const sttResp = await fetch(STT_ENDPOINT, {
    method: "POST",
    headers: { "X-Gateway-Authorization": `Bearer ${apiKey}` },
    body: form,
    signal: AbortSignal.timeout(240_000),
  });

  if (!sttResp.ok) {
    const errText = await sttResp.text().catch(() => "");
    throw new Error(`Whisper STT 失败 (${sttResp.status})：${errText.slice(0, 200)}`);
  }
  const sttData = await sttResp.json() as { text?: string };
  const transcript = (sttData.text ?? "").trim();
  if (!transcript) throw new Error("转录结果为空");

  await updateJob({ status: "formatting", stage_label: "AI 整理 Markdown…", transcript });

  // LLM 格式化
  let markdown = transcript;
  try {
    const llmResp = await fetch(LLM_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${apiKey}` },
      body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: buildMarkdownPrompt(transcript, title) }] }] }),
      signal: AbortSignal.timeout(120_000),
    });
    if (llmResp.ok && llmResp.body) {
      const rdr = llmResp.body.getReader();
      const dec = new TextDecoder();
      let buf2 = "", res = "";
      while (true) {
        const { done, value } = await rdr.read();
        if (done) break;
        buf2 += dec.decode(value, { stream: true });
        const lines = buf2.split("\n");
        buf2 = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.startsWith("data:")) continue;
          const d = line.slice(5).trim();
          if (!d || d === "[DONE]") continue;
          try {
            const frame = JSON.parse(d) as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> };
            const t = frame?.candidates?.[0]?.content?.parts?.[0]?.text;
            if (t) res += t;
          } catch { /* skip */ }
        }
      }
      if (res) markdown = res;
    }
  } catch (e) { console.warn(`[whisper-fallback] LLM failed: ${e}`); }

  await updateJob({ status: "completed", stage_label: "处理完成（Whisper 通道）", markdown });

  return new Response(
    JSON.stringify({ job_id: jobId, status: "completed", transcript_source: "whisper", transcript, markdown }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}
